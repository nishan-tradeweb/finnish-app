finnish  -  Write. That's it.                                   Creator: Nishan
===========================================================================
www/            the app (plain HTML/JS/CSS). Edit www/config.js once (see FIREBASE_SETUP.md).
electron/       Windows and Mac desktop shell
android-patch/  Android helper code (print to PDF, open-with)      scripts/  build helpers
firebase/       server side: account functions, database rules   (deployed with the Firebase CLI)
assets/         icon and splash sources
Upload finnish-app.zip and build.yml to the app repository; GitHub builds Android, Windows, macOS and the web version.
Version 1.0.0
