# finnish – server setup (Firebase) and release setup

Do these steps once, in this order. You need a Windows laptop with internet, a Google account, and your GitHub account.
Everything marked **COPY** goes into `www/config.js` (the only file you edit).

---
## 1. Create the Firebase project (Blaze plan)
1. Open https://console.firebase.google.com → **Create a project** → name it `finnish-writer` (any name) → turn **Google Analytics OFF** (the app promises no analytics).
2. Left menu → **Upgrade** (bottom) → choose **Blaze (pay as you go)** and add your billing details. Blaze is required for server functions. Normal early usage stays inside the free allowance. In Google Cloud → Billing → **Budgets & alerts**, add a budget alert (for example 5 USD) so you are warned about any cost.
3. **Project settings** (gear icon) → **General**:
   - Note the **Project ID** → **COPY** into `firebase.projectId`.
   - Under **Your apps** click the **Web** icon `</>` → nickname `finnish web` → Register (skip hosting). On the next screen find `apiKey` → **COPY** into `firebase.apiKey`.
   - You do **not** need the Android or iOS Firebase apps or a `google-services.json`; finnish talks to Firebase directly.

## 2. Turn on sign-in
Build → **Authentication** → **Get started** → **Sign-in method**:
- **Email/Password** → Enable (leave "Email link" off) → Save.
- **Google** → Enable → choose a support email → Save.
Then **Authentication → Templates**: open **Email address verification** and **Password reset** → pencil icon → set Sender name to `finnish`, Reply-to to your support address, and write the subject as `Verify your email for finnish` / `Reset your finnish password`. (Later, when you own a domain, you can send from `support@yourdomain` here.)
Authentication → **Settings → User actions**: tick **Email enumeration protection**.

## 3. Database (Firestore)
Build → **Firestore Database** → **Create database** → location near your users (for example `asia-south1` Mumbai or `nam5`) → **Start in production mode**. The rules are deployed in step 5.

## 4. Install the tools (once)
1. Install Node.js 20 LTS from https://nodejs.org.
2. Open **PowerShell** and run: `npm install -g firebase-tools` then `firebase login`.

## 5. Deploy the server code
In PowerShell, go to the `firebase` folder of this project (unzipped `finnish-app.zip` → `firebase`):
```
cd path\to\firebase
copy .firebaserc.example .firebaserc      (then open .firebaserc and put your Project ID in it)
cd functions
npm install
cd ..
firebase deploy --only firestore:rules,functions
```
The first deploy asks to enable some Google APIs – answer **Y**. When it ends you will see three functions: `status`, `deleteMe`, `verifyPlay`. If your region is not `us-central1`, create `firebase/functions/.env` with `FUNCTIONS_REGION=asia-south1` before deploying and set the same value in `config.js` → `firebase.region`.

**VPN check (recommended):** make a free account at https://proxycheck.io, copy the API key, and add this line to `firebase/functions/.env`: `PROXYCHECK_KEY=your-key`. Deploy again with `firebase deploy --only functions`. Without a key the free limit is about 1,000 checks a day; if the service is ever unreachable, people are simply not blocked.

## 6. Google sign-in and Drive backup (Google Cloud console)
Open https://console.cloud.google.com and select the same project (it was created for you).
1. **APIs & Services → Library** → search **Google Drive API** → Enable.
2. **APIs & Services → OAuth consent screen** (or "Google Auth platform"): User type **External**, App name `finnish`, support email, logo optional, developer contact email. **Scopes:** add `openid`, `email`, `profile`, and `.../auth/drive.appdata` (this one is non-sensitive, so no long review). Publish the app (**In production**) when you are ready; until then only listed test users can sign in with Google.
3. **APIs & Services → Credentials → Create credentials → OAuth client ID**, three times:
   - **Web application** → name `finnish web`; Authorized JavaScript origins: `https://nishan-tradeweb.github.io` (and `http://localhost:8000` if you test locally) → **COPY** the Client ID into `google.webClientId`.
   - **Android** → name `finnish android`; Package name `app.finnish.writer`; SHA-1 = the release key's SHA-1 from step 7 → **COPY** the Client ID into `google.androidClientId`. (If you later enrol in Play App Signing, create a second Android client with the SHA-1 Google shows in Play Console → App integrity, and keep both.)
   - **Desktop app** → name `finnish desktop` → **COPY** the Client ID into `google.desktopClientId` and the Client secret into `google.desktopClientSecret`. (Google treats desktop secrets as public.)

## 7. Android signing key (needed once; this is what lets an update install over the old app)
1. Install a JDK (https://adoptium.net, version 21). In PowerShell:
```
keytool -genkeypair -v -keystore finnish-release.jks -alias finnish -keyalg RSA -keysize 2048 -validity 10000
```
Choose a strong password (use the same for the key if asked). **Back up `finnish-release.jks` and the passwords in at least two safe places. If you lose this file you can never update the app.** Never upload it to GitHub as a file.
2. SHA-1 for step 6: `keytool -list -v -keystore finnish-release.jks -alias finnish` → copy the **SHA1** line.
3. Make the base64 text (PowerShell): `[Convert]::ToBase64String([IO.File]::ReadAllBytes("finnish-release.jks")) | Set-Clipboard`
4. In GitHub: app repository → **Settings → Secrets and variables → Actions → New repository secret**, add four secrets:
   `ANDROID_KEYSTORE_B64` (paste), `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` (= `finnish`), `ANDROID_KEY_PASSWORD`.
5. **One last uninstall:** older test APKs were signed with a different (debug) key, so install the new APK only after uninstalling the old one once. From then on every build is signed with the same key and installs as an update with all scripts kept.

## 8. Fill config.js and build
1. Put your values into `www/config.js`, zip the project again as `finnish-app.zip` (files at the top level of the zip).
2. App repository `nishan-tradeweb/finnish-app`: upload `finnish-app.zip` to the repository root and `build.yml` to `.github/workflows/` (delete the other old workflow files). **Settings → Pages → Source: GitHub Actions.**
3. Actions tab → the run takes about 15 minutes. Results: **Releases → v1.0.0** has `finnish-1.0.0.apk`, `finnish-1.0.0.aab`, `finnish-setup-1.0.0.exe`, `finnish-portable-1.0.0.exe`, `finnish-1.0.0.dmg`. The iPhone/Mac web version opens at https://nishan-tradeweb.github.io/Finnish/. Right-click any release file → Copy link address to get the download link for the website (`js/config.js` in the website).

## 9. Test before you publish (see the test list that came with these files)
Create an account with a real email, open the verification link, press **I have verified**, check the trial, sign out and in, test Google sign-in, back up to Drive and restore, delete the account, install a second build over the first (the update test).

## 10. Store billing (later, when the store listings exist)
- Google Play Console → your app → **Monetize → Subscriptions**: create `finnish_monthly` and `finnish_annual` (7-day grace optional, **no store free trial** because finnish gives its own 5-day trial) with prices per country matching the website.
- Link the Play Console to your Google Cloud project, then **Users and permissions → Invite** `PROJECT_ID@appspot.gserviceaccount.com` with **View financial data** and **Manage orders and subscriptions**. The `verifyPlay` function then checks purchases.
- The in-app purchase button needs a billing plugin and your product IDs, added after the listings exist. Until then `billingLive` stays `false` and the app shows "Subscriptions open soon".
- Apple (App Store) and Microsoft Store billing are separate later steps; the account, trial and region logic already works for them.
