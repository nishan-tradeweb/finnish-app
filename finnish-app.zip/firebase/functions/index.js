/* finnish server functions (Firebase, Node 20, first-generation callable functions).
   status      – starts the 5-day trial once per verified account, checks the country and VPN, returns the plan
   deleteMe    – deletes the signed-in user's record and account
   verifyPlay  – checks a Google Play subscription and records the plan (used once store billing is switched on)
   Region check uses proxycheck.io. Set PROXYCHECK_KEY for more than 1,000 lookups a day (see FIREBASE_SETUP.md). */
const functions = require('firebase-functions/v1');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

const REGION = process.env.FUNCTIONS_REGION || 'us-central1';
const fn = functions.region(REGION);
const TRIAL_MS = 5 * 24 * 3600 * 1000;

function ipOf(context) {
  const r = context.rawRequest || {};
  const xf = (r.headers && r.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return xf || r.ip || '';
}

/* country + VPN/proxy check. Fails open (no VPN flag) if the service is unreachable, so people are never locked out. */
async function lookup(ip) {
  if (!ip) return { country: '', vpn: false };
  try {
    const key = process.env.PROXYCHECK_KEY ? '&key=' + encodeURIComponent(process.env.PROXYCHECK_KEY) : '';
    const r = await fetch('https://proxycheck.io/v2/' + encodeURIComponent(ip) + '?vpn=1&asn=1' + key, { signal: AbortSignal.timeout(4000) });
    const j = await r.json(); const d = j[ip] || {};
    return { country: String(d.isocode || '').toUpperCase(), vpn: d.proxy === 'yes' };
  } catch (e) { return { country: '', vpn: false }; }
}

function needAuth(context) {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Please sign in.');
  return context.auth;
}

exports.status = fn.https.onCall(async (data, context) => {
  const auth = needAuth(context);
  const uid = auth.uid, verified = auth.token.email_verified === true;
  const ref = db.collection('users').doc(uid);
  const geo = await lookup(ipOf(context));
  const out = {};
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const u = snap.exists ? snap.data() : {};
    const patch = { email: auth.token.email || u.email || '', lastSeen: Date.now() };
    if (!snap.exists) patch.created = Date.now();
    // the trial starts once, when the email is verified
    if (verified && !u.trialStart) { patch.trialStart = Date.now(); u.trialStart = patch.trialStart; }
    // the price country is the real (non-VPN) country; it follows the person if they really move, but never changes while a VPN is detected
    if (geo.country && !geo.vpn) patch.country = geo.country;
    tx.set(ref, patch, { merge: true });
    const country = patch.country || u.country || '';
    out.trialEnd = u.trialStart ? u.trialStart + TRIAL_MS : 0;
    out.plan = u.plan && u.until > Date.now() ? u.plan : '';
    out.until = out.plan ? u.until : 0;
    out.country = country;
    out.vpn = geo.vpn;
  });
  return out;
});

exports.deleteMe = fn.https.onCall(async (data, context) => {
  const auth = needAuth(context);
  await db.collection('users').doc(auth.uid).delete().catch(() => { });
  await admin.auth().deleteUser(auth.uid);
  return { ok: true };
});

/* Google Play subscription check. Needs: the Play Console linked to a Google Cloud project, and this project's service account
   (<project>@appspot.gserviceaccount.com) invited in Play Console → Users and permissions with "View financial data" and "Manage orders". */
exports.verifyPlay = fn.https.onCall(async (data, context) => {
  const auth = needAuth(context);
  const { productId, purchaseToken } = data || {};
  if (!productId || !purchaseToken) throw new functions.https.HttpsError('invalid-argument', 'Missing purchase details.');
  const geo = await lookup(ipOf(context));
  if (geo.vpn) throw new functions.https.HttpsError('failed-precondition', 'vpn');
  const { GoogleAuth } = require('google-auth-library');
  const client = await new GoogleAuth({ scopes: ['https://www.googleapis.com/auth/androidpublisher'] }).getClient();
  const pkg = 'app.finnish.writer';
  const url = 'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/' + pkg + '/purchases/subscriptionsv2/tokens/' + encodeURIComponent(purchaseToken);
  const r = await client.request({ url });
  const s = r.data || {};
  const live = ['SUBSCRIPTION_STATE_ACTIVE', 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD', 'SUBSCRIPTION_STATE_CANCELED'].includes(s.subscriptionState);
  const line = (s.lineItems || [])[0] || {};
  const until = line.expiryTime ? Date.parse(line.expiryTime) : 0;
  if (!live || until < Date.now()) throw new functions.https.HttpsError('failed-precondition', 'This subscription is not active.');
  const plan = /year|annual/i.test(productId) ? 'year' : 'month';
  await db.collection('users').doc(auth.uid).set({ plan, until, store: 'google', productId, lastCheck: Date.now() }, { merge: true });
  return { plan, until };
});
