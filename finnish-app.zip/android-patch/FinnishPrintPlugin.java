package app.finnish.writer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.CancellationSignal;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.provider.Settings;
import java.util.Locale;
import java.util.Set;
import android.speech.tts.Voice;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import org.json.JSONArray;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.OpenableColumns;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResult;
import androidx.webkit.WebViewAssetLoader;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Print-to-PDF, "Save as" dialog and "Open with finnish" support. Creator: Nishan */
@CapacitorPlugin(name = "FinnishPrint")
public class FinnishPrintPlugin extends Plugin {
    private static final String ASSET_BASE = "https://appassets.androidplatform.net/assets/public/";
    private WebView printView;
    static String pendingName, pendingText;
    private OnBackPressedCallback backCb;

    /* System back (button or swipe from either screen edge) goes to the app first; only if the app does not handle it does the system act. */
    @Override
    public void load() {
        try {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    try {
                        backCb = new OnBackPressedCallback(true) {
                            @Override
                            public void handleOnBackPressed() {
                                try {
                                    getBridge().getWebView().evaluateJavascript(
                                        "(function(){try{return window.THK&&THK.backNative?THK.backNative():false}catch(e){return false}})()",
                                        value -> {
                                            if ("true".equals(value)) return;
                                            try {
                                                setEnabled(false);
                                                getActivity().getOnBackPressedDispatcher().onBackPressed();
                                                setEnabled(true);
                                            } catch (Exception e) { setEnabled(true); }
                                        });
                                } catch (Exception e) { }
                            }
                        };
                        getActivity().getOnBackPressedDispatcher().addCallback(getActivity(), backCb);
                    } catch (Exception e) { }
                }
            });
        } catch (Exception e) { }
    }

    /* ---------------------------------------------------------- open files from other apps ("Open with") */
    public static void handleIntent(Context ctx, Intent i) {
        if (i == null || i.getData() == null) return;
        String a = i.getAction();
        if (!Intent.ACTION_VIEW.equals(a) && !Intent.ACTION_EDIT.equals(a)) return;
        Uri u = i.getData();
        if ("app.finnish.writer".equals(u.getScheme())) return; // Google sign-in return link, not a file
        try (InputStream is = ctx.getContentResolver().openInputStream(u)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            String name = null;
            try (Cursor c = ctx.getContentResolver().query(u, null, null, null, null)) {
                if (c != null && c.moveToFirst()) { int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ix >= 0) name = c.getString(ix); }
            } catch (Exception ignored) { }
            if (name == null) { String p = u.getLastPathSegment(); name = p == null ? "script.finnish" : p; }
            pendingName = name;
            pendingText = bo.toString("UTF-8");
        } catch (Exception ignored) { }
    }

    @PluginMethod
    public void setIcon(final PluginCall call) {
        final int pack = call.getInt("pack", 0);
        final Activity act = getActivity();
        try {
            android.content.pm.PackageManager pm = act.getPackageManager();
            String pkg = act.getPackageName();
            for (int i = 0; i <= 8; i++) {
                android.content.ComponentName cn = new android.content.ComponentName(pkg, "app.finnish.writer.alias.P" + i);
                pm.setComponentEnabledSetting(cn, i == pack ? android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED : android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED, android.content.pm.PackageManager.DONT_KILL_APP);
            }
            call.resolve();
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public void sysBars(final PluginCall call) {
        final boolean light = call.getBoolean("light", false);
        final boolean hidden = call.getBoolean("hidden", false);
        final Activity act = getActivity();
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    android.view.Window w = act.getWindow();
                    androidx.core.view.WindowInsetsControllerCompat c = androidx.core.view.WindowCompat.getInsetsController(w, w.getDecorView());
                    c.setAppearanceLightStatusBars(light);
                    if (hidden) {
                        c.setSystemBarsBehavior(androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                        c.hide(androidx.core.view.WindowInsetsCompat.Type.statusBars());
                    } else {
                        c.show(androidx.core.view.WindowInsetsCompat.Type.statusBars());
                    }
                } catch (Exception ignored) { }
                call.resolve();
            }
        });
    }

    @PluginMethod
    public void getPending(PluginCall call) {
        JSObject o = new JSObject();
        if (pendingText != null) { o.put("name", pendingName); o.put("text", pendingText); }
        pendingText = null; pendingName = null;
        call.resolve(o);
    }

    private static PrintAttributes.MediaSize mediaFor(String id, double wmm, double hmm) {
        if ("letter".equals(id)) return PrintAttributes.MediaSize.NA_LETTER;
        if ("legal".equals(id)) return PrintAttributes.MediaSize.NA_LEGAL;
        if ("a5".equals(id)) return PrintAttributes.MediaSize.ISO_A5;
        if ("custom".equals(id)) return new PrintAttributes.MediaSize("custom", "Custom", (int) Math.round(wmm / 25.4 * 1000), (int) Math.round(hmm / 25.4 * 1000));
        return PrintAttributes.MediaSize.ISO_A4;
    }

    @Override protected void handleOnPause() { JSObject o = new JSObject(); o.put("active", false); notifyListeners("appState", o); }
    @Override protected void handleOnResume() { JSObject o = new JSObject(); o.put("active", true); notifyListeners("appState", o); }

    /* ---------------------------------------------------------- voice dictation (system speech recognition screen) */
    @PluginMethod
    public void dictate(PluginCall call) {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        String lg = call.getString("lang", "en-IN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lg);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lg);
        i.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, true);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, call.getString("prompt", "Speak now"));
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try { startActivityForResult(call, i, "dictateResult"); }
        catch (Exception e) { call.reject("Speech recognition is not available on this device"); }
    }

    @ActivityCallback
    private void dictateResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            ArrayList<String> r = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            JSObject o = new JSObject(); o.put("text", (r != null && !r.isEmpty()) ? r.get(0) : ""); call.resolve(o);
        } else call.reject("cancelled");
    }

    /* ---------------------------------------------------------- native read-aloud (Android text-to-speech engine) */
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private void ttsEnsure(final Runnable then) {
        if (tts != null && ttsReady) { then.run(); return; }
        if (tts == null) {
            tts = new TextToSpeech(getContext(), new TextToSpeech.OnInitListener() {
                @Override public void onInit(int status) {
                    ttsReady = status == TextToSpeech.SUCCESS;
                    if (ttsReady) tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override public void onStart(String id) { }
                        @Override public void onDone(String id) { JSObject o = new JSObject(); o.put("id", id); o.put("ok", true); notifyListeners("ttsEnd", o); }
                        @Override public void onError(String id) { JSObject o = new JSObject(); o.put("id", id); o.put("ok", false); notifyListeners("ttsEnd", o); }
                    });
                    then.run();
                }
            });
        } else { new Handler(Looper.getMainLooper()).postDelayed(then, 400); }
    }

    @PluginMethod
    public void ttsLangs(final PluginCall call) {
        final JSONArray tags = new JSONArray();
        try { com.getcapacitor.JSArray a = call.getArray("tags"); for (int i = 0; i < a.length(); i++) tags.put(a.getString(i)); } catch (Exception ignored) { }
        ttsEnsure(new Runnable() { @Override public void run() {
            JSObject o = new JSObject(); o.put("engine", ttsReady);
            JSObject m = new JSObject();
            if (ttsReady) for (int i = 0; i < tags.length(); i++) {
                try { String t = tags.getString(i); int r = tts.isLanguageAvailable(Locale.forLanguageTag(t)); m.put(t, r >= TextToSpeech.LANG_AVAILABLE); } catch (Exception ignored) { }
            }
            o.put("langs", m); call.resolve(o);
        } });
    }

    @PluginMethod
    public void ttsSpeak(final PluginCall call) {
        final String text = call.getString("text", "");
        final String tag = call.getString("lang", "en-IN");
        final String id = call.getString("id", "u");
        final float rate = call.getFloat("rate", 1.0f);
        final float pitch = call.getFloat("pitch", 1.0f);
        ttsEnsure(new Runnable() { @Override public void run() {
            JSObject o = new JSObject();
            if (!ttsReady) { o.put("ok", false); o.put("why", "engine"); call.resolve(o); return; }
            String vn = call.getString("voice", "");
            if (vn != null && vn.length() > 0) { try { Set<Voice> all = tts.getVoices(); if (all != null) for (Voice v : all) if (v.getName().equals(vn)) { tts.setVoice(v); break; } } catch (Exception ignored) { } }
            int r = (vn != null && vn.length() > 0) ? TextToSpeech.SUCCESS : tts.setLanguage(Locale.forLanguageTag(tag));
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) { o.put("ok", false); o.put("why", "lang"); call.resolve(o); return; }
            tts.setSpeechRate(rate); tts.setPitch(pitch);
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
            o.put("ok", true); call.resolve(o);
        } });
    }

    @PluginMethod
    public void ttsVoices(final PluginCall call) {
        final String tag = call.getString("tag", "en-IN");
        ttsEnsure(new Runnable() { @Override public void run() {
            JSONArray arr = new JSONArray();
            try {
                String lang = Locale.forLanguageTag(tag).getLanguage();
                Set<Voice> all = ttsReady ? tts.getVoices() : null;
                if (all != null) for (Voice v : all) {
                    if (!v.getLocale().getLanguage().equals(lang)) continue;
                    org.json.JSONObject o = new org.json.JSONObject();
                    o.put("name", v.getName()); o.put("locale", v.getLocale().toLanguageTag()); o.put("quality", v.getQuality()); o.put("network", v.isNetworkConnectionRequired());
                    o.put("missing", v.getFeatures() != null && v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED));
                    arr.put(o);
                }
            } catch (Exception ignored) { }
            JSObject res = new JSObject(); res.put("voices", arr); call.resolve(res);
        } });
    }

    @PluginMethod
    public void ttsStop(PluginCall call) { try { if (tts != null) tts.stop(); } catch (Exception ignored) { } call.resolve(); }

    @PluginMethod
    public void ttsSettings(PluginCall call) {
        Intent i = new Intent("com.android.settings.TTS_SETTINGS");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { getContext().startActivity(i); }
        catch (Exception e) {
            try { Intent j = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA); j.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(j); }
            catch (Exception e2) { try { Intent k = new Intent(Settings.ACTION_SETTINGS); k.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(k); } catch (Exception ignored) { } }
        }
        call.resolve();
    }

    /* ---------------------------------------------------------- fingerprint / face unlock (system prompt, no extra libraries) */
    @PluginMethod
    public void bioAvailable(PluginCall call) {
        boolean ok = false;
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                BiometricManager bm = getContext().getSystemService(BiometricManager.class);
                ok = bm != null && bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS;
            } else if (Build.VERSION.SDK_INT >= 29) {
                BiometricManager bm = getContext().getSystemService(BiometricManager.class);
                ok = bm != null && bm.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
            } else if (Build.VERSION.SDK_INT >= 28) {
                ok = getContext().getPackageManager().hasSystemFeature(PackageManager.FEATURE_FINGERPRINT);
            }
        } catch (Exception ignored) { }
        JSObject o = new JSObject();
        o.put("ok", ok);
        call.resolve(o);
    }

    @PluginMethod
    public void bioAuth(final PluginCall call) {
        if (Build.VERSION.SDK_INT < 28) { call.reject("Not supported on this Android version"); return; }
        final Activity a = getActivity();
        final String title = call.getString("title", "Unlock finnish");
        final String neg = call.getString("cancel", "Use password");
        a.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    BiometricPrompt.Builder b = new BiometricPrompt.Builder(a).setTitle(title);
                    if (Build.VERSION.SDK_INT >= 30) b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
                    b.setNegativeButton(neg, a.getMainExecutor(), new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { call.reject("cancelled"); }
                    });
                    b.build().authenticate(new CancellationSignal(), a.getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                        @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { JSObject o = new JSObject(); o.put("ok", true); call.resolve(o); }
                        @Override public void onAuthenticationError(int code, CharSequence msg) { call.reject(String.valueOf(msg)); }
                    });
                } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
            }
        });
    }

    /* ---------------------------------------------------------- print / save as PDF */
    @PluginMethod
    public void print(final PluginCall call) {
        final String html0 = call.getString("html", "");
        final String name = call.getString("name", "script");
        final String paperId = call.getString("paper", "a4");
        final double wmm = call.getDouble("wmm", 210.0), hmm = call.getDouble("hmm", 297.0);
        final String html = html0.replace("<base href=\"https://localhost/\">", "<base href=\"" + ASSET_BASE + "\">");
        getActivity().runOnUiThread(() -> {
            try {
                final Activity act = getActivity();
                final ViewGroup root = (ViewGroup) act.getWindow().getDecorView();
                if (printView != null) { root.removeView(printView); printView.destroy(); printView = null; }
                final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(getContext())).build();
                final WebView wv = new WebView(act);
                printView = wv;
                wv.setAlpha(0.01f);
                root.addView(wv, new FrameLayout.LayoutParams(2, 2)); // must be attached to a window to render and print
                final boolean[] done = { false };
                final Runnable go = () -> {
                    if (done[0]) return;
                    done[0] = true;
                    try {
                        PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
                        PrintDocumentAdapter adapter = wv.createPrintDocumentAdapter(name);
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(mediaFor(paperId, wmm, hmm))
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
                        pm.print(name, adapter, attrs);
                        call.resolve(new JSObject());
                    } catch (Exception e) { call.reject("Print failed: " + e.getMessage()); }
                };
                wv.setWebViewClient(new WebViewClient() {
                    @Override
                    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                        return loader.shouldInterceptRequest(request.getUrl());
                    }

                    @Override
                    public void onPageFinished(WebView view, String url) {
                        new Handler(Looper.getMainLooper()).postDelayed(go, 900);
                    }
                });
                new Handler(Looper.getMainLooper()).postDelayed(go, 7000); // safety net if the page never reports "finished"
                wv.loadDataWithBaseURL(ASSET_BASE, html, "text/html", "UTF-8", null);
            } catch (Exception e) { call.reject("Print failed: " + e.getMessage()); }
        });
    }

    /* ---------------------------------------------------------- system "Save as" dialog */
    @PluginMethod
    public void saveFile(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(call.getString("mime", "application/octet-stream"));
        i.putExtra(Intent.EXTRA_TITLE, call.getString("name", "file"));
        startActivityForResult(call, i, "saveResult");
    }

    @ActivityCallback
    private void saveResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) { call.reject("cancelled"); return; }
        Uri uri = result.getData().getData();
        try (OutputStream os = getContext().getContentResolver().openOutputStream(uri, "wt")) {
            String dat = call.getString("data", "");
            os.write(call.getBoolean("b64", false) ? android.util.Base64.decode(dat, android.util.Base64.DEFAULT) : dat.getBytes("UTF-8"));
            JSObject o = new JSObject(); o.put("uri", uri.toString()); call.resolve(o);
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    /* ---------------------------------------------------------- chunked save (big files: backups with many pictures) */
    private OutputStream chunkOs = null;

    @PluginMethod
    public void saveBegin(PluginCall call) {
        try { if (chunkOs != null) { chunkOs.close(); } } catch (Exception e) { }
        chunkOs = null;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(call.getString("mime", "application/octet-stream"));
        i.putExtra(Intent.EXTRA_TITLE, call.getString("name", "file"));
        startActivityForResult(call, i, "beginResult");
    }

    @ActivityCallback
    private void beginResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) { call.reject("cancelled"); return; }
        try {
            Uri uri = result.getData().getData();
            chunkOs = getContext().getContentResolver().openOutputStream(uri, "wt");
            JSObject o = new JSObject(); o.put("uri", uri.toString()); call.resolve(o);
        } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }

    @PluginMethod
    public synchronized void saveChunk(PluginCall call) {
        if (chunkOs == null) { call.reject("No file is open"); return; }
        try {
            byte[] b = android.util.Base64.decode(call.getString("data", ""), android.util.Base64.DEFAULT);
            chunkOs.write(b);
            call.resolve();
        } catch (Throwable e) {
            try { chunkOs.close(); } catch (Exception x) { }
            chunkOs = null; call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public synchronized void saveEnd(PluginCall call) {
        try { if (chunkOs != null) { chunkOs.flush(); chunkOs.close(); } } catch (Exception e) { }
        chunkOs = null; call.resolve();
    }

    @PluginMethod
    public void exitApp(PluginCall call) {
        try { getActivity().moveTaskToBack(true); } catch (Exception e) { }
        call.resolve();
    }
}
