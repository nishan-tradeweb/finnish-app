// finnish – desktop shell (Windows and Mac). Creator: Nishan
const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os'), http = require('http'), crypto = require('crypto');

function createWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 860, minWidth: 420, minHeight: 600, backgroundColor: '#dfe9f7', title: 'finnish',
    icon: path.join(__dirname, '..', 'build', process.platform === 'win32' ? 'icon.ico' : 'icon.png'), autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, spellcheck: false }
  });
  win.loadFile(path.join(__dirname, '..', 'www', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}

ipcMain.handle('pdf', async (e, html, name, size) => {
  const tmp = path.join(os.tmpdir(), 'finnish-print-' + Date.now() + '.html');
  fs.writeFileSync(tmp, html, 'utf8');
  const w = new BrowserWindow({ show: false, webPreferences: { offscreen: false } });
  try {
    await w.loadFile(tmp);
    await w.webContents.executeJavaScript('document.fonts.ready.then(()=>true)');
    await new Promise(r => setTimeout(r, 400));
    const data = await w.webContents.printToPDF({ preferCSSPageSize: true, printBackground: true });
    const r = await dialog.showSaveDialog({ defaultPath: name, filters: [{ name: 'PDF', extensions: ['pdf'] }] });
    if (r.canceled || !r.filePath) return null;
    fs.writeFileSync(r.filePath, data); shell.showItemInFolder(r.filePath); return r.filePath;
  } finally { w.destroy(); try { fs.unlinkSync(tmp); } catch (x) { } }
});
ipcMain.handle('saveFile', async (e, name, text, existing) => {
  let p = existing;
  if (!p || !fs.existsSync(path.dirname(p))) {
    const r = await dialog.showSaveDialog({ defaultPath: name, filters: [{ name: 'finnish script', extensions: ['finnish'] }] });
    if (r.canceled || !r.filePath) return null; p = r.filePath;
  }
  fs.writeFileSync(p, text, 'utf8'); return p;
});
ipcMain.handle('saveText', async (e, name, text, b64) => {
  const ext = path.extname(name).slice(1) || 'txt';
  const r = await dialog.showSaveDialog({ defaultPath: name, filters: [{ name: ext.toUpperCase(), extensions: [ext] }] });
  if (r.canceled || !r.filePath) return null; fs.writeFileSync(r.filePath, b64 ? Buffer.from(text, 'base64') : text, b64 ? undefined : 'utf8'); return r.filePath;
});

/* Google sign-in / Drive: system browser + PKCE + local return address (Google's recommended way for desktop apps) */
ipcMain.handle('googleAuth', (e, scope, clientId, secret) => new Promise((resolve) => {
  const verifier = crypto.randomBytes(48).toString('base64url');
  const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
  const state = crypto.randomBytes(12).toString('hex');
  let redirect = '', done = false;
  const finish = (v) => { if (done) return; done = true; try { srv.close(); } catch (x) { } resolve(v); };
  const srv = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://127.0.0.1');
    if (u.pathname !== '/cb') { res.statusCode = 404; res.end(); return; }
    const code = u.searchParams.get('code'), ok = code && u.searchParams.get('state') === state;
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end('<!doctype html><meta charset="utf-8"><title>finnish</title><body style="font-family:system-ui;text-align:center;padding:60px"><h2>' + (ok ? 'Done. You can close this tab and return to finnish.' : 'Sign-in was cancelled. You can close this tab.') + '</h2></body>');
    if (!ok) return finish(null);
    try {
      const body = new URLSearchParams({ client_id: clientId, code, code_verifier: verifier, grant_type: 'authorization_code', redirect_uri: redirect });
      if (secret) body.set('client_secret', secret);
      const r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body });
      const j = await r.json(); finish(j.access_token || null);
    } catch (x) { finish(null); }
    BrowserWindow.getAllWindows().forEach(w => { try { w.show(); w.focus(); } catch (x) { } });
  });
  srv.listen(0, '127.0.0.1', () => {
    redirect = 'http://127.0.0.1:' + srv.address().port + '/cb';
    const q = new URLSearchParams({ client_id: clientId, redirect_uri: redirect, response_type: 'code', scope, state, code_challenge: challenge, code_challenge_method: 'S256', prompt: 'select_account' });
    shell.openExternal('https://accounts.google.com/o/oauth2/v2/auth?' + q.toString());
  });
  setTimeout(() => finish(null), 180000);
}));

app.whenReady().then(() => { Menu.setApplicationMenu(process.platform === 'darwin' ? Menu.buildFromTemplate([{ role: 'appMenu' }, { role: 'editMenu' }, { role: 'viewMenu' }, { role: 'windowMenu' }]) : null); createWindow(); app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
