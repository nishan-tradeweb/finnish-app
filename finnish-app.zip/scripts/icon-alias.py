import re
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
if 'alias.P1' not in s:
    s = re.sub(r'\s*<intent-filter>\s*<action android:name="android.intent.action.MAIN"\s*/>\s*<category android:name="android.intent.category.LAUNCHER"\s*/>\s*</intent-filter>', '', s, count=1)
    T = ('\n        <activity-alias android:name="app.finnish.writer.alias.P%d" android:targetActivity="app.finnish.writer.MainActivity"'
         ' android:enabled="%s" android:exported="true" android:icon="%s" android:roundIcon="%s" android:label="@string/app_name">\n'
         '            <intent-filter>\n                <action android:name="android.intent.action.MAIN" />\n'
         '                <category android:name="android.intent.category.LAUNCHER" />\n            </intent-filter>\n        </activity-alias>\n')
    al = ''
    for i in range(0, 9):
        ic = '@mipmap/ic_launcher' if i == 0 else '@mipmap/ic_p%d' % i
        rd = '@mipmap/ic_launcher_round' if i == 0 else '@mipmap/ic_p%d_round' % i
        al += T % (i, 'true' if i == 0 else 'false', ic, rd)
    s = s.replace('</application>', al + '    </application>', 1)
    open(p, 'w', encoding='utf-8').write(s)
print('icon aliases added')
