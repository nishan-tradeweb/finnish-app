#!/usr/bin/env bash
# Runs after "npx cap add android": native helper, "Open with", Google sign-in return link, release signing and version numbers.
set -euo pipefail
PKG_DIR=android/app/src/main/java/app/finnish/writer
mkdir -p "$PKG_DIR"
cp android-patch/MainActivity.java "$PKG_DIR/MainActivity.java"
cp android-patch/FinnishPrintPlugin.java "$PKG_DIR/FinnishPrintPlugin.java"
# androidx.webkit is needed by the print plugin
if ! grep -q "androidx.webkit" android/app/build.gradle; then
  sed -i 's#dependencies {#dependencies {\n    implementation "androidx.webkit:webkit:1.12.1"#' android/app/build.gradle
fi
VNAME="${FINNISH_VERSION:-1.0.0}"
VCODE="${FINNISH_VERSION_CODE:-1}"
sed -i "s/versionName \".*\"/versionName \"$VNAME\"/" android/app/build.gradle
sed -i "s/versionCode [0-9]*/versionCode $VCODE/" android/app/build.gradle
# release signing: the SAME key every build, so a new build installs over the old one and keeps the user's scripts
if [ -n "${ANDROID_KEYSTORE_B64:-}" ]; then
  echo "$ANDROID_KEYSTORE_B64" | base64 -d > android/app/finnish-release.jks
  python3 - <<'PY'
p = 'android/app/build.gradle'
s = open(p, encoding='utf-8').read()
if 'finnishRelease' not in s:
    sc = '''
    signingConfigs {
        finnishRelease {
            storeFile file("finnish-release.jks")
            storePassword System.getenv("ANDROID_KEYSTORE_PASSWORD")
            keyAlias System.getenv("ANDROID_KEY_ALIAS")
            keyPassword System.getenv("ANDROID_KEY_PASSWORD")
        }
    }
'''
    lint = '''
    lint {
        checkReleaseBuilds false
        abortOnError false
    }
'''
    s = s.replace('android {', 'android {' + sc + lint, 1)
    s = s.replace('buildTypes {', 'buildTypes {', 1)
    s = s.replace('release {', 'release {\n            signingConfig signingConfigs.finnishRelease', 1)
    open(p, 'w', encoding='utf-8').write(s)
print('release signing configured')
PY
else
  echo "ERROR: ANDROID_KEYSTORE_B64 secret is missing - a release build must be signed with your key." >&2; exit 1
fi
# "Open with finnish" for .finnish / .fdx / .fountain / .screenplay files
python3 - <<'PY'
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
for perm in ('VIBRATE', 'RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS'):
    if perm not in s:
        s = s.replace('<application', '<uses-permission android:name="android.permission.%s" />\n    <application' % perm, 1)
        open(p, 'w', encoding='utf-8').write(s)
if 'USE_BIOMETRIC' not in s:
    s = s.replace('<application', '<uses-permission android:name="android.permission.USE_BIOMETRIC" />\n    <application', 1)
    open(p, 'w', encoding='utf-8').write(s)
if 'TTS_SERVICE' not in s:
    s = s.replace('<application', '<queries><intent><action android:name="android.intent.action.TTS_SERVICE" /></intent></queries>\n    <application', 1)
    open(p, 'w', encoding='utf-8').write(s)
if 'RECOGNIZE_SPEECH' not in s:
    s = s.replace('<application', '<queries><intent><action android:name="android.speech.action.RECOGNIZE_SPEECH" /></intent></queries>\n    <application', 1)
    open(p, 'w', encoding='utf-8').write(s)
if 'finnish-oauth' not in s:
    o = '''
            <!-- finnish-oauth: Google sign-in returns here -->
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="app.finnish.writer" />
            </intent-filter>
'''
    s = s.replace('</activity>', o + '        </activity>', 1)
    open(p, 'w', encoding='utf-8').write(s)
if 'finnish-open-with' not in s:
    f = '''
            <!-- finnish-open-with -->
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="content" />
                <data android:scheme="file" />
                <data android:mimeType="application/octet-stream" />
                <data android:mimeType="application/json" />
                <data android:mimeType="application/xml" />
                <data android:mimeType="text/xml" />
                <data android:mimeType="text/plain" />
                <data android:mimeType="text/*" />
                <data android:mimeType="application/x-finnish" />
            </intent-filter>
'''
    s = s.replace('</activity>', f + '        </activity>', 1)
    open(p, 'w', encoding='utf-8').write(s)
print('manifest patched')
PY
# icon packs: resources + one launcher alias per pack (switchable from the Theme window)
cp -R android-patch/res/. android/app/src/main/res/
python3 scripts/icon-alias.py
echo "Android patch applied."
