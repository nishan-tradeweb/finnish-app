/* Scene numbers – automatic 1,2,3 … plus sub-scenes (1A, 1.1, 1-1), custom numbers and locked numbers.
   Stored as: block.sn (custom text) · block.sub (sub-scene of the scene before) · doc.snStyle ('A'|'dot'|'dash') · doc.snLock.
   The numbering itself (THK.sceneNums) lives in export.js so every export, the breakdown and the schedule use the same numbers. */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, SN = THK.sn = {};
  var A = function () { return THK.app; };
  function el(t, c, h) { return A().el(t, c, h); }
  function doc() { return A().cur; }
  function scenesOf(d) { return d.blocks.filter(function (b) { return b.t === 'scene'; }); }
  function curScene() { var d = doc(), cb = A().cb; if (!d) return null; var i = cb ? d.blocks.indexOf(cb) : -1; if (i < 0) i = 0; for (var k = i; k >= 0; k--) if (d.blocks[k].t === 'scene') return d.blocks[k]; return scenesOf(d)[0] || null; }
  function headOf(b) { return (THK.stripSn ? THK.stripSn(b.x || '') : (b.x || '')).replace(/\s+/g, ' ').trim() || 'Untitled scene'; }

  /* numbers in the editor margin follow the same rules */
  var T = 0;
  SN.paint = function () {
    var d = doc(); if (!d) return; var m = THK.sceneNums(d);
    [].forEach.call(document.querySelectorAll('#page .b.scene'), function (e) { var v = m[e.dataset.id]; if (v != null) { if (e.dataset.sn !== v) e.dataset.sn = v; } else if (e.dataset.sn) delete e.dataset.sn; });
  };
  function soon() { clearTimeout(T); T = setTimeout(SN.paint, 60); }
  function watch() { var pg = document.getElementById('page'); if (!pg) return setTimeout(watch, 500); new MutationObserver(soon).observe(pg, { childList: true }); soon(); }

  SN.open = function () {
    var d = doc(); if (!d) return A().toast('Open a script first'); var A1 = A(), sc = curScene(); if (!scenesOf(d).length) return A1.toast('Add a scene heading first');
    var body = el('div', 'xdlg'), info = el('p', '', ''); body.appendChild(info);
    var mode = el('div', 'xrow'), custom = el('input', 't'); custom.placeholder = 'e.g. 12A, 3.1, S-7'; custom.maxLength = 8;
    var shown = el('div', 'snnow'); body.appendChild(shown);
    function pill(l, on, fn, t) { var b = A1.btn(l, fn, on ? 'on' : '', t); return b; }
    function save() { A1.persist && A1.persist(); A1.dirty(); SN.paint(); draw(); }
    function label() { return THK.sceneNums(d)[sc.id]; }
    function draw() {
      var m = THK.sceneNums(d), isC = !!(sc.sn && String(sc.sn).trim()), isS = !!sc.sub && !isC;
      shown.innerHTML = ''; shown.appendChild(el('b', '', 'Scene ' + m[sc.id])); shown.appendChild(el('span', '', ' · ' + headOf(sc)));
      mode.innerHTML = '';
      mode.appendChild(pill('Automatic', !isC && !isS && !d.snLock, function () { delete sc.sn; delete sc.sub; save(); }, 'Numbered in order: 1, 2, 3 …'));
      mode.appendChild(pill('Sub-scene', isS || (!isC && d.snLock), function () { delete sc.sn; sc.sub = true; save(); }, 'Belongs to the scene before it, e.g. 4A'));
      mode.appendChild(pill('Custom', isC, function () { custom.hidden = false; custom.focus(); }, 'Type any number you like'));
      custom.hidden = !isC && custom.hidden !== false ? true : custom.hidden; if (isC) custom.hidden = false; custom.value = isC ? sc.sn : custom.value;
      var any = scenesOf(d).some(function (b) { return b.sn || b.sub; });
      lockB.textContent = d.snLock ? 'Numbers locked – tap to unlock' : 'Lock all numbers';
      lockB.classList.toggle('on', !!d.snLock); resetB.hidden = !any && !d.snLock;
      [].forEach.call(sty.querySelectorAll('[data-s]'), function (b) { b.classList.toggle('on', (d.snStyle || 'A') === b.dataset.s); });
    }
    info.innerHTML = 'Scenes are numbered <b>1, 2, 3…</b> by themselves. A scene you add later, in between, can be a <b>sub-scene</b> (4A, 4B…) so the other numbers do not move – this is how production scripts stay in step with the schedule.';
    body.appendChild(el('div', 'xsubh', 'This scene')); body.appendChild(mode);
    custom.hidden = true; custom.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); custom.onchange(); } };
    custom.onchange = function () { var v = custom.value.trim().replace(/\s+/g, ''); if (!v) { delete sc.sn; } else { sc.sn = v; delete sc.sub; } save(); };
    body.appendChild(custom);
    body.appendChild(el('div', 'xsubh', 'Sub-scene style'));
    var sty = el('div', 'xrow'); [['A', '4A  4B'], ['dot', '4.1  4.2'], ['dash', '4-1  4-2']].forEach(function (s) { var b = A1.btn(s[1], function () { d.snStyle = s[0]; save(); }, ''); b.dataset.s = s[0]; sty.appendChild(b); }); body.appendChild(sty);
    body.appendChild(el('div', 'xsubh', 'Whole script'));
    var lockB = A1.btn('Lock all numbers', function () {
      if (d.snLock) { d.snLock = false; save(); return A1.toast('Unlocked – new scenes get the next number'); }
      var m = THK.sceneNums(d); scenesOf(d).forEach(function (b) { b.sn = m[b.id]; delete b.sub; }); d.snLock = true; save(); A1.toast('Numbers locked – scenes you add later become 4A, 4B…');
    }, '', 'Freeze the current numbers; scenes added later become sub-scenes');
    var resetB = A1.btn('Renumber everything 1, 2, 3…', function () {
      A1.confirmD('Renumber all scenes?', 'Custom and sub-scene numbers are removed and every scene is numbered 1, 2, 3 again.', function () { scenesOf(d).forEach(function (b) { delete b.sn; delete b.sub; }); d.snLock = false; save(); A1.toast('Renumbered'); }, 'Renumber');
    }, ''); var r2 = el('div', 'xrow'); r2.appendChild(lockB); r2.appendChild(resetB); body.appendChild(r2);
    body.appendChild(el('p', 'xnote', 'Planning the shoot: every sub-scene is its own line in the breakdown, shot list and schedule, with its own number, location, time of day and page length. Pick it up with its parent scene or on another day – the schedule groups by location, so 4A stays next to 4.'));
    draw();
    A1.dlg('Scene numbers', body, [{ l: 'Done', cls: 'pri', fn: function () { SN.paint(); } }]);
  };

  var st = document.createElement('style'); st.textContent =
    '#page .b.scene[data-sn]::before,#nPage .b.scene[data-sn]::before{content:attr(data-sn)}' +
    '.xdlg .xrow{display:flex;flex-wrap:wrap;gap:6px}.xdlg .xsubh{font-size:.78em;letter-spacing:.05em;text-transform:uppercase;color:var(--ink2);margin:6px 4px 0}.xdlg .xnote{font-size:.85em}.snnow{padding:8px 12px;border-radius:16px;background:var(--glass2,var(--glass));border:1px solid var(--edge);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.snnow span{color:var(--ink2)}.xdlg .btn.on{background:var(--acc);color:var(--onacc,#fff)}';
  document.head.appendChild(st);
  watch();
})();
