/* finnish – Dynamic Themes registry (source of truth) and style generator.
   27 themes in four experiences: Sculpted (10: 5 light + 5 dark), Material (6), Atmosphere (7), Experimental (4).
   Sculpted themes are PALETTES of one shared sculpted construction (sculpt()); the others are built from surface recipes (mat()).
   The generated tokens feed the shared component map in dyn.css, so no stylesheet is duplicated per theme.
   Registry item: id, name, family (value of html[data-dyn]), group, sub, dark, desc, prev (picker preview css), tok (css variables), extra (small local css). */
(function () {
  'use strict';
  var T = (window.THK = window.THK || {}).themes = {};

  /* ---------- colour helpers ---------- */
  function rgb(h) { h = h.replace('#', ''); if (h.length === 3) h = h.replace(/./g, '$&$&'); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; }
  function hex(a) { return '#' + a.map(function (v) { v = Math.max(0, Math.min(255, Math.round(v))); return (v < 16 ? '0' : '') + v.toString(16); }).join(''); }
  function mix(a, b, t) { var x = rgb(a), y = rgb(b); return hex([0, 1, 2].map(function (i) { return x[i] + (y[i] - x[i]) * t; })); }
  function lum(h) { var c = rgb(h).map(function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }
  T.contrast = function (a, b) { var l1 = lum(a), l2 = lum(b); return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05); };
  var rg = function (h, a) { var c = rgb(h); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; };

  /* ---------- Sculpted: one construction, many palettes ---------- */
  function sculpt(p) {
    var dark = !!p.dark, base = p.base, lift = dark ? mix(base, '#ffffff', .045) : mix(base, '#ffffff', .35), drop = dark ? mix(base, '#000000', .22) : mix(base, '#000000', .04);
    var sh = p.sh, hi = p.hi, k = {};
    k['--dk'] = p.ink; k['--dk2'] = p.ink2; k['--page-c'] = base; k['--dng'] = p.dng || (dark ? '#ff7a70' : '#b8322a');
    k['--page-bg'] = dark ? 'radial-gradient(90% 55% at 18% 0,' + rg(p.glow || '#ffffff', .075) + ',transparent 70%),' + base : base;
    k['--OV-bg'] = rg(dark ? mix(base, '#000000', .35) : mix(base, '#000000', .03), .97); k['--CINE-bg'] = dark ? mix(base, '#000000', .3) : mix(base, '#000000', .06);
    k['--edgeC'] = dark ? 'rgba(255,255,255,.10)' : rg(hi, .7); k['--edge2C'] = dark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.09)';
    k['--scrimC'] = dark ? 'rgba(0,0,0,.6)' : rg(mix(p.ink, base, .3), .3); k['--hov'] = dark ? 'rgba(255,255,255,.07)' : 'rgba(0,0,0,.05)';
    k['--S-bg-flat'] = base; k['--L-bg-flat'] = dark ? mix(base, '#000000', .12) : mix(base, '#ffffff', .25);
    if (dark) {
      k['--L-bg'] = 'linear-gradient(145deg,' + lift + ',' + mix(base, '#000000', .1) + ')'; k['--L-bd'] = '1px solid rgba(255,255,255,.045)';
      k['--L-sh'] = '12px 12px 28px ' + rg(sh, .62) + ',-9px -9px 22px ' + rg(hi, .065) + ',inset 0 1px 0 rgba(255,255,255,.04)';
      k['--S-bg'] = 'linear-gradient(145deg,' + mix(base, '#ffffff', .075) + ',' + mix(base, '#000000', .06) + ')'; k['--S-bd'] = '1px solid rgba(255,255,255,.05)';
      k['--S-sh'] = '5px 5px 12px ' + rg(sh, .62) + ',-4px -4px 10px ' + rg(hi, .06);
      k['--P-bg'] = mix(base, '#000000', .2); k['--P-bd'] = '1px solid rgba(0,0,0,.25)'; k['--P-sh'] = 'inset 4px 4px 9px ' + rg(sh, .75) + ',inset -3px -3px 8px ' + rg(hi, .055);
    } else {
      k['--L-bg'] = base; k['--L-bd'] = '1px solid ' + rg(hi, .55); k['--L-sh'] = '11px 11px 26px ' + rg(sh, .52) + ',-11px -11px 26px ' + rg(hi, .95);
      k['--S-bg'] = 'linear-gradient(145deg,' + lift + ',' + drop + ')'; k['--S-bd'] = '1px solid ' + rg(hi, .5); k['--S-sh'] = '5px 5px 12px ' + rg(sh, .55) + ',-5px -5px 12px ' + rg(hi, .95);
      k['--P-bg'] = mix(base, '#000000', .015); k['--P-bd'] = '1px solid rgba(0,0,0,.02)'; k['--P-sh'] = 'inset 4px 4px 9px ' + rg(sh, .55) + ',inset -4px -4px 9px ' + rg(hi, .95);
    }
    var s0 = p.sel[0], s1 = p.sel[1]; k['--ON-bg'] = 'linear-gradient(' + (dark ? '180deg' : '145deg') + ',' + s0 + ',' + s1 + ')'; k['--ON-c'] = p.selC; k['--ON-bd'] = '1px solid ' + (dark ? 'transparent' : 'rgba(0,0,0,.25)');
    k['--ON-sh'] = dark ? '0 4px 14px rgba(0,0,0,.45),0 0 0 1px rgba(255,255,255,.04)' : '3px 3px 9px ' + rg(sh, .5) + ',inset 0 1px 0 rgba(255,255,255,.14)';
    k['--PRI-bg'] = k['--ON-bg']; k['--PRI-c'] = p.selC; k['--PRI-sh'] = dark ? '0 4px 14px rgba(0,0,0,.45)' : '5px 5px 12px ' + rg(sh, .55) + ',-4px -4px 10px ' + rg(hi, .9);
    k['--SEL-bg'] = k['--ON-bg']; k['--SEL-c'] = p.selC; k['--SEL-solid'] = s0; k['--SELS-c'] = p.selSub || mix(p.selC, s0, .35);
    k['--FOCUS'] = p.ink;
    return k;
  }
  function sprev(p) { var b = p.base, sh = p.dark ? rg(p.sh, .8) : rg(p.sh, .6), hi = p.dark ? rg(p.hi, .12) : rg(p.hi, .95); return 'background:' + b + ';box-shadow:inset 4px 4px 8px ' + sh + ',inset -4px -4px 8px ' + hi; }

  /* ---------- Material / Atmosphere / Experimental: surface recipes ---------- */
  function mat(p) {
    var k = {}, d = !!p.dark;
    k['--dk'] = p.ink; k['--dk2'] = p.ink2; k['--page-c'] = p.page; k['--page-bg'] = p.pageBg || p.page; k['--dng'] = p.dng || (d ? '#ff8078' : '#b3261e');
    k['--OV-bg'] = rg(mix(p.page, d ? '#000000' : '#ffffff', .25), .97); k['--CINE-bg'] = p.page;
    k['--edgeC'] = p.line; k['--edge2C'] = p.line2 || p.line; k['--scrimC'] = p.scrim || (d ? 'rgba(0,0,0,.62)' : 'rgba(40,40,50,.32)'); k['--hov'] = d ? 'rgba(255,255,255,.07)' : 'rgba(0,0,0,.06)';
    k['--S-bg-flat'] = p.small[0]; k['--L-bg-flat'] = p.card[0];
    k['--L-bg'] = 'linear-gradient(' + (p.ang || '160deg') + ',' + p.card[0] + ',' + p.card[1] + ')'; k['--L-bd'] = '1px solid ' + p.line; k['--L-sh'] = p.lsh || ('0 14px 34px ' + p.shadow + ',inset 0 1px 0 ' + p.hi);
    k['--S-bg'] = 'linear-gradient(' + (p.ang || '160deg') + ',' + p.small[0] + ',' + p.small[1] + ')'; k['--S-bd'] = '1px solid ' + p.line; k['--S-sh'] = p.ssh || ('inset 0 1px 0 ' + p.hi + ',0 3px 8px ' + p.shadow);
    k['--P-bg'] = p.well; k['--P-bd'] = '1px solid ' + (p.wellLine || p.line); k['--P-sh'] = p.psh || ('inset 0 2px 7px ' + p.shadow);
    k['--ON-bg'] = 'linear-gradient(180deg,' + p.sel[0] + ',' + p.sel[1] + ')'; k['--ON-c'] = p.selC; k['--ON-bd'] = '1px solid transparent'; k['--ON-sh'] = p.onsh || ('0 4px 14px ' + p.shadow);
    k['--PRI-bg'] = p.pri ? 'linear-gradient(180deg,' + p.pri[0] + ',' + p.pri[1] + ')' : k['--ON-bg']; k['--PRI-c'] = p.priC || p.selC; k['--PRI-sh'] = k['--ON-sh'];
    k['--SEL-bg'] = k['--ON-bg']; k['--SEL-c'] = p.selC; k['--SEL-solid'] = p.sel[0]; k['--SELS-c'] = p.selSub || mix(p.selC, p.sel[0], .35); k['--FOCUS'] = p.focus || p.ink;
    return k;
  }

  var L = [];
  function add(o) { o.prev = o.prev || ''; L.push(o); }
  var SC = 'Sculpted', LI = 'Light', DK = 'Dark';
  /* ---- Sculpted · Light ---- */
  [['dyn-white', 'Matte White', 'white', { base: '#e6e7e9', sh: '#969aa3', hi: '#ffffff', ink: '#18191c', ink2: '#5a5d65', sel: ['#33353a', '#17181b'], selC: '#f6f6f7' }, 'Soft sculpted surfaces that press in'],
   ['dyn-porcelain', 'Porcelain', 'porcelain', { base: '#efe8dc', sh: '#b0a08a', hi: '#fffcf4', ink: '#2a251e', ink2: '#645b4d', sel: ['#4a4036', '#2c251d'], selC: '#faf5ea' }, 'Warm ivory with warm-grey shadows'],
   ['dyn-lavender', 'Lavender Mist', 'lavender', { base: '#e5e1f1', sh: '#9a8fbd', hi: '#fbf9ff', ink: '#231f35', ink2: '#5d5679', sel: ['#4a3f78', '#2e2550'], selC: '#f7f4ff' }, 'Pale lilac with cool violet shadows'],
   ['dyn-sage', 'Sage', 'sage', { base: '#dfe6dc', sh: '#8a9f8a', hi: '#f6fcf3', ink: '#1d2a20', ink2: '#506055', sel: ['#3f5a45', '#26382b'], selC: '#f2faf1' }, 'Muted botanical green, natural shadows'],
   ['dyn-champagne', 'Champagne', 'champagne', { base: '#ece0cc', sh: '#a8926f', hi: '#fff8ea', ink: '#2d2415', ink2: '#66583f', sel: ['#5b4a2c', '#3a2e18'], selC: '#fbf3e2' }, 'Warm beige with a golden undertone']
  ].forEach(function (a) { var p = a[3]; p.dark = 0; add({ id: a[0], name: a[1], family: a[2], group: SC, sub: LI, dark: 0, desc: a[4], prev: sprev(p), tok: sculpt(p) }); });
  /* ---- Sculpted · Dark (Matte Black rebuilt as the dark twin of Matte White) ---- */
  [['dyn-black', 'Matte Black', 'black', { base: '#1c1d20', sh: '#000000', hi: '#ffffff', glow: '#ffffff', ink: '#f2f2f4', ink2: '#a9abb3', sel: ['#f4f4f6', '#d0d1d6'], selC: '#0b0b0d' }, 'Premium graphite, raised and recessed'],
   ['dyn-midnightblue', 'Midnight Blue', 'midnightblue', { base: '#131b2f', sh: '#02060f', hi: '#7fa6ff', glow: '#7fa6ff', ink: '#e8eefc', ink2: '#9fb0d2', sel: ['#e6edff', '#b9c9ef'], selC: '#0a1224' }, 'Deep navy with quiet blue light'],
   ['dyn-burgundy', 'Burgundy', 'burgundy', { base: '#2a1219', sh: '#0e0205', hi: '#ff7a88', glow: '#ff7a88', ink: '#f8eaed', ink2: '#cba5ad', sel: ['#f8e1e5', '#e0b3bb'], selC: '#2a0d14' }, 'Deep wine with muted red highlights'],
   ['dyn-amethyst', 'Amethyst', 'amethyst', { base: '#241731', sh: '#0b0314', hi: '#b98cff', glow: '#b98cff', ink: '#f2eafb', ink2: '#bba8d4', sel: ['#ecdfff', '#cbb5ee'], selC: '#1b0f2b' }, 'Deep plum with restrained violet'],
   ['dyn-water', 'Dark Water', 'water', { base: '#0d1f29', sh: '#01080c', hi: '#74d6ff', glow: '#74d6ff', ink: '#e6f5fb', ink2: '#9dbccb', sel: ['#e2f4fb', '#b4d5e4'], selC: '#06161d' }, 'Sculpted deep water – touch the background to make ripples'],
   ['dyn-graphite', 'Graphite', 'graphite', { base: '#27292c', sh: '#000000', hi: '#ffffff', glow: '#ffffff', ink: '#ededef', ink2: '#abaeb3', sel: ['#ededef', '#c4c6ca'], selC: '#0e0f10' }, 'Neutral charcoal, understated light']
  ].forEach(function (a) { var p = a[3]; p.dark = 1; add({ id: a[0], name: a[1], family: a[2], group: SC, sub: DK, dark: 1, desc: a[4], prev: sprev(p), tok: sculpt(p) }); });

  /* ---- Material ---- */
  var MT = 'Material', AT = 'Atmosphere', EX = 'Experimental';
  add({ id: 'dyn-crystal', name: 'Frosted Crystal', family: 'crystal', group: MT, dark: 0, desc: 'Layered frosted glass, soft diffusion',
    prev: 'background:radial-gradient(60% 80% at 25% 20%,#fff,transparent 70%),linear-gradient(135deg,#cfe2f3,#e9f1f9);box-shadow:inset 0 0 0 1px rgba(255,255,255,.9),inset 0 -6px 12px rgba(120,160,210,.25)',
    tok: mat({ page: '#dce8f3', pageBg: 'radial-gradient(70% 50% at 15% 0,rgba(255,255,255,.9),transparent 70%),radial-gradient(60% 50% at 90% 100%,rgba(170,200,235,.55),transparent 70%),#dce8f3', card: ['rgba(255,255,255,.62)', 'rgba(236,244,251,.5)'], small: ['rgba(255,255,255,.75)', 'rgba(232,241,250,.6)'], well: 'rgba(205,222,240,.65)', ink: '#12202e', ink2: '#42566b', line: 'rgba(255,255,255,.8)', line2: 'rgba(60,90,130,.14)', wellLine: 'rgba(90,120,160,.22)', shadow: 'rgba(60,100,150,.22)', hi: 'rgba(255,255,255,.95)', sel: ['#1f3a5c', '#13253d'], selC: '#f2f7fc' }),
    extra: 'html[data-dyn=crystal] :is(.dlg,.menu,#top,#ribbon,#toast){-webkit-backdrop-filter:blur(10px)!important;backdrop-filter:blur(10px)!important}' });
  add({ id: 'dyn-titanium', name: 'Titanium', family: 'titanium', group: MT, dark: 0, desc: 'Brushed titanium with fine grain',
    prev: 'background:repeating-linear-gradient(90deg,rgba(255,255,255,.18) 0 1px,transparent 1px 3px),linear-gradient(180deg,#d5d8dc,#aeb2b8);box-shadow:inset 0 1px 0 #fff,inset 0 -2px 4px rgba(0,0,0,.25)',
    tok: mat({ page: '#c8cbd0', pageBg: 'repeating-linear-gradient(90deg,rgba(255,255,255,.07) 0 1px,transparent 1px 3px),linear-gradient(180deg,#d2d5d9,#bfc3c9)', card: ['#dcdfe3', '#c2c6cc'], small: ['#e3e5e8', '#c9cdd2'], well: '#b3b7be', ink: '#15171a', ink2: '#464b53', line: 'rgba(255,255,255,.55)', line2: 'rgba(0,0,0,.14)', wellLine: 'rgba(0,0,0,.18)', shadow: 'rgba(40,46,56,.35)', hi: 'rgba(255,255,255,.9)', sel: ['#3b4047', '#1e2226'], selC: '#f0f2f4' }),
    extra: 'html[data-dyn=titanium] :is(.dlg,.glass,#top){background-image:repeating-linear-gradient(90deg,rgba(255,255,255,.06) 0 1px,transparent 1px 3px),var(--L-bg)}' });
  add({ id: 'dyn-leather', name: 'Leatherbound', family: 'leather', group: MT, dark: 1, desc: 'Premium bound notebook, stitched edges',
    prev: 'background:repeating-linear-gradient(45deg,rgba(0,0,0,.12) 0 1px,transparent 1px 3px),linear-gradient(160deg,#4c382b,#33231a);box-shadow:inset 0 0 0 3px #3b2a1f,inset 0 0 0 4px rgba(224,184,130,.55)',
    tok: mat({ dark: 1, page: '#33241b', pageBg: 'repeating-linear-gradient(45deg,rgba(0,0,0,.05) 0 1px,transparent 1px 3px),repeating-linear-gradient(-45deg,rgba(255,255,255,.02) 0 1px,transparent 1px 4px),#33241b', card: ['#46332a', '#392820'], small: ['#533d31', '#41302a'], well: '#251a14', ink: '#f6e9d6', ink2: '#cdb592', line: 'rgba(224,184,130,.22)', shadow: 'rgba(0,0,0,.5)', hi: 'rgba(255,220,170,.12)', sel: ['#e0bf8c', '#bd9560'], selC: '#2a1b0e' }),
    extra: 'html[data-dyn=leather] :is(.dlg,.panel,.wizcard){outline:1px dashed rgba(224,184,130,.38);outline-offset:-7px}' });
  add({ id: 'dyn-ceramic', name: 'Obsidian Ceramic', family: 'ceramic', group: MT, dark: 1, desc: 'Deep satin ceramic with glaze depth',
    prev: 'background:radial-gradient(70% 60% at 30% 15%,rgba(255,255,255,.22),transparent 60%),linear-gradient(160deg,#2a2d35,#0d0e11);box-shadow:inset 0 1px 0 rgba(255,255,255,.3),inset 0 -8px 12px rgba(0,0,0,.5)',
    tok: mat({ dark: 1, page: '#0f1013', pageBg: 'radial-gradient(80% 50% at 25% 0,rgba(140,160,200,.1),transparent 70%),#0f1013', card: ['#23262d', '#121317'], small: ['#2b2e36', '#181a1f'], well: '#08090b', ink: '#eceef3', ink2: '#9ea5b3', line: 'rgba(190,205,235,.12)', shadow: 'rgba(0,0,0,.6)', hi: 'rgba(210,222,250,.16)', lsh: '0 16px 36px rgba(0,0,0,.65),inset 0 1px 0 rgba(210,222,250,.16),inset 0 -10px 18px rgba(0,0,0,.35)', sel: ['#f1f2f6', '#cfd3dc'], selC: '#0b0c0f' }) });
  add({ id: 'dyn-chrome', name: 'Liquid Chrome', family: 'chrome', group: MT, dark: 0, desc: 'Fluid silver gradients, soft highlights',
    prev: 'background:linear-gradient(115deg,#f4f6f8,#b9bfc7 35%,#eef0f3 55%,#a9b0b9);box-shadow:inset 0 1px 0 #fff,inset 0 -3px 6px rgba(0,0,0,.2)',
    tok: mat({ page: '#cdd1d7', pageBg: 'linear-gradient(115deg,#e6e9ed 0%,#c2c7ce 38%,#e0e3e8 58%,#bcc2ca 100%)', card: ['#f1f3f6', '#cfd4db'], small: ['#f6f7f9', '#d6dae0'], well: '#bcc1c9', ink: '#14171b', ink2: '#434952', line: 'rgba(255,255,255,.7)', line2: 'rgba(0,0,0,.14)', wellLine: 'rgba(0,0,0,.16)', shadow: 'rgba(50,58,70,.3)', hi: 'rgba(255,255,255,.95)', ang: '115deg', sel: ['#2b3037', '#12151a'], selC: '#f4f6f8' }) });
  add({ id: 'dyn-paper', name: 'Embossed Paper', family: 'paper', group: MT, dark: 0, desc: 'Quiet editorial paper, raised and pressed',
    prev: 'background:#f1ebde;box-shadow:inset 0 1px 0 #fff,0 1px 0 rgba(120,100,70,.35),inset 2px 3px 5px rgba(120,100,70,.18)',
    tok: mat({ page: '#ece5d6', pageBg: 'repeating-linear-gradient(0deg,rgba(120,100,70,.025) 0 1px,transparent 1px 3px),#ece5d6', card: ['#f5f0e4', '#eee7d8'], small: ['#f7f2e7', '#ece5d6'], well: '#e3dbc9', ink: '#2b2418', ink2: '#645a46', line: 'rgba(120,100,70,.22)', shadow: 'rgba(110,90,60,.22)', hi: 'rgba(255,255,255,.9)', lsh: 'inset 0 1px 0 rgba(255,255,255,.9),0 1px 0 rgba(120,100,70,.25),4px 7px 16px rgba(110,90,60,.2)', ssh: 'inset 0 1px 0 rgba(255,255,255,.9),0 1px 0 rgba(120,100,70,.3),2px 3px 6px rgba(110,90,60,.2)', psh: 'inset 1px 2px 5px rgba(110,90,60,.32),0 1px 0 rgba(255,255,255,.8)', sel: ['#5a4a32', '#3b2f1e'], selC: '#f8f2e5' }) });

  /* ---- Atmosphere ---- */
  add({ id: 'dyn-velvet', name: 'Velvet Theatre', family: 'velvet', group: AT, dark: 1, desc: 'Burgundy velvet and a warm spotlight',
    prev: 'background:radial-gradient(60% 50% at 50% 0,rgba(255,196,120,.45),transparent 70%),linear-gradient(180deg,#3a0f18,#14040a)',
    tok: mat({ dark: 1, page: '#1b070c', pageBg: 'radial-gradient(75% 45% at 50% -5%,rgba(255,190,110,.17),transparent 70%),#1b070c', card: ['#2f0f17', '#1f0a10'], small: ['#3b141d', '#26101a'], well: '#12050a', ink: '#f8eae6', ink2: '#d0a9a4', line: 'rgba(255,200,150,.14)', shadow: 'rgba(0,0,0,.6)', hi: 'rgba(255,200,150,.1)', sel: ['#f2d49c', '#d4a95f'], selC: '#2a1206' }) });
  add({ id: 'dyn-noir', name: 'Film Noir', family: 'noir', group: AT, dark: 1, desc: 'Monochrome contrast, smoky charcoal',
    prev: 'background:linear-gradient(120deg,#000 0,#2a2a2c 45%,#0a0a0b 100%)',
    tok: mat({ dark: 1, page: '#0c0c0d', pageBg: 'linear-gradient(115deg,rgba(255,255,255,.05),transparent 40%),radial-gradient(80% 50% at 80% 0,rgba(255,255,255,.05),transparent 70%),#0c0c0d', card: ['#1c1c1e', '#111112'], small: ['#262628', '#18181a'], well: '#060607', ink: '#eeeeee', ink2: '#a2a2a6', line: 'rgba(255,255,255,.11)', shadow: 'rgba(0,0,0,.7)', hi: 'rgba(255,255,255,.09)', sel: ['#ececec', '#bdbdbf'], selC: '#0a0a0a' }) });
  add({ id: 'dyn-tungsten', name: 'Tungsten', family: 'tungsten', group: AT, dark: 1, desc: 'Warm amber indoor light',
    prev: 'background:radial-gradient(70% 70% at 50% 0,rgba(255,176,60,.6),transparent 72%),linear-gradient(180deg,#3a2410,#1b1006)',
    tok: mat({ dark: 1, page: '#231508', pageBg: 'radial-gradient(80% 50% at 50% -5%,rgba(255,170,60,.2),transparent 70%),#231508', card: ['#38240f', '#291a0b'], small: ['#432b13', '#31200e'], well: '#170d05', ink: '#fbebcb', ink2: '#d6b57f', line: 'rgba(255,190,100,.16)', shadow: 'rgba(0,0,0,.55)', hi: 'rgba(255,200,120,.12)', sel: ['#ffc15c', '#e29631'], selC: '#2a1604' }) });
  add({ id: 'dyn-dusk', name: 'Dusk', family: 'dusk', group: AT, dark: 1, desc: 'Twilight blue-violet and smoky mauve',
    prev: 'background:linear-gradient(180deg,#2a2347,#4a3350 75%,#6a4558)',
    tok: mat({ dark: 1, page: '#262040', pageBg: 'linear-gradient(180deg,#241e3e 0%,#35294b 62%,#46324f 100%)', card: ['rgba(60,48,88,.85)', 'rgba(42,34,66,.9)'], small: ['rgba(76,62,108,.9)', 'rgba(54,44,82,.95)'], well: 'rgba(26,21,44,.85)', ink: '#f3eaf8', ink2: '#c5b3d6', line: 'rgba(210,180,240,.16)', shadow: 'rgba(10,6,24,.5)', hi: 'rgba(220,190,250,.1)', sel: ['#f1dbef', '#d4aed3'], selC: '#2c1a3a' }) });
  add({ id: 'dyn-midnight', name: 'Midnight', family: 'midnight', group: AT, dark: 1, desc: 'Near-black navy, calm and nocturnal',
    prev: 'background:radial-gradient(60% 60% at 70% 0,rgba(90,130,220,.3),transparent 70%),linear-gradient(180deg,#0a1020,#04060d)',
    tok: mat({ dark: 1, page: '#060a14', pageBg: 'radial-gradient(70% 40% at 75% -5%,rgba(90,130,220,.14),transparent 70%),#060a14', card: ['#0f1526', '#0a0f1d'], small: ['#151c32', '#0e1426'], well: '#03050b', ink: '#e7edf9', ink2: '#97a6c4', line: 'rgba(130,160,230,.13)', shadow: 'rgba(0,0,0,.65)', hi: 'rgba(150,180,255,.09)', sel: ['#d3e2ff', '#a2bff0'], selC: '#08101f' }) });
  add({ id: 'dyn-forest', name: 'Dark Forest', family: 'forest', group: AT, dark: 1, desc: 'Deep greens with soft mist',
    prev: 'background:radial-gradient(80% 50% at 50% 100%,rgba(120,170,130,.35),transparent 70%),linear-gradient(180deg,#14281c,#08130c)',
    tok: mat({ dark: 1, page: '#0b1a12', pageBg: 'radial-gradient(90% 40% at 50% 105%,rgba(110,160,120,.17),transparent 70%),radial-gradient(70% 40% at 20% -5%,rgba(150,190,150,.07),transparent 70%),#0b1a12', card: ['#15291d', '#0f1e16'], small: ['#1b3325', '#13261b'], well: '#07110b', ink: '#e8f2e8', ink2: '#a2bda9', line: 'rgba(160,210,170,.14)', shadow: 'rgba(0,0,0,.55)', hi: 'rgba(170,220,180,.09)', sel: ['#cde8c0', '#9bc78e'], selC: '#0b1f10' }) });
  add({ id: 'dyn-redroom', name: 'Red Room', family: 'redroom', group: AT, dark: 1, desc: 'Black and crimson, controlled red light',
    prev: 'background:radial-gradient(60% 60% at 50% 100%,rgba(230,40,60,.55),transparent 72%),linear-gradient(180deg,#14060a,#050203)',
    tok: mat({ dark: 1, page: '#090405', pageBg: 'radial-gradient(80% 40% at 50% 108%,rgba(220,30,50,.22),transparent 70%),#090405', card: ['#1d0a0d', '#130609'], small: ['#280d12', '#1a080c'], well: '#050203', ink: '#f7e8e8', ink2: '#c9a0a3', line: 'rgba(255,70,80,.2)', shadow: 'rgba(0,0,0,.7)', hi: 'rgba(255,90,100,.1)', sel: ['#ffd9d9', '#ff9fa2'], selC: '#2a0509' }) });

  /* ---- Experimental ---- */
  add({ id: 'dyn-brutalist', name: 'Brutalist', family: 'brutalist', group: EX, dark: 0, desc: 'Raw concrete, hard edges, no softness',
    prev: 'background:linear-gradient(#bdbcb7,#bdbcb7);box-shadow:inset 0 0 0 3px #111,5px 5px 0 #111',
    tok: mat({ page: '#b9b8b3', pageBg: 'radial-gradient(rgba(0,0,0,.05) 1px,transparent 1.5px) 0 0/7px 7px,#b9b8b3', card: ['#d0cfca', '#d0cfca'], small: ['#e0dfda', '#e0dfda'], well: '#a7a6a1', ink: '#101010', ink2: '#3a3a37', line: '#111111', shadow: '#111111', hi: 'transparent', lsh: '6px 6px 0 #111', ssh: '3px 3px 0 #111', psh: 'inset 3px 3px 0 rgba(0,0,0,.28)', onsh: '3px 3px 0 #111', sel: ['#111111', '#111111'], selC: '#f2f2ee', focus: '#111' }),
    extra: 'html[data-dyn=brutalist] :is(.btn,.glass,.dlg,.menu,#toast,.sv,.pcard,.thcard,.thprev,.fbtn,.panel,.wizcard,input.t,textarea.t,select.t,.paper-opt,#side,#top,#ribbon){border-radius:0!important}html[data-dyn=brutalist] :is(.btn,.glass,.dlg,.menu,#toast,.sv,.pcard,.thcard,.fbtn,.panel,.wizcard,#side,#top,#ribbon){border:3px solid #111!important}html[data-dyn=brutalist] .btn{font-weight:800;text-transform:uppercase;letter-spacing:.03em}html[data-dyn=brutalist] .btn:active{transform:translate(3px,3px);box-shadow:none}' });
  add({ id: 'dyn-eink', name: 'E-Ink', family: 'eink', group: EX, dark: 0, desc: 'Matte e-paper, crisp and instant',
    prev: 'background:#e8e7e1;box-shadow:inset 0 0 0 1.5px #1a1a1a',
    tok: mat({ page: '#e8e7e1', card: ['#eeede7', '#eeede7'], small: ['#eeede7', '#eeede7'], well: '#dcdbd4', ink: '#111111', ink2: '#454540', line: '#1a1a1a', line2: 'rgba(0,0,0,.35)', shadow: 'transparent', hi: 'transparent', lsh: 'none', ssh: 'none', psh: 'none', onsh: 'none', sel: ['#111111', '#111111'], selC: '#f4f4ef', focus: '#111' }),
    extra: 'html[data-dyn=eink] *,html[data-dyn=eink] *::before,html[data-dyn=eink] *::after{transition:none!important;animation:none!important}html[data-dyn=eink] :is(.btn,.glass,.dlg,.menu,.sv,.pcard,.thcard,.fbtn,.panel,.wizcard,#side,#top,#ribbon,#toast){border:1.5px solid #1a1a1a!important;box-shadow:none!important}html[data-dyn=eink] .btn:active{background:#111;color:#f4f4ef}html[data-dyn=eink] :is(#cover,#page,#nPage){box-shadow:0 0 0 1.5px #1a1a1a!important}' });
  add({ id: 'dyn-holo', name: 'Holographic Glass', family: 'holo', group: EX, dark: 0, desc: 'Pearl glass with a spectral shimmer',
    prev: 'background:linear-gradient(120deg,rgba(110,231,249,.7),rgba(167,139,250,.7) 40%,rgba(249,168,212,.7) 70%,rgba(253,230,138,.7)),#eee;box-shadow:inset 0 0 0 1px rgba(255,255,255,.9)',
    tok: mat({ page: '#e6e3f3', pageBg: 'radial-gradient(60% 45% at 10% 0,rgba(120,230,250,.35),transparent 70%),radial-gradient(60% 45% at 95% 20%,rgba(250,170,215,.3),transparent 70%),radial-gradient(70% 50% at 50% 105%,rgba(180,160,255,.35),transparent 70%),#e8e6f4', card: ['rgba(255,255,255,.6)', 'rgba(240,238,252,.5)'], small: ['rgba(255,255,255,.78)', 'rgba(238,236,251,.62)'], well: 'rgba(214,210,238,.7)', ink: '#19182a', ink2: '#4e4c74', line: 'rgba(255,255,255,.85)', line2: 'rgba(120,110,190,.2)', wellLine: 'rgba(120,110,190,.25)', shadow: 'rgba(100,90,170,.2)', hi: 'rgba(255,255,255,.95)', sel: ['#c9f1fb', '#e4cffb'], selC: '#17162a', focus: '#5b4fd0' }),
    extra: 'html[data-dyn=holo] :is(.dlg,.menu,#top,#ribbon){-webkit-backdrop-filter:blur(9px)!important;backdrop-filter:blur(9px)!important}html[data-dyn=holo] :is(.btn.on,.btn.pri,.thcard.sel,.menu>button.sel){background:linear-gradient(120deg,#9be7f5,#c4b2fb 45%,#f7b8dc 75%,#fbe7a0)!important;color:#17162a!important;border:1px solid rgba(255,255,255,.85)!important}html[data-dyn=holo] .thcard.sel::after{background:#17162a!important;color:#fff!important}' });
  add({ id: 'dyn-sumi', name: 'Sumi', family: 'sumi', group: EX, dark: 0, desc: 'Ink wash on warm paper, quiet space',
    prev: 'background:radial-gradient(70% 90% at 25% 30%,rgba(40,38,34,.55),transparent 70%),radial-gradient(60% 70% at 80% 80%,rgba(90,86,78,.3),transparent 70%),#efe9db',
    tok: mat({ page: '#ebe5d6', pageBg: 'radial-gradient(60% 40% at 10% 0,rgba(60,56,50,.1),transparent 70%),radial-gradient(60% 40% at 100% 100%,rgba(60,56,50,.09),transparent 70%),#ebe5d6', card: ['#f3eee2', '#eee8da'], small: ['#f5f0e5', '#ece6d7'], well: '#e1dac8', ink: '#15130f', ink2: '#58534a', line: 'rgba(30,28,24,.2)', shadow: 'rgba(40,36,30,.18)', hi: 'rgba(255,255,255,.7)', lsh: '0 10px 28px rgba(40,36,30,.14)', ssh: '0 2px 6px rgba(40,36,30,.14)', psh: 'inset 0 1px 4px rgba(40,36,30,.22)', sel: ['#1c1b18', '#0e0d0b'], selC: '#f1ebdc' }) });

  T.list = L; T.groups = [SC, MT, AT, EX]; T.subs = { Sculpted: [LI, DK] };
  T.byId = function (id) { return L.filter(function (t) { return t.id === id; })[0]; };

  /* one style element holds every generated token block + local extras */
  var css = '';
  L.forEach(function (t) { css += 'html[data-dyn=' + t.family + ']{' + Object.keys(t.tok).map(function (n) { return n + ':' + t.tok[n]; }).join(';') + '}\n'; if (t.extra) css += t.extra + '\n'; });
  var st = document.createElement('style'); st.id = 'dyn-tokens'; st.textContent = css; document.head.appendChild(st);
})();
