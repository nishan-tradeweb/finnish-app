/* Script layouts – Industry (US), Standard (the original finnish layout), Mirrored (right-to-left) – chosen automatically from the writing language.
   Stored on the script as d.layout ('us' | 'std' | 'rtl'), d.layoutUser (true when picked by hand; reset when the language changes) and d.typo (the numbers every renderer already reads).
   Numbers from the research PDF: Courier 12 pt, single spacing, left margin 1.5 in, right 1 in, top 1 in, dialogue block 1 in in, cue 2.2 in in, parenthetical 1.6 in in. */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, L = THK.layouts = {};
  var IN = 25.4;
  var PRESETS = {
    us: {
      n: 'Industry (US)', s: 'Hollywood standard: single spacing, left-aligned dialogue, about 55 lines a page.',
      typo: { lh: 1, m: { t: IN, b: IN, l: 1.5 * IN, r: IN }, el: { scene: { l: 0, r: 0, sb: 1 }, action: { l: 0, r: 0, sb: 1 }, char: { l: 2.2 * IN, r: 0, sb: 1 }, paren: { l: 1.6 * IN, r: 2 * IN, sb: 0 }, dial: { l: IN, r: 1.5 * IN, sb: 0 }, trans: { l: 0, r: 0, sb: 1 } } },
      hf: { title: false, pn: 'top-right', pnf: 'dot' }
    },
    rtl: {
      n: 'Mirrored (right-to-left)', s: 'For Arabic, Persian, Urdu and Hebrew: binding margin on the right, everything anchored from the right.',
      typo: { lh: 1.15, mir: true, m: { t: IN, b: IN, l: 1.5 * IN, r: IN }, el: { scene: { l: 0, r: 0, sb: 1 }, action: { l: 0, r: 0, sb: 1 }, char: { l: 2.2 * IN, r: 0, sb: 1 }, paren: { l: 1.6 * IN, r: 2 * IN, sb: 0 }, dial: { l: IN, r: 1.5 * IN, sb: 0 }, trans: { l: 0, r: 0, sb: 1 } } },
      hf: { title: false, pn: 'top-left', pnf: 'dot' }
    },
    std: { n: 'Standard (finnish)', s: 'The original finnish layout: 1.5 spacing, roomy margins. Good for Indian scripts.', typo: null, hf: null }
  };
  L.PRESETS = PRESETS;
  var SPANISH = { es: 1, fr: 1 };
  /* language → layout. English and the western languages use the US layout, right-to-left languages are mirrored, everything else keeps Standard. */
  var US_LANGS = { en: 1, es: 1, fr: 1, de: 1, it: 1, pt: 1, ja: 1, pl: 1, tr: 1, id: 1, tl: 1, vi: 1 };
  L.forLang = function (lang) { var l = THK.lang(lang); if (l.rtl) return 'rtl'; return US_LANGS[l.id] ? 'us' : 'std'; };

  function clone(o) { return o ? JSON.parse(JSON.stringify(o)) : o; }
  L.apply = function (d, id, byUser) {
    var P = PRESETS[id] || PRESETS.std; d.layout = id;
    if (byUser) d.layoutUser = true; else delete d.layoutUser;
    if (P.typo) d.typo = clone(P.typo); else delete d.typo;
    var hf = d.hf = d.hf || {};
    if (P.hf) { if (!d.layoutHf) d.layoutHf = clone({ title: hf.title, pn: hf.pn, pnf: hf.pnf }); hf.title = P.hf.title; hf.pn = P.hf.pn; hf.pnf = P.hf.pnf; }
    else if (d.layoutHf) { ['title', 'pn', 'pnf'].forEach(function (k) { if (d.layoutHf[k] === undefined) delete hf[k]; else hf[k] = d.layoutHf[k]; }); delete d.layoutHf; }
    if (!Object.keys(hf).length) delete d.hf;
    return d;
  };
  /* new scripts */
  L.init = function (d) { if (d && !d.layout && !d.typo) L.apply(d, L.forLang(d.lang || 'en')); return d; };
  /* the language menu changed the writing language: layout follows (a hand-picked layout lasts until the language changes) */
  L.onLang = function (d) {
    if (!d) return; var id = L.forLang(d.lang), was = d.layout; L.apply(d, id, false); return was !== id;
  };

  /* ---- series (multi-camera) helpers read by the typography code ---- */
  L.mc = function (d) { return !!(d && d.series && d.series.mc); };

  /* ---- print css that only layouts need ---- */
  L.printCss = function (d) {
    var c = '';
    if (d.layout === 'us' || d.layout === 'rtl') {
      c += 'main{page:script}@page script:first{@top-right{content:none}@top-left{content:none}}' + 'main .b.dial,main .b.paren{break-inside:avoid}main .b.char{break-after:avoid}';
      if (d.layout === 'rtl') c += 'main{direction:rtl}main .b.trans{text-align:left}';
    }
    if (L.mc(d)) c += 'main .b.dial,main .b.paren{line-height:2}main .b.action{text-transform:uppercase}';
    return c;
  };
  L.editCss = function (d) {
    var c = '';
    if ((d.layout === 'us' || d.layout === 'rtl') && d.fmt !== 'two') c += '#page.std .b.dial:not([class*="al-"]){text-align:' + (d.layout === 'rtl' ? 'right' : 'left') + '}';
    if (L.mc(d)) c += '#page .b.dial,#page .b.paren{line-height:2}#page .b.action{text-transform:uppercase}';
    return c;
  };

  /* ---- (CONT'D): the same character speaks again after only action, inside the same scene ---- */
  L.pre = function (d) {
    if (!d || (d.layout !== 'us' && d.layout !== 'rtl') || d.contd === false) return d;
    var out = Object.assign({}, d), last = '', lastIdx = -1, between = false;
    out.blocks = d.blocks.map(function (b) { return b; });
    var tag = (THK.lang(d.lang).id === 'es') ? '(CONT.)' : (d.lang === 'fr' ? '(SUITE)' : "(CONT'D)");
    for (var i = 0; i < out.blocks.length; i++) {
      var b = out.blocks[i];
      if (b.t === 'scene') { last = ''; between = false; continue; }
      if (b.t === 'char') {
        var nm = String(b.x || '').replace(/\(.*?\)/g, '').trim().toUpperCase();
        if (nm && nm === last && between && !/\(CONT|\(SUITE/i.test(b.x)) out.blocks[i] = Object.assign({}, b, { x: b.x + ' ' + tag });
        last = nm; between = false; continue;
      }
      if (b.t === 'action' && String(b.x || '').trim()) between = true;
      else if (b.t === 'trans' || b.t === 'shot') { last = ''; between = false; }
    }
    return out;
  };

  /* ---- the Layout dialog ---- */
  L.dialog = function () {
    var A = THK.app, d = A.cur; if (!d) return A.toast('Open a script first');
    var body = A.el('div', 'xdlg'), keep = d.layout || 'std';
    var cur = d.layout || (d.typo ? 'custom' : 'std'), list = A.el('div', ''); body.appendChild(list);
    body.appendChild(A.el('div', 'xsub', 'The layout follows the writing language. Pick one by hand and it stays until you change the language again. Fine-tuning is under Page design → Typography.'));
    function draw() {
      list.innerHTML = '';
      ['us', 'std', 'rtl'].forEach(function (id) {
        var P = PRESETS[id], on = (d.layout || (d.typo ? '' : 'std')) === id;
        var b = A.el('button', 'btn' + (on ? ' on' : ''), '<b>' + A.esc(P.n) + '</b><br><small>' + A.esc(P.s) + '</small>'); b.style.cssText = 'display:block;width:100%;text-align:left;margin:6px 0;height:auto;padding:10px 14px;white-space:normal';
        b.onclick = function () { A.snap && A.snap(); L.apply(d, id, true); finish(); draw(); A.toast('Layout: ' + P.n); };
        list.appendChild(b);
      });
      if (d.fmt === 'two') list.appendChild(A.el('div', 'xsub', 'The Two Column format ignores these indents; margins and spacing still apply.'));
    }
    function finish() { if (A.applyLook) A.applyLook(); if (A.persist) A.persist(); A.dirty(); A.refreshRibbon && A.refreshRibbon(); }
    draw(); A.dlg('Script layout', body, [{ l: 'Done', cls: 'pri' }]);
  };
})();
