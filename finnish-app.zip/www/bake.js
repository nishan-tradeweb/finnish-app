/* finnish – theme texture baker.
   The material themes (leather, stone, linen …) draw their texture with live SVG light-and-noise filters. Every repaint makes the browser run those filters again, which is what made scrolling and typing stutter.
   This turns each filter texture of the ACTIVE theme into a ready-made bitmap once (at the screen's own pixel density, so it looks the same), and swaps it in. Nothing about the look changes. */
(function () {
  'use strict';
  var map = {}, busy = false, queue = [], R = document.documentElement;
  var DPR = Math.min(2, Math.max(1, window.devicePixelRatio || 1));
  var RE = /url\("data:image\/svg\+xml,([^"]+)"\)/g;
  function styles() { return ['dyn-tokens', 'dyn-plus'].map(function (i) { return document.getElementById(i); }).filter(Boolean); }
  function wrap(w, h, png) { return 'url("data:image/svg+xml,' + encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' width='" + w + "' height='" + h + "'><image width='" + w + "' height='" + h + "' href='" + png + "'/></svg>") + '")'; }
  function bake(enc, done) {
    if (map[enc]) return done();
    var svg; try { svg = decodeURIComponent(enc); } catch (e) { map[enc] = 0; return done(); }
    if (svg.indexOf('<filter') < 0) { map[enc] = 0; return done(); }                       /* plain gradients and dots are already cheap */
    var m = /width='(\d+)' height='(\d+)'/.exec(svg); if (!m) { map[enc] = 0; return done(); }
    var w = +m[1], h = +m[2], img = new Image();
    img.onload = function () {
      try {
        var c = document.createElement('canvas'); c.width = w * DPR; c.height = h * DPR; var x = c.getContext('2d'); x.drawImage(img, 0, 0, c.width, c.height);
        map[enc] = wrap(w, h, c.toDataURL('image/png'));
      } catch (e) { map[enc] = 0; }
      done();
    };
    img.onerror = function () { map[enc] = 0; done(); };
    img.src = 'data:image/svg+xml;charset=utf-8,' + enc;
  }
  function swap() {
    styles().forEach(function (st) {
      var t = st.textContent, n = t.replace(RE, function (all, enc) { return map[enc] || all; });
      if (n !== t) st.textContent = n;
    });
  }
  function run() {
    var fam = R.dataset.dyn; if (!fam) return;
    var list = [], seen = {}, tag = 'data-dyn=' + fam + ']';
    styles().forEach(function (st) {
      st.textContent.split('\n').forEach(function (line) {
        if (line.indexOf(tag) < 0) return; var m; RE.lastIndex = 0;
        while ((m = RE.exec(line))) { if (!seen[m[1]] && map[m[1]] === undefined) { seen[m[1]] = 1; list.push(m[1]); } }
      });
    });
    if (!list.length) return swap();
    var i = 0;
    (function step() {
      if (i >= list.length) { swap(); return; }
      bake(list[i++], function () { (window.requestIdleCallback || function (f) { setTimeout(f, 16); })(step); });
    })();
  }
  /* bake after the first paint, and again whenever the theme changes */
  function later() { clearTimeout(later.t); later.t = setTimeout(function () { (window.requestIdleCallback || function (f) { f(); })(run); }, 400); }
  new MutationObserver(later).observe(R, { attributes: true, attributeFilter: ['data-dyn'] });
  if (document.readyState === 'complete') later(); else window.addEventListener('load', later);
})();
