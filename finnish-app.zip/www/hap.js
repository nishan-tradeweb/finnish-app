/* Haptic feedback – a light tick on buttons, menus and switches, stronger ones for drag/drop, page turns and success.
   Uses the Capacitor Haptics plugin on Android (falls back to navigator.vibrate). Can be switched off in Customise. */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, last = 0;
  function plug() { try { var c = window.Capacitor; return c && c.isNativePlatform && c.isNativePlatform() && c.Plugins && c.Plugins.Haptics ? c.Plugins.Haptics : null; } catch (e) { return null; } }
  function on() { try { return !(THK.app && THK.app.S && THK.app.S.haptic === false); } catch (e) { return true; } }
  var PAT = { tick: 8, pick: 16, drop: 12, turn: 10, ok: [10, 40, 16], err: [24, 50, 24] };
  THK.hap = function (kind) {
    if (!on()) return; var now = Date.now(); if (now - last < 28) return; last = now; kind = kind || 'tick';
    var H = plug();
    try {
      if (H) {
        if (kind === 'ok') return void H.notification({ type: 'SUCCESS' });
        if (kind === 'err') return void H.notification({ type: 'ERROR' });
        if (kind === 'turn') return void H.selectionChanged ? (H.selectionStart && H.selectionStart(), H.selectionChanged(), H.selectionEnd && H.selectionEnd()) : H.impact({ style: 'LIGHT' });
        return void H.impact({ style: kind === 'pick' ? 'MEDIUM' : 'LIGHT' });
      }
      if (navigator.vibrate) navigator.vibrate(PAT[kind] || 8);
    } catch (e) { }
  };
  /* one listener covers every pill / menu row / switch in the app (and dialogs added later) */
  var SEL = 'button,.btn,.menu [role=menuitem],.sw,.thcard,.sv,[role=button],label.pdfsim,input[type=checkbox],input[type=radio],select';
  document.addEventListener('pointerdown', function (e) {
    if (e.pointerType === 'mouse') return; var t = e.target; if (!t || !t.closest) return; var h = t.closest(SEL); if (!h || h.disabled || h.closest('.odh,.nopress')) return; THK.hap('tick');
  }, { passive: true, capture: true });
})();
