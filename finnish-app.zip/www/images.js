/* Pictures inside the script. A picture is its own line (block type "img"): the file is stored exactly as picked – no recompression – inside the script
   (doc.imgs), the line only points to it, so undo history and recovery copies stay small. Placement: left, centre, right or full page.
   Printed only when "Print with images" is ticked in Export. */
(function () {
  'use strict';
  var A = THK.app, el = A.el, esc = A.esc, I = THK.img = {};
  var OK = /^image\/(jpeg|jpg|png|webp|gif|bmp|avif|svg\+xml|heic|heif|x-icon|tiff?)$/i;
  var PLACE = [['left', 'Left'], ['center', 'Centre'], ['right', 'Right'], ['full', 'Full page']];

  I.src = function (d, b) { return (d && d.imgs && b && d.imgs[b.iid]) || ''; };
  I.has = function (d) { return (d.blocks || []).some(function (b) { return b.t === 'img' && I.src(d, b); }); };

  /* editor block */
  I.mk = function (b, w) {
    var cur = A.cur, fig = el('div', 'imgbox ia-' + (b.ia || 'center')), src = I.src(cur, b);
    if (src) { var im = el('img'); im.src = src; im.alt = b.x || ''; im.draggable = false; im.onclick = function (e) { e.stopPropagation(); I.menu(b, im); }; fig.appendChild(im); }
    else fig.appendChild(el('div', 'imgmiss', 'Picture missing from this file'));
    w.appendChild(fig);
    var cap = el('div', 'ed'); cap.dataset.f = 'x'; cap.dataset.ph = 'Caption (optional)'; cap.contentEditable = A.PT; cap.spellcheck = false; A.drawRich(cap, b.x || '', b.fm && b.fm.x); w.appendChild(cap);
    w.classList.add('ia-' + (b.ia || 'center'));
    return w;
  };

  function place(b, v) {
    var w = A.blockEl(b.id); if (!w) return; b.ia = v;
    ['left', 'center', 'right', 'full'].forEach(function (p) { w.classList.remove('ia-' + p); var f = w.querySelector('.imgbox'); f && f.classList.remove('ia-' + p); }); w.classList.add('ia-' + v); var f2 = w.querySelector('.imgbox'); f2 && f2.classList.add('ia-' + v);
  }
  I.menu = function (b, anchor) {
    var items = PLACE.map(function (p) { return { l: (b.ia || 'center') === p[0] ? '✓ ' + p[1] : p[1], fn: function () { A.snap(); place(b, p[0]); A.snap(); A.dirty(); } }; });
    items.push({ hr: 1 }, { l: 'Replace picture…', fn: function () { pick(function (r) { A.snap(); A.cur.imgs[b.iid] = r.url; var w = A.blockEl(b.id), n = I.mk(b, el('div')); var old = w.querySelector('.imgbox'); old.replaceWith(n.querySelector('.imgbox')); A.snap(); A.dirty(); }); } },
      { l: 'Remove picture', fn: function () { A.snap(); var i = A.idxOf(b.id), w = A.blockEl(b.id); A.cur.blocks.splice(i, 1); if (!A.cur.blocks.length) A.cur.blocks.push({ id: A.uid(), t: 'action', x: '' }); A.renderAll(); A.snap(); A.dirty(); } });
    A.menu(anchor, items, false);
  };

  function pick(done) {
    var inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*,.jpg,.jpeg,.png,.webp,.gif,.bmp,.avif,.svg,.heic'; inp.style.display = 'none'; document.body.appendChild(inp);
    inp.onchange = function () {
      var f = inp.files && inp.files[0]; inp.remove(); if (!f) return;
      if (f.type && !OK.test(f.type)) return A.toastIn('That file is not a picture I can use (jpg, png, webp, gif, bmp, avif, svg)');
      var r = new FileReader(); r.onerror = function () { A.toastIn('Could not read the picture'); };
      r.onload = function () {
        var url = String(r.result), im = new Image();
        im.onload = function () { done({ url: url, w: im.naturalWidth, h: im.naturalHeight, bytes: f.size, name: f.name }); };
        im.onerror = function () { A.toastIn('That picture could not be opened on this device'); };
        im.src = url;
      };
      r.readAsDataURL(f);   /* the bytes are kept exactly as they are */
    };
    inp.click();
  }
  I.pickFile = pick;
  I.pick = function () {
    var cur = A.cur; if (!cur) return;
    pick(function (r) {
      var body = el('div', ''), sel = 'center';
      var th = el('img', 'imgprev'); th.src = r.url; body.appendChild(th);
      body.appendChild(el('p', 'imgnote', esc(r.name) + ' · ' + r.w + '×' + r.h + ' px · ' + (r.bytes / 1048576 >= 1 ? (r.bytes / 1048576).toFixed(1) + ' MB' : Math.round(r.bytes / 1024) + ' KB') + ' · original quality, not compressed'));
      body.appendChild(el('p', '', 'Where should it sit on the page?'));
      var row = el('div', 'imgplace'); PLACE.forEach(function (p) { var b = el('button', 'btn' + (p[0] === sel ? ' on' : ''), p[1]); b.onclick = function () { sel = p[0]; [].forEach.call(row.children, function (c) { c.classList.remove('on'); }); b.classList.add('on'); }; row.appendChild(b); }); body.appendChild(row);
      body.appendChild(el('p', 'imgnote', 'Pictures appear in the PDF only when “Print with images” is ticked in Export.'));
      A.dlg('Add picture', body, [{ l: 'Cancel' }, { l: 'Add', cls: 'pri', fn: function () { insert(r.url, sel); } }], { nofocus: true });
    });
  };
  function insert(url, pl) {
    var cur = A.cur; cur.imgs = cur.imgs || {}; var iid = 'i' + A.uid(); cur.imgs[iid] = url; A.snap();
    var nb = { id: A.uid(), t: 'img', x: '', iid: iid, ia: pl }, i = A.cb ? A.idxOf(A.cb.id) : cur.blocks.length - 1, after = { id: A.uid(), t: 'action', x: '' };
    if (i >= 0 && cur.blocks[i] && cur.blocks[i].t !== 'img' && !(cur.blocks[i].x || '').trim() && cur.blocks.length > 1) cur.blocks.splice(i, 1, nb); else cur.blocks.splice(i + 1, 0, nb);
    var k = cur.blocks.indexOf(nb); if (!cur.blocks[k + 1]) cur.blocks.splice(k + 1, 0, after);
    A.renderAll(); A.snap(); A.dirty(); setTimeout(function () { var w = A.blockEl(nb.id); w && w.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 60);
  }

  /* print */
  I.print = function (d, b) {
    var s = I.src(d, b); if (!s) return '';
    var ia = b.ia || 'center', cap = (b.x || '').trim() ? '<figcaption>' + esc(b.x) + '</figcaption>' : '';
    return '<figure class="b img ia-' + ia + (b.pb ? ' pb' : '') + '"><img src="' + s + '" alt="">' + cap + '</figure>';
  };
  I.css = function () {
    return 'figure.b.img{margin:0 0 4mm;padding:0;display:flex;flex-direction:column;break-inside:avoid;white-space:normal}figure.b.img img{max-width:100%;max-height:230mm;height:auto;width:auto;display:block;image-rendering:auto}' +
      'figure.b.img figcaption{font-size:.85em;opacity:.8;margin-top:1.5mm;white-space:pre-wrap}' +
      'figure.ia-left{align-items:flex-start;text-align:left}figure.ia-center{align-items:center;text-align:center}figure.ia-right{align-items:flex-end;text-align:right}' +
      'figure.ia-full{break-before:page;break-after:page;height:calc(100vh - 2mm);justify-content:center;align-items:center;text-align:center;margin:0}figure.ia-full img{max-width:100%;max-height:calc(100vh - 14mm);object-fit:contain}';
  };

  I.editorCss = '#page .b.img{margin:.8em 0}#page .b.img .imgbox{display:flex;max-width:100%}#page .b.img .ia-left{justify-content:flex-start}#page .b.img .ia-center{justify-content:center}#page .b.img .ia-right{justify-content:flex-end}' +
    '#page .b.img .imgbox img{max-width:100%;max-height:70vh;border-radius:6px;box-shadow:0 2px 10px rgba(0,0,0,.18);cursor:pointer;-webkit-user-select:none;user-select:none}#page .b.img .ia-full img{width:100%;max-height:80vh;object-fit:contain}' +
    '#page .b.img .ed{font-size:.85em;opacity:.85;text-align:center;margin-top:.3em;min-height:1.2em}#page .b.img .imgmiss{padding:20px;border:1px dashed currentColor;border-radius:8px;opacity:.6}' +
    '.imgprev{display:block;max-width:100%;max-height:34vh;margin:0 auto 8px;border-radius:10px;box-shadow:0 4px 18px rgba(0,0,0,.25)}.imgnote{font-size:12px;opacity:.7;margin:6px 0}.imgplace{display:flex;gap:8px;flex-wrap:wrap}.imgplace .btn.on{background:#5e6cf2;color:#fff}';
  var st = document.createElement('style'); st.textContent = I.editorCss; document.head.appendChild(st);
})();
