/* Print only some pages of the script (for example 15-17, or just 200). The pages are worked out from the real layout of the script
   (same fonts, same width, same keep-together rules as the printed PDF), then only those pages are printed with their real page numbers. */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, PR = THK.pr = {};
  var MM = 96 / 25.4;

  /* "15-17", "200-200", "3", "1-3, 8, 12-" → sorted list of [from,to]; null if it cannot be understood */
  PR.parse = function (str) {
    var s = String(str || '').replace(/[–—−]/g, '-').replace(/\bto\b/gi, '-').replace(/[;\s]+/g, ',').replace(/,+/g, ',').replace(/^,|,$/g, ''); if (!s) return null;
    var out = [], ok = true;
    s.split(',').forEach(function (t) {
      var m = /^(\d+)?-(\d+)?$/.exec(t), n;
      if (m && (m[1] || m[2])) { var a = m[1] ? +m[1] : 1, b = m[2] ? +m[2] : Infinity; if (a > b) { var x = a; a = b; b = x; } out.push([a, b]); }
      else if ((n = /^\d+$/.exec(t))) out.push([+t, +t]); else ok = false;
    });
    if (!ok || !out.length || out.some(function (r) { return r[0] < 1; })) return null;
    return out;
  };
  function toSet(ranges, total) { var set = {}; ranges.forEach(function (r) { for (var p = r[0]; p <= Math.min(r[1], total); p++) set[p] = 1; }); return Object.keys(set).map(Number).sort(function (a, b) { return a - b; }); }
  function label(ranges, total) { return ranges.map(function (r) { var b = Math.min(r[1], total); return r[0] === b ? '' + r[0] : r[0] + '-' + b; }).join(', '); }

  /* lay the script out at page width and cut it into pages */
  function layout(d, o) {
    return new Promise(function (resolve, reject) {
      var p = THK.buildPrint(d, o), g = p.geo, f = document.createElement('iframe');
      f.setAttribute('aria-hidden', 'true'); f.style.cssText = 'position:fixed;left:-20000px;top:0;border:0;visibility:hidden;width:' + Math.round(g.cw * MM) + 'px;height:2000px';
      var done = false;
      function fin() {
        if (done) return; done = true;
        try {
          var doc = f.contentDocument, w = f.contentWindow, main = doc.querySelector('main.body'); if (!main) throw new Error('no body');
          var H = g.ch * MM * 0.985, kids = [].slice.call(main.children), pages = [[]], y = 0, prevMb = 0, has = false;
          var info = kids.map(function (el) { var cs = w.getComputedStyle(el), r = el.getBoundingClientRect(); return { el: el, h: r.height, mt: parseFloat(cs.marginTop) || 0, mb: parseFloat(cs.marginBottom) || 0, pb: el.classList.contains('pb') || /page|always|left|right/.test(cs.breakBefore || ''), keep: /avoid/.test(cs.breakAfter || '') }; });
          function np() { pages.push([]); y = 0; prevMb = 0; has = false; }
          info.forEach(function (k, i) {
            if (k.pb && has) np();
            var gap = has ? Math.max(prevMb, k.mt) : 0, total = gap + k.h, j = i;
            while (info[j].keep && j + 1 < info.length && !info[j + 1].pb) { j++; total += Math.max(info[j - 1].mb, info[j].mt) + info[j].h; }
            if (has && y + total > H && total - gap <= H) { np(); gap = 0; }
            else if (has && y + gap + k.h > H) { np(); gap = 0; }
            y += gap + k.h; prevMb = k.mb; has = true; pages[pages.length - 1].push(k.el);
            if (y > H * 1.02) { var extra = Math.floor((y - 0.01) / H); for (var q = 0; q < extra; q++) pages.splice(pages.length, 0, []); y = y - extra * H; }
          });
              resolve({ pages: pages, doc: doc, frame: f, p: p, cleanup: function () { f.remove(); } });
        } catch (e) { f.remove(); reject(e); }
      }
      f.onload = function () { var fonts = f.contentDocument && f.contentDocument.fonts; if (fonts && fonts.ready) Promise.race([fonts.ready, new Promise(function (r) { setTimeout(r, 3500); })]).then(function () { setTimeout(fin, 250); }); else setTimeout(fin, 400); };
      f.srcdoc = THK.printDoc(d, o); document.body.appendChild(f); setTimeout(function () { if (!done) fin(); }, 9000);
    });
  }
  function baseOpts(o) { var x = {}; for (var k in (o || {})) x[k] = o[k]; x.toc = false; x.payload = false; return x; }

  /* number of script pages (without the cover) */
  PR.count = function (d, o) { var x = baseOpts(o); x.cover = false; return layout(d, x).then(function (L) { var n = L.pages.length; L.cleanup(); return n; }); };

  /* spec: the text typed by the person */
  PR.print = function (d, o, spec) {
    var ranges = PR.parse(spec); if (!ranges) return Promise.reject(new Error('Type pages like 15-17 or 3, 8, 12-14'));
    var x = baseOpts(o), withCover = o.cover !== false; x.cover = withCover;
    return layout(d, x).then(function (L) {
      var total = L.pages.length, sel = toSet(ranges, total);
      if (!sel.length) { L.cleanup(); throw new Error('This script has ' + total + ' page' + (total === 1 ? '' : 's') + '.'); }
      var body = '', k = 0, names = '';
      sel.forEach(function (pn) {
        var els = L.pages[pn - 1]; if (!els.length) return;
        body += '<div style="page:rp' + pn + '">';
        els.forEach(function (el, i) { var c = el.cloneNode(true); if (i === 0) c.style.marginTop = '0'; body += c.outerHTML; });
        body += '</div>'; names += '@page rp' + pn + '{counter-set:page ' + pn + '}'; k++;
      });
      L.cleanup();
      if (!k) throw new Error('Those pages are empty.');
      var css = x.css || '', html = THK.printDoc(d, x);
      /* swap the body for the chosen pages and make the page numbers continue from the first chosen page */
      var i0 = html.indexOf('<main class="body">'), i1 = html.indexOf('</main>', i0);
      if (i0 < 0 || i1 < 0) throw new Error('Could not build the pages');
      html = html.slice(0, i0) + '<main class="body">' + body + html.slice(i1);
      html = html.replace('</style>', names + '</style>');
      var nm = (d.title || 'script') + ' pages ' + label(ranges, total);
      return THK.printRaw(html, d, nm);
    });
  };
  PR.label = label;
})();
