/* Storyboard – one panel per shot, drawn by hand or built from pictures, tied to the screenplay's scenes, exported as a PDF.
   Stored inside the script as cur.sb = { ar, panels:[{ id, sc (scene block id), ang, cap, note, bg (reference picture), fit, ink (drawing layer) }] } */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, SB = THK.sb = {};
  var A = function () { return THK.app; };
  var ANG = ['Establishing shot', 'Extreme wide (EWS)', 'Wide shot (WS)', 'Medium shot (MS)', 'Medium close-up (MCU)', 'Close-up (CU)', 'Extreme close-up (ECU)', 'Over the shoulder (OTS)', 'Two-shot', 'POV', 'Insert', 'Cutaway', 'High angle', 'Low angle', "Bird's eye", "Worm's eye", 'Dutch angle', 'Tracking', 'Pan', 'Tilt', 'Dolly in', 'Dolly out', 'Crane', 'Handheld'];
  var ARS = { '16:9': [16, 9], '2.39:1': [239, 100], '4:3': [4, 3], '1:1': [1, 1], '9:16': [9, 16] };
  var COLS = ['#111111', '#e5484d', '#f59e0b', '#2fa86b', '#2f7cf6', '#8b5cf6', '#ffffff'];
  var root = null, ed = null, filter = 'all', cache = {};

  function el(t, c, h) { var e = A().el(t, c); if (h != null) e.textContent = h; return e; }
  function esc(s) { return A().esc(s); }
  function doc() { return A().cur; }
  function sb() { var d = doc(); if (!d.sb) d.sb = { ar: '16:9', panels: [] }; if (!ARS[d.sb.ar]) d.sb.ar = '16:9'; return d.sb; }
  function dims(ar, long) { var r = ARS[ar || '16:9'], w = r[0], h = r[1], k = long / Math.max(w, h); return [Math.round(w * k), Math.round(h * k)]; }
  function scenes() { var M = THK.sceneNums(doc()), out = []; doc().blocks.forEach(function (b) { if (b.t === 'scene') { out.push({ id: b.id, n: M[b.id], head: (THK.stripSn ? THK.stripSn(b.x || '') : (b.x || '')).replace(/\s+/g, ' ').trim() || 'Untitled scene' }); } }); return out; }
  function sceneOf(id, list) { return (list || scenes()).filter(function (s) { return s.id === id; })[0]; }
  function loadImg(url) { return new Promise(function (res) { if (!url) return res(null); if (cache[url]) return res(cache[url]); var i = new Image(); i.onload = function () { cache[url] = i; res(i); }; i.onerror = function () { res(null); }; i.src = url; }); }
  /* ordered list: by scene order, then the order they were made; panels without a scene last */
  function shotNos() { var no = {}, cnt = {}, S = scenes(); ordered().forEach(function (p) { var k = sceneOf(p.sc, S) ? p.sc : '_'; cnt[k] = (cnt[k] || 0) + 1; no[p.id] = cnt[k]; }); return no; }
  function ordered() {
    var S = scenes(), P = sb().panels, out = [];
    S.forEach(function (s) { P.forEach(function (p) { if (p.sc === s.id) out.push(p); }); });
    P.forEach(function (p) { if (!sceneOf(p.sc, S)) out.push(p); });
    return out;
  }
  function drawFit(ctx, img, W, H, fit) {
    if (!img) return; var iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
    if (fit === 'stretch') { ctx.drawImage(img, 0, 0, W, H); return; }
    var k = fit === 'fit' ? Math.min(W / iw, H / ih) : Math.max(W / iw, H / ih), w = iw * k, h = ih * k;
    ctx.drawImage(img, (W - w) / 2, (H - h) / 2, w, h);
  }
  /* picture + drawing → one canvas */
  function compose(p, long) {
    var D = dims(sb().ar, long), c = document.createElement('canvas'); c.width = D[0]; c.height = D[1]; var x = c.getContext('2d'); x.fillStyle = '#ffffff'; x.fillRect(0, 0, D[0], D[1]);
    return Promise.all([loadImg(p.bg), loadImg(p.ink)]).then(function (r) { drawFit(x, r[0], D[0], D[1], p.fit || 'fill'); if (r[1]) x.drawImage(r[1], 0, 0, D[0], D[1]); return c; });
  }
  function shrink(file, done) {
    var fr = new FileReader(); fr.onload = function () { var i = new Image(); i.onload = function () { var k = Math.min(1, 1400 / Math.max(i.width, i.height)), c = document.createElement('canvas'); c.width = Math.round(i.width * k); c.height = Math.round(i.height * k); c.getContext('2d').drawImage(i, 0, 0, c.width, c.height); done(c.toDataURL('image/jpeg', .86)); }; i.onerror = function () { A().toast('Could not read that picture'); }; i.src = fr.result; }; fr.readAsDataURL(file);
  }
  function pickPicture(done) { var f = el('input'); f.type = 'file'; f.accept = 'image/*'; f.onchange = function () { if (f.files[0]) shrink(f.files[0], done); }; f.click(); }
  function save() { A().dirty(); A().persist && A().persist(); }

  /* ---------------------------------------------------------------- studio (the grid of panels) */
  SB.open = function () {
    if (root || !doc()) return; var d = doc(); sb();
    root = el('div', 'sbo'); var cs = getComputedStyle(document.body); root.style.backgroundColor = cs.backgroundColor; root.style.backgroundImage = cs.backgroundImage;
    var bar = el('div', 'sbbar glass'), t = el('div', 'sbt', 'Storyboard'); var back = A().btn('Close', SB.close, '', 'Close'); bar.appendChild(back); bar.appendChild(t);
    var tools = el('div', 'sbtools glass');
    tools.appendChild(A().btn('+ Panel', function () { newPanel(filter !== 'all' && filter !== 'none' ? filter : curScene()); }, 'pri'));
    tools.appendChild(A().btn('Panels from scenes', fromScenes, '', 'One empty panel for every scene that has none'));
    var sc = el('select', 't'); sc.id = 'sbSc'; sc.onchange = function () { filter = sc.value; grid(); }; tools.appendChild(sc); A().upgradeSelect(sc);
    var ar = el('select', 't'); ar.id = 'sbAr'; Object.keys(ARS).forEach(function (k) { var o = el('option', '', k); o.value = k; ar.appendChild(o); }); ar.value = sb().ar; ar.title = 'Frame shape'; ar.onchange = function () { sb().ar = ar.value; save(); grid(); A().toast('Frame shape changed – older drawings are stretched to fit'); }; tools.appendChild(ar); A().upgradeSelect(ar);
    var body = el('div', 'sbbody'); body.id = 'sbBody';
    root.appendChild(bar); root.appendChild(tools); root.appendChild(body); document.body.appendChild(root);
    root.classList.add('in'); fillScenes(); grid(true);
  };
  function curScene() { var A1 = A(), cb = A1.cb, d = doc(); if (!cb) return null; var i = d.blocks.indexOf(cb); while (i >= 0 && d.blocks[i].t !== 'scene') i--; return i >= 0 ? d.blocks[i].id : null; }
  function fillScenes() {
    var sc = document.getElementById('sbSc'); if (!sc) return; var S = scenes(), v = filter; sc.innerHTML = '';
    function add(val, txt) { var o = el('option', '', txt); o.value = val; sc.appendChild(o); }
    add('all', 'All scenes'); S.forEach(function (s) { add(s.id, s.n + '. ' + (s.head.length > 34 ? s.head.slice(0, 34) + '…' : s.head)); }); add('none', 'No scene yet');
    sc.value = v; if (sc.value !== v) { filter = 'all'; sc.value = 'all'; }
  }
  SB.close = function () { if (!root) return; if (ed) { edClose(false); } var r = root; root = null; r.classList.remove('in'); setTimeout(function () { r.remove(); }, 200); try { A().renderAll && 0; } catch (e) { } };
  SB.back = function () { if (ed) { edTryClose(); return true; } if (root) { SB.close(); return true; } return false; };
  function grid(scroll) {
    var body = document.getElementById('sbBody'); if (!body) return; var S = scenes(), P = sb().panels, no = shotNos();
    body.innerHTML = ''; var ar = sb().ar, shown = 0, cs = curScene(), jump = null;
    function group(title, list, id) {
      if (filter !== 'all' && filter !== id) return; var g = el('section', 'sbg'); var h = el('div', 'sbgh'); h.appendChild(el('b', '', title)); h.appendChild(el('small', '', list.length + (list.length === 1 ? ' panel' : ' panels')));
      var add = A().btn('+', function () { newPanel(id === 'none' ? null : id); }, 'sbadd', 'Add a panel to this scene'); h.appendChild(add); g.appendChild(h);
      var gr = el('div', 'sbgrid'); list.forEach(function (p) { gr.appendChild(card(p, no[p.id], list)); shown++; }); if (!list.length) gr.appendChild(el('div', 'sbempty', 'No panels yet')); g.appendChild(gr); body.appendChild(g); if (id === cs) jump = g;
    }
    S.forEach(function (s) { var l = P.filter(function (p) { return p.sc === s.id; }); if (l.length || filter === s.id || filter === 'all') group('Scene ' + s.n + ' · ' + s.head, l, s.id); });
    var un = P.filter(function (p) { return !sceneOf(p.sc, S); }); if (un.length || filter === 'none') group('No scene yet', un, 'none');
    if (!P.length) { var e = el('div', 'sbwelcome'); e.innerHTML = '<b>Plan every shot</b><span>Tap <i>+ Panel</i> to draw a frame, or <i>Panels from scenes</i> to start with one empty frame per scene. Add a reference picture and draw over it, label the camera angle, and export it all as a PDF.</span>'; body.insertBefore(e, body.firstChild); }
    var tt = root && root.querySelector('.sbt'); if (tt) tt.textContent = 'Storyboard · ' + P.length + (P.length === 1 ? ' panel' : ' panels');
    if (scroll && jump && filter === 'all' && P.length) setTimeout(function () { jump.scrollIntoView({ block: 'start' }); }, 30);
  }
  function card(p, n, list) {
    var c = el('div', 'sbc'), D = dims(sb().ar, 1000), fr = el('div', 'sbfr'); fr.style.aspectRatio = D[0] + ' / ' + D[1];
    var cv = document.createElement('canvas'); fr.appendChild(cv); compose(p, 480).then(function (k) { cv.width = k.width; cv.height = k.height; cv.getContext('2d').drawImage(k, 0, 0); });
    fr.appendChild(el('span', 'sbn', String(n))); if (p.ang) fr.appendChild(el('span', 'sba', p.ang.replace(/^.*\(([^)]+)\)$/, '$1').slice(0, 14)));
    fr.onclick = function () { edOpen(p); }; c.appendChild(fr);
    var cap = el('div', 'sbcap'); if (p.cap) cap.textContent = p.cap; else cap.innerHTML = '<i>No description</i>'; cap.onclick = function () { edOpen(p); }; c.appendChild(cap);
    var row = el('div', 'sbmv'), i = list.indexOf(p), P = sb().panels;
    function mv(dir) { var a = P.indexOf(p), nb = list[i + dir]; if (!nb) return; var b = P.indexOf(nb); P[a] = nb; P[b] = p; save(); grid(); }
    var l = A().btn('◀', function () { mv(-1); }, '', 'Move earlier'), r = A().btn('▶', function () { mv(1); }, '', 'Move later'); l.disabled = i <= 0; r.disabled = i >= list.length - 1; row.appendChild(l); row.appendChild(r);
    var dup = A().btn('Copy', function () { var q = JSON.parse(JSON.stringify(p)); q.id = A().uid(); P.splice(P.indexOf(p) + 1, 0, q); save(); grid(); }, '', 'Duplicate this panel'); row.appendChild(dup); c.appendChild(row);
    return c;
  }
  function newPanel(sc) { var p = { id: A().uid(), sc: sc || null, ang: '', cap: '', note: '', fit: 'fill' }; sb().panels.push(p); save(); edOpen(p, true); }
  function fromScenes() {
    var S = scenes(), P = sb().panels, n = 0; S.forEach(function (s) { if (!P.some(function (p) { return p.sc === s.id; })) { P.push({ id: A().uid(), sc: s.id, ang: n % 3 === 0 ? 'Wide shot (WS)' : '', cap: '', note: '', fit: 'fill' }); n++; } });
    if (!S.length) return A().toast('Write a scene heading first'); if (!n) return A().toast('Every scene already has a panel'); save(); grid(); A().toast(n + ' panel' + (n === 1 ? '' : 's') + ' added');
  }

  /* ---------------------------------------------------------------- panel editor (draw, picture, labels) */
  function edOpen(p, isNew) {
    if (ed) return; var D = dims(sb().ar, 1280), o = el('div', 'sbe'); var cs = getComputedStyle(document.body); o.style.backgroundColor = cs.backgroundColor; o.style.backgroundImage = cs.backgroundImage;
    ed = { p: p, o: o, isNew: !!isNew, tool: 'pen', col: COLS[0], size: 6, undo: [], dirty: false, W: D[0], H: D[1], bg: p.bg || '', fit: p.fit || 'fill', snap: JSON.stringify({ sc: p.sc, ang: p.ang, cap: p.cap, note: p.note }) };
    var bar = el('div', 'sbbar glass'); bar.appendChild(A().btn('Cancel', edTryClose, '', 'Close without saving')); bar.appendChild(el('div', 'sbt', 'Shot ' + (shotNos()[p.id] || 1)));
    bar.appendChild(A().btn('Done', function () { edClose(true); }, 'pri', 'Save this panel')); o.appendChild(bar);
    var wrap = el('div', 'sbwrap'), stage = el('div', 'sbstage'); stage.style.aspectRatio = D[0] + ' / ' + D[1];
    var cb = document.createElement('canvas'), ci = document.createElement('canvas'); cb.width = ci.width = D[0]; cb.height = ci.height = D[1]; cb.className = 'cb'; ci.className = 'ci'; stage.appendChild(cb); stage.appendChild(ci); wrap.appendChild(stage); ed.cb = cb; ed.ci = ci;
    /* tools */
    var tl = el('div', 'sbtl glass'), sw = el('div', 'sbsw');
    [['pen', 'Pen'], ['brush', 'Marker'], ['eraser', 'Eraser']].forEach(function (t) { var b = A().btn(t[1], function () { ed.tool = t[0]; paintTools(); }, ''); b.dataset.tool = t[0]; tl.appendChild(b); });
    COLS.forEach(function (c) { var s = el('button', 'sbcol'); s.style.background = c; s.dataset.c = c; s.setAttribute('aria-label', 'Colour ' + c); s.onclick = function () { ed.col = c; if (ed.tool === 'eraser') ed.tool = 'pen'; paintTools(); }; sw.appendChild(s); });
    var pk = el('input'); pk.type = 'color'; pk.className = 'sbpk'; pk.value = ed.col; pk.oninput = function () { ed.col = pk.value; if (ed.tool === 'eraser') ed.tool = 'pen'; paintTools(); }; sw.appendChild(pk); tl.appendChild(sw);
    var sz = el('input'); sz.type = 'range'; sz.min = 1; sz.max = 40; sz.value = ed.size; sz.className = 'sbsz'; sz.title = 'Size'; sz.oninput = function () { ed.size = +sz.value; }; tl.appendChild(sz);
    tl.appendChild(A().btn('Undo', undoInk, '')); tl.appendChild(A().btn('Clear drawing', function () { pushUndo(); ed.ci.getContext('2d').clearRect(0, 0, ed.W, ed.H); ed.dirty = true; }, ''));
    wrap.appendChild(tl);
    var pic = el('div', 'sbpic glass'); pic.appendChild(A().btn('Add picture', function () { pickPicture(function (u) { ed.bg = u; ed.dirty = true; paintBg(); paintPic(); }); }, '', 'Use a photo or reference as the frame'));
    ed.picRow = pic; [['fill', 'Fill'], ['fit', 'Fit'], ['stretch', 'Stretch']].forEach(function (f) { var b = A().btn(f[1], function () { ed.fit = f[0]; ed.dirty = true; paintBg(); paintPic(); }, ''); b.dataset.fit = f[0]; pic.appendChild(b); });
    ed.rm = A().btn('Remove picture', function () { ed.bg = ''; ed.dirty = true; paintBg(); paintPic(); }, ''); pic.appendChild(ed.rm); wrap.appendChild(pic);
    /* labels */
    var f = el('div', 'sbf glass'); function fld(lbl, node) { var l = el('label', 'sbl'); l.appendChild(el('span', '', lbl)); l.appendChild(node); f.appendChild(l); return node; }
    var sc = el('select', 't'); (function () { var n0 = el('option', '', 'No scene yet'); n0.value = ''; sc.appendChild(n0); scenes().forEach(function (s) { var o2 = el('option', '', s.n + '. ' + (s.head.length > 40 ? s.head.slice(0, 40) + '…' : s.head)); o2.value = s.id; sc.appendChild(o2); }); sc.value = p.sc || ''; })(); sc.onchange = function () { p.sc = sc.value || null; }; fld('Scene', sc); ed.sc = sc; A().upgradeSelect(sc);
    var an = el('select', 't'); var o0 = el('option', '', 'No camera label'); o0.value = ''; an.appendChild(o0); ANG.forEach(function (a) { var oo = el('option', '', a); oo.value = a; an.appendChild(oo); }); an.value = p.ang || ''; fld('Camera angle', an); ed.an = an; A().upgradeSelect(an);
    var cp = el('textarea', 't'); cp.rows = 2; cp.placeholder = 'What happens in this shot'; cp.value = p.cap || ''; fld('Description', cp); ed.cp = cp;
    var nt = el('textarea', 't'); nt.rows = 2; nt.placeholder = 'Dialogue, sound, movement…'; nt.value = p.note || ''; fld('Notes', nt); ed.nt = nt;
    var del = A().btn('Delete panel', function () { A().confirmD ? A().confirmD('Delete this panel?', 'This cannot be undone.', function () { delPanel(); }, 'Delete') : delPanel(); }, ''); f.appendChild(del);
    wrap.appendChild(f); o.appendChild(wrap); document.body.appendChild(o); o.classList.add('in');
    paintTools(); paintPic(); paintBg(); loadInk(); bindInk(ci);
  }
  function delPanel() { var P = sb().panels; P.splice(P.indexOf(ed.p), 1); save(); edClose(false, true); grid(); fillScenes(); }
  function paintTools() { if (!ed) return; [].forEach.call(ed.o.querySelectorAll('[data-tool]'), function (b) { b.classList.toggle('on', b.dataset.tool === ed.tool); }); [].forEach.call(ed.o.querySelectorAll('.sbcol'), function (s) { s.classList.toggle('on', s.dataset.c === ed.col && ed.tool !== 'eraser'); }); }
  function paintPic() { if (!ed) return; [].forEach.call(ed.picRow.querySelectorAll('[data-fit]'), function (b) { b.classList.toggle('on', b.dataset.fit === ed.fit); b.hidden = !ed.bg; }); ed.rm.hidden = !ed.bg; }
  function paintBg() { var x = ed.cb.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, ed.W, ed.H); loadImg(ed.bg).then(function (i) { if (!ed) return; x.fillStyle = '#fff'; x.fillRect(0, 0, ed.W, ed.H); drawFit(x, i, ed.W, ed.H, ed.fit); }); }
  function loadInk() { loadImg(ed.p.ink).then(function (i) { if (i && ed) ed.ci.getContext('2d').drawImage(i, 0, 0, ed.W, ed.H); }); }
  function pushUndo() { try { ed.undo.push(ed.ci.getContext('2d').getImageData(0, 0, ed.W, ed.H)); if (ed.undo.length > 15) ed.undo.shift(); } catch (e) { } }
  function undoInk() { var s = ed.undo.pop(); if (!s) return A().toast('Nothing to undo'); ed.ci.getContext('2d').putImageData(s, 0, 0); ed.dirty = true; }
  function bindInk(cv) {
    var x = cv.getContext('2d'), down = false, last = null, lw = 0; cv.style.touchAction = 'none';
    function pt(e) { var r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * cv.width / r.width, y: (e.clientY - r.top) * cv.height / r.height, p: e.pointerType === 'pen' && e.pressure ? e.pressure : .5 }; }
    function style(p) {
      var base = ed.size * (cv.width / 1280) * (ed.tool === 'brush' ? 2.4 : 1), k = ed.tool === 'eraser' ? 3 : 1; x.lineCap = 'round'; x.lineJoin = 'round';
      lw = base * k * (p.p === .5 ? 1 : (.4 + p.p * 1.2)); x.lineWidth = Math.max(1, lw);
      if (ed.tool === 'eraser') { x.globalCompositeOperation = 'destination-out'; x.strokeStyle = '#000'; x.globalAlpha = 1; } else { x.globalCompositeOperation = 'source-over'; x.strokeStyle = ed.col; x.globalAlpha = ed.tool === 'brush' ? .55 : 1; }
    }
    cv.addEventListener('pointerdown', function (e) { if (e.button > 0) return; e.preventDefault(); try { cv.setPointerCapture(e.pointerId); } catch (er) { } pushUndo(); down = true; last = pt(e); style(last); x.beginPath(); x.moveTo(last.x, last.y); x.lineTo(last.x + .01, last.y + .01); x.stroke(); ed.dirty = true; if (THK.hap) THK.hap('tick'); });
    cv.addEventListener('pointermove', function (e) {
      if (!down) return; e.preventDefault(); var evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e]; if (!evs.length) evs = [e];
      evs.forEach(function (ev) { var q = pt(ev); style(q); x.beginPath(); x.moveTo(last.x, last.y); var mx = (last.x + q.x) / 2, my = (last.y + q.y) / 2; x.quadraticCurveTo(last.x, last.y, mx, my); x.lineTo(q.x, q.y); x.stroke(); last = q; });
    });
    function up() { down = false; x.globalAlpha = 1; x.globalCompositeOperation = 'source-over'; }
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up); cv.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  }
  function isBlank(c) { try { var d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; for (var i = 3; i < d.length; i += 16) if (d[i]) return false; return true; } catch (e) { return false; } }
  function edTryClose() {
    var p = ed.p, ch = ed.dirty || ed.snap !== JSON.stringify({ sc: ed.sc.value || null, ang: ed.an.value, cap: ed.cp.value, note: ed.nt.value }) && true;
    if (!ch) return edClose(false);
    A().confirmD ? A().confirmD('Discard changes?', 'This panel has changes that are not saved.', function () { edClose(false); }, 'Discard') : edClose(false);
  }
  function edClose(keep, gone) {
    if (!ed) return; var e = ed; ed = null;
    if (keep && !gone) {
      var p = e.p; p.sc = e.sc.value || null; p.ang = e.an.value; p.cap = e.cp.value.trim(); p.note = e.nt.value.trim(); p.fit = e.fit;
      if (e.bg) p.bg = e.bg; else delete p.bg; if (isBlank(e.ci)) delete p.ink; else p.ink = e.ci.toDataURL('image/png');
      save(); A().toast('Panel saved');
    } else if (!keep && !gone && e.isNew) { var P = sb().panels, p0 = e.p; if (!p0.cap && !p0.bg && !p0.ink && !p0.ang) { P.splice(P.indexOf(p0), 1); save(); } }
    e.o.classList.remove('in'); setTimeout(function () { e.o.remove(); }, 180); fillScenes(); grid();
  }

  /* ---------------------------------------------------------------- PDF (started from the main Export window) */
  SB.has = function (d) { return !!(d && d.sb && d.sb.panels && d.sb.panels.length); };
  function labelOf(p, n) { return 'Shot ' + n + (p.ang ? ' · ' + p.ang : ''); }
  /* every panel as a picture, keyed by id – used for "script with panels" */
  SB.maps = function () {
    var list = ordered(); return Promise.all(list.map(function (p) { return compose(p, 800).then(function (c) { return c.toDataURL("image/jpeg", .82); }); })).then(function (urls) {
      var map = {}, no = shotNos(); list.forEach(function (p, i) { map[p.id] = urls[i]; });
      return { sbMap: map, sbNo: no, sbLabel: function (p) { return labelOf(p, no[p.id]); } };
    });
  };
  /* storyboard on its own: one heading per scene, then that scene's panels with shot number + camera label */
  SB.exportPdf = function () {
    var d = doc(); if (!SB.has(d)) { A().toast('Add a panel first'); return Promise.resolve(); } A().toast('Preparing PDF…');
    return SB.maps().then(function (M) {
      var S = scenes(), P = sb().panels, D = dims(sb().ar, 1000), cols = D[0] >= D[1] * 1.2 ? 2 : (D[0] <= D[1] * .8 ? 4 : 3), pw = THK.paperOf(d);
      function card(p) { return '<div class="c"><div class="im"><img src="' + M.sbMap[p.id] + '"></div><div class="m"><i>' + M.sbNo[p.id] + '</i>' + (p.ang ? '<span>' + esc(p.ang) + '</span>' : '') + '</div>' + (p.cap ? '<div class="cp">' + esc(p.cap) + '</div>' : '') + (p.note ? '<div class="nt">' + esc(p.note) + '</div>' : '') + '</div>'; }
      var body = '<div class="top"><b>' + esc(d.title || 'Untitled') + '</b><span>Storyboard · ' + P.length + (P.length === 1 ? ' panel' : ' panels') + '</span></div>';
      function sec(head, sub, list) { if (!list.length) return; body += '<section class="sc"><h2><span>' + esc(head) + '</span>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</h2><div class="g">' + list.map(card).join('') + '</div></section>'; }
      S.forEach(function (s) { sec('Scene ' + s.n, s.head, P.filter(function (p) { return p.sc === s.id; })); });
      sec('Other panels', 'Not linked to a scene', P.filter(function (p) { return !sceneOf(p.sc, S); }));
      var css = '@page{size:' + pw.w + ' ' + pw.h + ';margin:14mm 12mm 16mm;@bottom-center{content:counter(page);font:8pt Arial;color:#666}}*{box-sizing:border-box}html,body{margin:0;background:#fff;color:#111;font-family:Arial,Helvetica,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}' +
        '.top{display:flex;justify-content:space-between;align-items:baseline;border-bottom:.7pt solid #111;padding-bottom:2mm;margin-bottom:5mm;font-size:9pt;color:#444}.top b{font-size:13pt;color:#111}' +
        '.sc{margin-bottom:7mm}.sc h2{margin:0 0 3mm;font-size:10.5pt;display:flex;gap:3mm;align-items:baseline;break-after:avoid;border-left:2.2mm solid #111;padding-left:3mm}.sc h2 small{font-size:9pt;font-weight:600;color:#444;text-transform:uppercase;letter-spacing:.02em}' +
        '.g{display:grid;grid-template-columns:repeat(' + cols + ',minmax(0,1fr));gap:5mm 4mm}.c{break-inside:avoid}.c .im{border:.6pt solid #111;aspect-ratio:' + D[0] + '/' + D[1] + ';overflow:hidden;background:#fff}.c img{width:100%;height:100%;display:block;object-fit:cover}' +
        '.m{display:flex;gap:2mm;align-items:center;margin:1.4mm 0 .6mm;font-size:7.5pt;font-weight:700;letter-spacing:.02em}.m i{font-style:normal;background:#111;color:#fff;border-radius:2mm;padding:.3mm 1.8mm}.c{min-width:0;overflow-wrap:anywhere;word-break:break-word}.cp{font-size:8.5pt;line-height:1.35;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}.nt{font-size:7.5pt;color:#555;margin-top:.8mm;font-style:italic;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}';
      return THK.printRaw(THK.shell(d, css, body, [d.font]), d, (d.title || 'script') + ' storyboard');
    }).catch(function () { A().toast('Could not make the PDF'); });
  };
  /* used by export.js: the panels of one scene, as a row under its heading */
  SB.row = function (d, blockId, o) {
    if (!o || !o.sbMap || !d.sb) return ''; var ps = d.sb.panels.filter(function (p) { return p.sc === blockId && o.sbMap[p.id]; }); if (!ps.length) return '';
    return '<div class="sbrow">' + ps.map(function (p) { return '<figure><img src="' + o.sbMap[p.id] + '"><figcaption><b>' + esc(o.sbLabel(p)) + '</b>' + (p.cap ? ' — ' + esc(p.cap) : '') + '</figcaption></figure>'; }).join('') + '</div>';
  };
  SB.printCss = '.sbrow{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:3mm;margin:1mm 0 5mm;break-inside:avoid;font-family:Arial,Helvetica,sans-serif;font-size:7pt;line-height:1.3}.sbrow figure{margin:0;min-width:0;overflow-wrap:anywhere;word-break:break-word}.sbrow figcaption{display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}.sbrow img{width:100%;display:block;border:.5pt solid #777}.sbrow figcaption{margin-top:1mm;opacity:.85}';

  /* ---------------------------------------------------------------- look: follows every theme through the shared variables */
  var st = document.createElement('style'); st.textContent =
    '.sbo,.sbe{position:fixed;inset:0;z-index:70;display:flex;flex-direction:column;opacity:0;transform:translateY(10px);transition:opacity .2s,transform .2s;color:var(--ink)}.sbe{z-index:75}.sbo.in,.sbe.in{opacity:1;transform:none}' +
    '.sbbar,.sbtools{margin:max(8px,env(safe-area-inset-top)) 8px 0;border-radius:22px;padding:6px 8px;display:flex;align-items:center;gap:6px;flex:0 0 auto}.sbtools{margin-top:8px;overflow-x:auto;scrollbar-width:none;flex-wrap:nowrap}.sbtools::-webkit-scrollbar{display:none}.sbtools>*{flex:0 0 auto}' +
    '.sbt{flex:1;text-align:center;font-weight:700;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.sbbody{flex:1;overflow:auto;padding:10px 10px max(18px,env(safe-area-inset-bottom));-webkit-overflow-scrolling:touch}.sbg{margin-bottom:16px}.sbgh{display:flex;align-items:center;gap:8px;margin:4px 4px 8px}.sbgh b{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.95em}.sbgh small{color:var(--ink2)}.sbgh .sbadd{padding:2px 14px}' +
    '.sbgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,230px),1fr));gap:12px}.sbempty{color:var(--ink2);padding:14px;border-radius:18px;border:1px dashed var(--edge);text-align:center;font-size:.9em}' +
    '.sbc{border-radius:20px;padding:8px;background:var(--glass2,var(--glass));border:1px solid var(--edge);color:var(--ink);display:flex;flex-direction:column;gap:6px}.sbfr{position:relative;border-radius:12px;overflow:hidden;background:#fff;cursor:pointer;box-shadow:0 0 0 1px rgba(0,0,0,.08)}.sbfr canvas{display:block;width:100%;height:100%}' +
    '.sbn{position:absolute;left:6px;top:6px;min-width:24px;height:24px;border-radius:12px;padding:0 7px;display:grid;place-items:center;background:var(--acc);color:var(--onacc,#fff);font-size:.78em;font-weight:700}.sba{position:absolute;right:6px;bottom:6px;border-radius:10px;padding:2px 8px;background:rgba(0,0,0,.62);color:#fff;font-size:.7em;font-weight:600}' +
    '.sbcap{font-size:.88em;color:var(--ink);min-height:1.2em;cursor:pointer;overflow-wrap:anywhere}.sbcap i{color:var(--ink2)}.sbmv{display:flex;gap:6px}.sbmv .btn{padding:4px 12px;font-size:.82em}.sbmv .btn:disabled{opacity:.35}' +
    '.sbwelcome{margin:20px auto;max-width:420px;padding:18px;border-radius:22px;background:var(--glass);border:1px solid var(--edge);color:var(--ink);display:flex;flex-direction:column;gap:6px;text-align:center}.sbwelcome span{color:var(--ink2);font-size:.92em;line-height:1.5}' +
    '.sbwrap{flex:1;overflow:auto;padding:10px 8px max(18px,env(safe-area-inset-bottom));display:flex;flex-direction:column;gap:10px;-webkit-overflow-scrolling:touch}.sbstage{position:relative;width:100%;max-width:min(100%,calc((100vh - 330px) * 1.78));margin:0 auto;border-radius:12px;overflow:hidden;background:#fff;box-shadow:0 8px 30px rgba(0,0,0,.25);flex:0 0 auto}' +
    '.sbstage canvas{position:absolute;inset:0;width:100%;height:100%}.sbstage .ci{touch-action:none;cursor:crosshair}' +
    '.sbtl,.sbpic,.sbf{border-radius:22px;padding:8px;display:flex;flex-wrap:wrap;gap:6px;align-items:center}.sbtl .btn,.sbpic .btn{padding:6px 13px}.sbtl .btn.on,.sbpic .btn.on{background:var(--acc);color:var(--onacc,#fff)}' +
    '.sbsw{display:flex;gap:6px;align-items:center;margin:0 4px}.sbcol{width:26px;height:26px;border-radius:50%;border:2px solid var(--edge);padding:0;cursor:pointer}.sbcol.on{box-shadow:0 0 0 2px var(--acc);border-color:#fff}.sbpk{width:30px;height:28px;border:0;padding:0;background:none;border-radius:50%}.sbsz{flex:1 1 90px;min-width:80px;accent-color:var(--acc)}' +
    '.sbwrap>*{min-width:0;max-width:100%}.sbf,.sbf *{box-sizing:border-box}.sbf{flex-direction:column;align-items:stretch;gap:10px}.sbl textarea.t{resize:vertical;min-height:64px;max-height:60vh;overflow-wrap:anywhere}.sbl .ddp{width:100%;justify-content:space-between}.sbl .ddp .dl{max-width:none;flex:1;text-align:left}.sbtools .ddp .dl{max-width:42vw}.sbl{display:flex;flex-direction:column;gap:4px}.sbl span{font-size:.78em;color:var(--ink2);letter-spacing:.04em;text-transform:uppercase;margin-left:6px}.sbl .t{width:100%}' +
    '.sbx{display:flex;flex-direction:column;gap:8px}.sbxo{display:flex;flex-direction:column;align-items:flex-start;gap:2px;text-align:left;padding:12px 14px;border-radius:18px;border:1px solid var(--edge);background:var(--glass2,var(--glass));color:var(--ink)}.sbxo small{color:var(--ink2)}.sbxo.on{background:var(--acc);color:var(--onacc,#fff)}.sbxo.on small{color:inherit;opacity:.85}' +
    '@media(min-width:900px){.sbwrap{flex-direction:row;flex-wrap:wrap;align-items:flex-start;justify-content:center}.sbstage{width:62%;max-width:none;margin:0}.sbtl,.sbpic,.sbf{width:34%}}';
  document.head.appendChild(st);
})();
