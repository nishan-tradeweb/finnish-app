/* finnish – talks to Firebase over its public REST interface (no SDK, so the app stays small and works offline until it needs the server).
   Accounts: email + password, Google, email verification, password reset. Server functions: account status, trial, region check, deletion. */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, C = THK.cloud = {}, CFG = window.FINNISH_CONFIG || {}, FB = CFG.firebase || {};
  var KEY = 'fn_session';
  C.ready = !!(FB.apiKey && FB.projectId);
  function nat() { try { var c = window.Capacitor; return !!(c && c.isNativePlatform && c.isNativePlatform()); } catch (e) { return false; } }
  C.native = nat;

  /* ---------------- session (kept on this device so the app opens offline) */
  var S = null;
  function load() { try { S = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { S = null; } }
  function save() { try { if (S) localStorage.setItem(KEY, JSON.stringify(S)); else localStorage.removeItem(KEY); } catch (e) { } }
  load();
  C.user = function () { return S ? { uid: S.uid, email: S.email, verified: !!S.verified, provider: S.provider || 'password' } : null; };

  function err(code, msg) { var e = new Error(msg || code); e.code = code; return e; }
  var MSG = {
    EMAIL_EXISTS: 'This email already has an account. Sign in instead.', INVALID_EMAIL: 'That email address does not look right.',
    WEAK_PASSWORD: 'Choose a password of at least 8 characters.', EMAIL_NOT_FOUND: 'No account uses this email.', INVALID_PASSWORD: 'The email or password is not correct.',
    INVALID_LOGIN_CREDENTIALS: 'The email or password is not correct.', USER_DISABLED: 'This account has been disabled. Contact support.', TOO_MANY_ATTEMPTS_TRY_LATER: 'Too many attempts. Please wait a few minutes and try again.',
    MISSING_PASSWORD: 'Enter your password.', OPERATION_NOT_ALLOWED: 'This sign-in method is not switched on yet.', NETWORK: 'No internet connection. Connect once to sign in, then you can work offline.'
  };
  function fail(code) { code = String(code || 'ERROR').split(' ')[0].split(':')[0]; return err(code, MSG[code] || 'Something went wrong. Please try again.'); }
  function post(url, body, headers) {
    return fetch(url, { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, headers || {}), body: JSON.stringify(body) }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) throw { http: r.status, body: j }; return j; });
    }, function () { throw err('NETWORK', MSG.NETWORK); });
  }
  function idt(path, body) {
    if (!C.ready) return Promise.reject(err('NOT_CONFIGURED', 'The account server is not set up in this build.'));
    return post('https://identitytoolkit.googleapis.com/v1/' + path + '?key=' + encodeURIComponent(FB.apiKey), body).catch(function (e) { if (e && e.code) throw e; throw fail(e && e.body && e.body.error && e.body.error.message); });
  }
  function take(r, provider) {
    S = { uid: r.localId, email: r.email || (S && S.email) || '', verified: r.emailVerified === true || provider === 'google', idToken: r.idToken, refresh: r.refreshToken, exp: Date.now() + (+r.expiresIn || 3600) * 1000 - 60000, provider: provider || 'password' };
    save(); return S;
  }
  function lookup() { return idt('accounts:lookup', { idToken: S.idToken }).then(function (r) { var u = r.users && r.users[0]; if (u) { S.verified = !!u.emailVerified; save(); } return S.verified; }); }

  C.signUp = function (email, pw) { return idt('accounts:signUp', { email: email, password: pw, returnSecureToken: true }).then(function (r) { take(r, 'password'); S.verified = false; save(); return C.sendVerify(); }); };
  C.signIn = function (email, pw) { return idt('accounts:signInWithPassword', { email: email, password: pw, returnSecureToken: true }).then(function (r) { take(r, 'password'); return lookup(); }); };
  C.signInGoogle = function (accessToken) {
    return idt('accounts:signInWithIdp', { postBody: 'access_token=' + encodeURIComponent(accessToken) + '&providerId=google.com', requestUri: 'http://localhost', returnIdpCredential: true, returnSecureToken: true })
      .then(function (r) { take(r, 'google'); return true; });
  };
  C.sendVerify = function () { return token().then(function (t) { return idt('accounts:sendOobCode', { requestType: 'VERIFY_EMAIL', idToken: t }); }); };
  C.sendReset = function (email) { return idt('accounts:sendOobCode', { requestType: 'PASSWORD_RESET', email: email }); };
  C.checkVerified = function () { return refresh(true).then(lookup); };
  C.signOut = function () { S = null; save(); try { localStorage.removeItem('fn_status'); } catch (e) { } return Promise.resolve(); };

  function refresh(force) {
    if (!S) return Promise.reject(err('SIGNED_OUT', 'Please sign in.'));
    if (!force && Date.now() < S.exp) return Promise.resolve(S.idToken);
    return post('https://securetoken.googleapis.com/v1/token?key=' + encodeURIComponent(FB.apiKey), { grant_type: 'refresh_token', refresh_token: S.refresh }).then(function (r) {
      S.idToken = r.id_token; S.refresh = r.refresh_token || S.refresh; S.exp = Date.now() + (+r.expires_in || 3600) * 1000 - 60000; save(); return S.idToken;
    }, function (e) { if (e && e.code === 'NETWORK') throw e; if (e && e.http >= 400 && e.http < 500) { S = null; save(); throw err('SIGNED_OUT', 'Please sign in again.'); } throw e; });
  }
  function token() { return refresh(false); }

  /* ---------------- server functions (callable) */
  C.call = function (name, data) {
    if (!C.ready) return Promise.reject(err('NOT_CONFIGURED', 'The account server is not set up in this build.'));
    return token().then(function (t) {
      var url = 'https://' + (FB.region || 'us-central1') + '-' + FB.projectId + '.cloudfunctions.net/' + name;
      return post(url, { data: data || {} }, { Authorization: 'Bearer ' + t }).then(function (j) { return j.result; }, function (e) {
        if (e && e.code) throw e; var m = e && e.body && e.body.error && e.body.error.message; throw err((e && e.body && e.body.error && e.body.error.status) || 'SERVER', m || 'The server did not answer. Try again.');
      });
    });
  };
  C.status = function () { return C.call('status', {}); };
  C.deleteAccount = function () { return C.call('deleteMe', {}).then(function () { return C.signOut(); }); };
})();
