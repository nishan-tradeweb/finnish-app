/* First run: offers a short sample script, "The Carnival", so a new writer sees the screenplay format straight away. */
(function () {
  'use strict';
  var A = THK.app, el = A.el, KEY = 'fn_tour';
  function seen() { try { return localStorage.getItem(KEY) === '1'; } catch (e) { return true; } }
  function mark() { try { localStorage.setItem(KEY, '1'); } catch (e) { } }
  var L = [
    ['scene', 'EXT. VILLAGE FAIR - EVENING'],
    ['action', 'Paper lanterns sway over a crowded field. A rickety Ferris wheel creaks round. MEERA (30s, ink on her fingers) pushes through the crowd, a notebook under her arm.'],
    ['char', 'MEERA'],
    ['paren', 'to herself'],
    ['dial', 'Three stalls, one wheel, and not a single story worth telling.'],
    ['action', 'A bell rings. Everyone turns. At the far end, a TALL MAN in a faded red coat climbs onto a crate.'],
    ['char', 'RINGMASTER'],
    ['dial', 'Ladies and gentlemen, tonight the carnival tells you a secret.'],
    ['char', 'MEERA'],
    ['dial', 'There it is.'],
    ['action', 'She opens the notebook and begins to write.'],
    ['trans', 'CUT TO:'],
    ['scene', 'INT. MEERA\'S ROOM - NIGHT'],
    ['action', 'The same notebook lies open on a desk. The first line reads: "Write. That\'s it."']
  ];
  function make() {
    var d = A.newDoc('std', 'a4', { title: 'The Carnival', writer: 'finnish sample', date: '' });
    d.blocks = L.map(function (b) { var o = { id: A.uid(), t: b[0], x: b[1] }; if (b[0] === 'scene') o.x2 = ''; return o; });
    A.openDoc(d, true);
    setTimeout(function () {
      A.dlg('This is how a script looks', '<p>This sample, <b>The Carnival</b>, shows scene headings, action, character names, dialogue and a transition.</p><ul style="text-align:left;padding-left:20px"><li>Tap any line and type to change it.</li><li>Press <b>Enter</b> for the next line. The line type follows automatically.</li><li>Use the bar above the keyboard to change a line’s type.</li><li>Open <b>More → How to use</b> for the full guide. You can delete this sample any time.</li></ul>', [{ l: 'Start writing', cls: 'pri' }]);
    }, 500);
  }
  function offer() {
    mark();
    A.dlg('Welcome to finnish', '<p>Want to see how a script looks? We can open a short sample called <b>The Carnival</b>. You can edit or delete it.</p>', [{ l: 'No thanks' }, { l: 'Open the sample', cls: 'pri', fn: function () { setTimeout(make, 100); } }]);
  }
  var iv = setInterval(function () {
    if (seen()) { clearInterval(iv); return; }
    if (!THK.acct || !THK.acct.canEdit() || A.cur || document.getElementById('fnwall') || document.querySelector('#layer .dlg') || document.getElementById('splash')) return;
    clearInterval(iv); offer();
  }, 1500);
})();
