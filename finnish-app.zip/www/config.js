/* finnish – settings you fill in once (see FIREBASE_SETUP.md). Nothing here is secret except desktopClientSecret,
   which Google treats as public for installed apps. Leave the other values exactly as they are. */
window.FINNISH_CONFIG = {
  version: '1.0.0',
  firebase: {
    apiKey: '',          /* Firebase console → Project settings → General → Web API Key */
    projectId: '',       /* e.g. finnish-writer */
    region: 'us-central1'
  },
  google: {
    webClientId: '',       /* Google Cloud → Credentials → OAuth client "Web application" */
    androidClientId: '',   /* OAuth client "Android" (package app.finnish.writer + your release SHA-1) */
    desktopClientId: '',   /* OAuth client "Desktop app" (Windows and Mac installers) */
    desktopClientSecret: ''
  },
  billingLive: false,      /* switch to true only after the store subscriptions exist and the billing step in FIREBASE_SETUP.md is done */
  webAppUrl: 'https://nishan-tradeweb.github.io/finnish-app/',
  support: 'mailstonishan@gmail.com'
};
