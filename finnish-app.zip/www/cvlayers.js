/* Layer-based cover page: model, templates (all cover styles), renderer (editor + preview + print).
   d.cl = { v:1, bg:{c,img,fit,op,bl,ov,ova,fx,fy}, items:[ {id,k,n,bind,x,y,w,h,r,t,f,s,c,b,i,u,up,ls,lh,al,va,op,sh,fill,bw,bc,bs,rad,bl,pd,src,fit,lock,hide} ] }
   x,y,w,h are percentages of the page, font sizes are in pt, radius / padding / blur in mm. */
(function () {
  'use strict';
  var CV = THK.cv, esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var cnt = 0; function nid() { return 'i' + Date.now().toString(36).slice(-4) + (cnt++).toString(36) + Math.random().toString(36).slice(2, 4); }
  CV.nid = nid;
  CV.BIND = { title: 'Main title', writer: 'Writer', director: 'Director', date: 'Date', basedOn: 'Based on', contact: 'Contact', draft: 'Draft' };
  CV.dim = function (d) { var P = THK.paperOf(d); return { w: parseFloat(P.w), h: parseFloat(P.h) }; };
  CV.hasLayers = function (d) { return !!(d && d.cl && d.cl.items); };

  /* ---------------------------------------------------------------- text of an item */
  CV.textOf = function (d, it) {
    if (it.bind) { var v = d[it.bind]; if (it.bind === 'date' && !v) v = THK.todayStr(); return v || ''; }
    return it.t || '';
  };
  CV.fontsOf = function (d) { var ids = []; if (CV.hasLayers(d)) d.cl.items.forEach(function (it) { if (it.f && ids.indexOf(it.f) < 0) ids.push(it.f); }); return ids; };

  /* ---------------------------------------------------------------- rendering */
  function box(it) {
    var s = 'left:' + it.x + '%;top:' + it.y + '%;width:' + it.w + '%;height:' + it.h + '%;';
    if (it.r) s += 'transform:rotate(' + it.r + 'deg);';
    if (it.op != null && it.op < 1) s += 'opacity:' + it.op + ';';
    if (it.fill) s += 'background:' + it.fill + ';';
    if (it.bw) s += 'border:' + it.bw + 'pt ' + (it.bs || 'solid') + ' ' + (it.bc || '#000') + ';';
    if (it.k === 'ellipse') s += 'border-radius:50%;'; else if (it.rad) s += 'border-radius:' + it.rad + 'mm;';
    if (it.bl) s += 'filter:blur(' + it.bl + 'mm);';
    if (it.sh && it.k !== 'text') s += 'box-shadow:0 1mm 3mm rgba(0,0,0,.3);';
    return s;
  }
  CV.itemHtml = function (d, it, edit) {
    if (it.hide) return '';
    var cls = 'cvi k-' + it.k + (it.lock && edit ? ' lk' : ''), a = ' data-i="' + it.id + '"', inner = '';
    if (it.k === 'text') {
      var f = it.f || (it.bind === 'title' ? (d.titleFont || d.font) : d.font), v = CV.textOf(d, it), runs = it.bind && (d.cfm || {})[it.bind];
      var ts = 'font-family:' + THK.fontStack(f) + ';font-size:' + (it.s || 12) + 'pt;color:' + (it.c || d.textColor || '#000') + ';text-align:' + (it.al || 'left') + ';font-weight:' + (it.b ? 700 : 400) + ';' +
        (it.i ? 'font-style:italic;' : '') + (it.u ? 'text-decoration:underline;' : '') + (it.up ? 'text-transform:uppercase;' : '') + 'letter-spacing:' + (it.ls || 0) + 'em;line-height:' + (it.lh || 1.25) + ';' +
        (it.sh ? 'text-shadow:0 .4mm 1.6mm rgba(0,0,0,.4);' : '');
      var body = runs && runs.length && v ? THK.richHtml(v, runs) : esc(v);
      inner = '<div class="cvt" style="' + ts + '"' + (edit ? ' data-ph="' + esc(CV.BIND[it.bind] || 'Text') + '"' : '') + '>' + body + '</div>';
      cls += ' t va-' + (it.va || 'top');
    } else if (it.k === 'img' && it.src) {
      inner = '<img class="cvm" src="' + esc(it.src) + '" alt="" draggable="false" style="object-fit:' + (it.fit === 'contain' ? 'contain' : it.fit === 'fill' ? 'fill' : 'cover') + (it.rad ? ';border-radius:' + it.rad + 'mm' : '') + '">';
    }
    var st = box(it) + (it.k === 'text' && it.pd ? 'padding:' + it.pd + 'mm;' : '');
    return '<div class="' + cls + '"' + a + ' style="' + st + '">' + inner + '</div>';
  };
  CV.bgHtml = function (d) {
    var b = d.cl.bg || {}, s = '<div class="cvbg" style="background:' + (b.c || d.pageColor || '#fff') + '"></div>';
    if (b.img) {
      var sz = b.fit === 'contain' ? 'contain' : b.fit === 'fill' ? '100% 100%' : b.fit === 'tile' ? '40mm auto' : 'cover';
      s += '<div class="cvbg" style="background-image:url(\'' + b.img.replace(/'/g, '%27') + '\');background-size:' + sz + ';background-position:' + (b.fx == null ? 50 : b.fx) + '% ' + (b.fy == null ? 50 : b.fy) + '%;background-repeat:' + (b.fit === 'tile' ? 'repeat' : 'no-repeat') + ';' + (b.op != null && b.op < 1 ? 'opacity:' + b.op + ';' : '') + (b.bl ? 'filter:blur(' + b.bl + 'mm);transform:scale(1.08);' : '') + '"></div>';
    }
    if (b.ov && b.ova) s += '<div class="cvbg" style="background:' + b.ov + ';opacity:' + b.ova + '"></div>';
    return s;
  };
  CV.pageHtml = function (d, edit) { return CV.bgHtml(d) + d.cl.items.map(function (it) { return CV.itemHtml(d, it, edit); }).join(''); };
  CV.layerCss = function () {
    return '.cvpg{position:relative;overflow:hidden;-webkit-print-color-adjust:exact;print-color-adjust:exact;box-sizing:border-box}.cvpg *{box-sizing:border-box}' +
      '.cvpg .cvbg{position:absolute;inset:0;pointer-events:none}.cvpg .cvi{position:absolute;transform-origin:50% 50%}' +
      '.cvpg .cvi.t{display:flex;flex-direction:column}.cvpg .cvi.va-top{justify-content:flex-start}.cvpg .cvi.va-middle{justify-content:center}.cvpg .cvi.va-bottom{justify-content:flex-end}' +
      '.cvpg .cvt{width:100%;white-space:pre-wrap;overflow-wrap:anywhere;word-break:normal;margin:0}.cvpg .cvm{width:100%;height:100%;display:block;pointer-events:none}';
  };
  /* print section – a full-bleed page of its own */
  CV.sectionHtml = function (d) { var D = CV.dim(d); return '<section class="cvpg cvprint" style="width:' + D.w + 'mm;height:' + (D.h - 0.4) + 'mm">' + CV.pageHtml(d, false) + '</section>'; };
  CV.layerPrintCss = function (d, nobox) {
    var D = CV.dim(d); return '@page coverL{counter-reset:page 0;margin:0;' + nobox + '}' + CV.layerCss() + '.cvprint{page:coverL;break-after:page;page-break-after:always;position:relative}';
  };

  /* ---------------------------------------------------------------- templates (one per cover style) */
  function tx(n, bind, t, x, y, w, h, o) { var it = { id: nid(), k: 'text', n: n, x: x, y: y, w: w, h: h, s: 12 }; if (bind) it.bind = bind; else it.t = t; for (var k in o) it[k] = o[k]; return it; }
  function rc(n, x, y, w, h, fill, o) { var it = { id: nid(), k: 'rect', n: n, x: x, y: y, w: w, h: h, fill: fill }; for (var k in o) it[k] = o[k]; return it; }
  function fr(n, x, y, w, h, bw, bc, o) { var it = { id: nid(), k: 'rect', n: n, x: x, y: y, w: w, h: h, fill: '', bw: bw, bc: bc }; for (var k in o) it[k] = o[k]; return it; }
  function hexLum(h) { var m = /^#?([0-9a-f]{6})$/i.exec(h || ''); if (!m) return 0; var v = parseInt(m[1], 16); return (0.299 * (v >> 16) + 0.587 * ((v >> 8) & 255) + 0.114 * (v & 255)) / 255; }
  var SPEC = {
    classic: { al: 'center', ty: 33, th: 17, ts: 34, tb: 1, my: 56 },
    elegant: { al: 'center', ty: 36, th: 14, ts: 26, tb: 1, up: 1, ls: .12, my: 58, it: 1 },
    industry: { al: 'center', ty: 38, th: 13, ts: 23, tb: 1, up: 1, ls: .06, my: 58 },
    poster: { al: 'center', ty: 31, th: 24, ts: 42, tb: 1, up: 1, ls: .03, my: 62 },
    banner: { al: 'center', ty: 13, th: 15, ts: 28, tb: 1, up: 1, ls: .06, my: 42 },
    corners: { al: 'center', ty: 36, th: 17, ts: 32, tb: 1, my: 58 },
    editorial: { al: 'left', x: 10, w: 80, ty: 52, th: 20, ts: 36, tb: 1, my: 78, va: 'bottom' },
    spine: { al: 'left', x: 15, w: 76, ty: 34, th: 20, ts: 34, tb: 1, my: 60 },
    glow: { al: 'center', ty: 36, th: 17, ts: 34, tb: 1, my: 58 },
    modern: { al: 'left', x: 14, w: 76, ty: 50, th: 20, ts: 38, tb: 1, my: 78, va: 'bottom' },
    left: { al: 'left', x: 10, w: 80, ty: 18, th: 16, ts: 32, tb: 1, my: 38 },
    bold: { al: 'center', ty: 30, th: 17, ts: 38, tb: 1, up: 1, ls: .05, my: 58 },
    minimal: { al: 'left', x: 10, w: 80, ty: 68, th: 9, ts: 22, tb: 1, my: 80, va: 'bottom' },
    framed: { al: 'center', x: 14, w: 72, ty: 32, th: 17, ts: 30, tb: 1, my: 56 }
  };
  /* o: {acc, sz (multiplier), up, wide, al, v ('top'|'mid'|'low'), rule, fr, lbl ('by'|'plain')} */
  CV.template = function (d, id, o) {
    o = o || {}; var sp = SPEC[id] || SPEC.classic, tc = d.textColor || '#000000', pc = d.pageColor || '#ffffff', a = o.acc || tc, al = o.al || sp.al, left = al === 'left', sz = o.sz || 1;
    var X = sp.x != null ? sp.x : 12, W = sp.w != null ? sp.w : 76; if (left && sp.x == null) { X = 12; } if (!left && sp.al === 'left') { X = 12; W = 76; }
    var by = (o.lbl || (CV.BY[id] ? 'by' : 'plain')) === 'by', ys = 0, items = [], nm = [], up = o.up != null ? !!o.up : !!sp.up, ls = o.wide ? .14 : (sp.ls || 0);
    if (o.v === 'top') ys = -14; else if (o.v === 'low') ys = 24; else if (o.v === 'mid') ys = 0;
    var P = function (it) { it.mv = 1; return it; };
    var bandCol = a, bandTxt = hexLum(a) > .62 ? '#111111' : '#ffffff';
    var ty = sp.ty + ys, my = sp.my + ys, titleC = tc;
    /* decorations behind the text */
    if (id === 'elegant') { items.push(P(rc('Line', 45, ty - 2.2, 10, .16, a)), P(rc('Line', 45, ty + sp.th + 1.2, 10, .16, a))); }
    if (id === 'industry') items.push(P(rc('Line', 30, ty + sp.th + 1.5, 40, .12, a)));
    if (id === 'poster') { items.push(P(rc('Bar', 12, ty - 1.6, 76, .8, a)), P(rc('Bar', 12, ty + sp.th + .9, 76, .8, a))); }
    if (id === 'banner') { items.push(P(rc('Band', 0, ty - 3, 100, sp.th + 6, bandCol))); titleC = bandTxt; }
    if (id === 'corners') { [[6, 4.2], [94, 4.2], [6, 95.8], [94, 95.8]].forEach(function (c) { var hx = c[0] < 50 ? c[0] : c[0] - 9, vy = c[1] < 50 ? c[1] : c[1] - 6.4, vx = c[0] < 50 ? c[0] : c[0] - .22; items.push(rc('Corner', hx, c[1] < 50 ? c[1] : c[1] - .13, 9, .13, a)); items.push(rc('Corner', vx, vy, .22, 6.4, a)); }); }
    if (id === 'editorial') items.push(P(rc('Line', X, ty - 1.4, 12, .35, a)));
    if (id === 'spine') items.push(rc('Spine', 0, 0, 7.5, 100, a));
    if (id === 'glow') items.push(P(rc('Glow', 18, ty - 14, 64, 44, a, { k: 'ellipse', op: .3, bl: 24 })));
    if (id === 'modern') items.push(P(rc('Bar', X - 4, ty + 1, 1.6, sp.th - 2, a)));
    if (id === 'bold') items.push(P(rc('Rule', X, ty + sp.th + 1.2, W, .85, a)));
    if (id === 'framed') { items.push(fr('Frame', 6, 4.2, 88, 91.6, 1.4, a)); items.push(P(rc('Line', 20, ty + sp.th + 2, 60, .1, a))); }
    if (o.rule && o.rule !== 'none' && id !== 'bold') items.push(P(rc('Divider', X, ty + sp.th + 2, W, o.rule === 'thick' ? .55 : .16, a, o.rule === 'double' ? { fill: '', bw: 3.5, bc: a, bs: 'double', h: .9 } : null)));
    if (o.fr && o.fr !== 'none' && id !== 'framed') items.push(o.fr === 'double' ? fr('Frame', 5.5, 4, 89, 92, 4.5, a, { bs: 'double' }) : fr('Frame', 6, 4.2, 88, 91.6, 1.4, a));
    /* texts */
    var ts = Math.round(sp.ts * sz * 2) / 2, tcol = titleC;
    items.push(P(tx('Main title', 'title', '', X, ty, W, sp.th, { s: ts, b: sp.tb, up: up, ls: ls, al: al, va: sp.va || 'middle', c: tcol, lh: 1.15, f: d.titleFont || d.font })));
    var lc = tc, gap = 0, xx = X, ww = W;
    var lab = function (t, yy) { return P(tx('Label', '', t, xx, yy, ww, 3.2, { s: 9, al: al, c: lc, op: .68, i: id === 'elegant' || undefined, up: id === 'poster' || undefined, ls: id === 'poster' ? .14 : 0, f: d.font })); };
    var nmv = function (n, b, yy) { return P(tx(n, b, '', xx, yy, ww, 4.6, { s: 15, al: al, c: lc, f: d.font })); };
    if (by) { items.push(lab('Written by', my), nmv('Writer', 'writer', my + 3), lab('Directed by', my + 9.5), nmv('Director', 'director', my + 12.5)); }
    else { items.push(lab('Writer :', my), nmv('Writer', 'writer', my + 3), lab('Director :', my + 9.5), nmv('Director', 'director', my + 12.5)); }
    items.push(P(tx('Based on', 'basedOn', '', xx, my + 20, ww, 4, { s: 10.5, i: 1, al: al, c: lc, op: .85, f: d.font })));
    var fy = 90;
    items.push(tx('Contact', 'contact', '', 9, fy - 2, 42, 7, { s: 8.5, al: 'left', c: lc, lh: 1.4, va: 'bottom', op: .85, f: d.font }));
    items.push(tx('Draft', 'draft', '', 51, fy - 2.5, 40, 3.6, { s: 8.5, al: 'right', c: lc, op: .85, f: d.font }));
    items.push(tx('Date', 'date', '', 51, fy + 1.2, 40, 3.6, { s: 8.5, al: 'right', c: lc, op: .85, f: d.font }));
    if (id === 'spine') { items.forEach(function (it) { if (it.k === 'text' && (it.bind === 'contact')) { it.x = 15; } }); }
    if (d.logo) items.push({ id: nid(), k: 'img', n: 'Logo', x: left ? X : 38, y: Math.max(4, ty - 17 + 0), w: 24, h: 12, src: d.logo, fit: 'contain' });
    return { v: 1, bg: { c: pc }, items: items };
  };
  /* build layers from the older style + options so nothing the writer already set is lost */
  CV.fromStyle = function (d) { var o = CV.opts(d), x = (d.cvo || {}); return CV.template(d, o.st, { acc: o.acc, sz: o.sz, up: o.up, wide: o.wide, al: o.al || '', v: o.v, rule: o.rule, fr: o.fr, lbl: o.lbl }); };
  CV.norm = function (cl) {
    if (!cl || !Array.isArray(cl.items)) return null;
    cl.v = 1; cl.bg = cl.bg && typeof cl.bg === 'object' ? cl.bg : {};
    cl.items = cl.items.filter(function (it) { return it && typeof it === 'object' && ['text', 'img', 'rect', 'ellipse'].indexOf(it.k) >= 0; }).slice(0, 200).map(function (it) {
      it.id = String(it.id || nid()); ['x', 'y', 'w', 'h'].forEach(function (k) { it[k] = isFinite(+it[k]) ? +it[k] : 10; }); return it;
    });
    return cl;
  };
})();
