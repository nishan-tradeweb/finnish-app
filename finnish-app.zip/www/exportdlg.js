/* The Export window: one format dropdown, then only the options that belong to that format. */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, XD = THK.xd = {};
  var MIME = { docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' };

  XD.open = function () {
    var A = THK.app, d = A.cur, el = A.el, esc = A.esc;
    var hasImg = !!(THK.img && THK.img.has && THK.img.has(d)), hasSb = !!(THK.sb && THK.sb.has(d));
    var F = [['pdf', 'PDF', 'The printed script, ready to share or print. You can choose exactly which pages.'],
      ['pres', 'Presentation PDF', 'A page-by-page reading version made for presenting on a screen.'],
      ['docx', 'Word document (.docx)', 'An editable Word file that keeps your fonts, scene numbers and layout.'],
      ['epub', 'E-book (.epub)', 'A reflowable e-book for phones, tablets and e-readers.'],
      ['fdx', 'Final Draft (.fdx)', 'Opens in Final Draft and most other screenwriting software.'],
      ['fountain', 'Fountain (.fountain)', 'Plain-text screenplay format that any writing app can read.'],
      ].concat(THK.fmt ? THK.fmt.LIST.filter(function (x) { return x[0] !== 'zip'; }).map(function (x) { return [x[0], x[1], x[2]]; }) : [], [['zip', 'Whole project (.zip)', 'Everything in one zip: the backup, the script in every format, and all pictures and storyboard drawings as files.'],
      ['bak', 'Backup (.finnish)', 'Everything in this script, to restore or move to another device. Not a printable file.']]);
    if (hasSb) F.splice(1, 0, ['sb', 'Storyboard PDF', 'Only the storyboard: panels grouped by scene with shot numbers and camera labels.']);
    var st = { fmt: 'pdf', cover: true, marks: false, images: false, sbp: false, mode: 'all', range: '' }, total = null, tkey = '', tseq = 0;
    var box = el('div', 'xdlg'), sel = el('select', 't'), desc = el('div', 'xsub'), opts = el('div', 'xopts');
    F.forEach(function (f) { var o = el('option'); o.value = f[0]; o.textContent = f[1]; sel.appendChild(o); });
    var fh = el('div', 'xhd'); fh.textContent = 'Format'; box.appendChild(fh); box.appendChild(sel); A.upgradeSelect(sel); box.appendChild(desc); box.appendChild(opts);
    sel.onchange = function () { st.fmt = sel.value; draw(); };

    function pill(label, on, fn) { var b = el('button', 'btn' + (on ? ' on' : '')); b.type = 'button'; b.textContent = label; b.onclick = function () { fn(b); }; return b; }
    function head(t) { var h = el('div', 'xhd'); h.textContent = t; opts.appendChild(h); }
    function row() { var r = el('div', 'xrow'); opts.appendChild(r); return r; }
    function tog(r, label, key, after) { r.appendChild(pill(label, st[key], function (b) { st[key] = !st[key]; b.classList.toggle('on', st[key]); if (after) after(); })); }
    function pdfOpts() { var o = { cover: st.cover, marks: st.marks, images: st.images && hasImg }; return o; }

    function draw() {
      var f = F.filter(function (x) { return x[0] === st.fmt; })[0]; desc.textContent = f[2]; opts.innerHTML = '';
      if (st.fmt === 'pdf' || st.fmt === 'docx') {
        head('Include'); var r = row(); tog(r, 'Cover page', 'cover');
        if (st.fmt === 'pdf') { tog(r, 'Marker colours', 'marks', recount); if (hasImg) tog(r, 'Pictures', 'images', recount); if (hasSb) tog(r, 'Storyboard panels under scenes', 'sbp', recount); }
      }
      if (st.fmt === 'pdf') {
        head('Pages'); var r2 = row();
        r2.appendChild(pill('All pages', st.mode === 'all', function () { st.mode = 'all'; draw(); }));
        r2.appendChild(pill('Choose pages', st.mode === 'range', function () { st.mode = 'range'; draw(); setTimeout(function () { var i = box.querySelector('.xrng'); if (i) i.focus(); }, 60); }));
        if (st.mode === 'range') {
          var inp = el('input', 't xrng'); inp.type = 'text'; inp.inputMode = 'text'; inp.placeholder = 'e.g. 15-17   or   3, 8, 12-14'; inp.value = st.range; inp.autocomplete = 'off';
          inp.oninput = function () { st.range = inp.value; check(); }; opts.appendChild(inp);
          var info = el('div', 'xsub xinfo'); info.id = 'xinfo'; opts.appendChild(info);
          var tip = el('div', 'xsub'); tip.textContent = 'Pages are counted like the page numbers printed on the script (the cover is not counted). Use 200-200, or just 200, for a single page.'; opts.appendChild(tip);
          recount(); check();
        }
      }
      if (st.fmt === 'pdf' && st.mode === 'all' && false) { }
      var n = el('div', 'xsub'); n.textContent = st.fmt === 'pdf' || st.fmt === 'docx' ? 'If the export date on the cover is empty it is filled in automatically. The middle line of Two Column is never printed.' : ''; if (n.textContent) opts.appendChild(n);
    }
    function check() {
      var info = box.querySelector('#xinfo'); if (!info) return; var r = THK.pr.parse(st.range);
      info.classList.remove('bad');
      if (!st.range.trim()) info.textContent = total ? 'This script has ' + total + (total === 1 ? ' page.' : ' pages.') : 'Counting pages…';
      else if (!r) { info.textContent = 'Type pages like 15-17 or 3, 8, 12-14'; info.classList.add('bad'); }
      else if (total && r.every(function (x) { return x[0] > total; })) { info.textContent = 'This script has only ' + total + (total === 1 ? ' page.' : ' pages.'); info.classList.add('bad'); }
      else info.textContent = (total ? 'Will export page' + (THK.pr.label(r, total).match(/[-,]/) ? 's ' : ' ') + THK.pr.label(r, total) + ' of ' + total : 'Counting pages…');
    }
    function recount() {
      if (st.mode !== 'range' || st.fmt !== 'pdf') return; var o = pdfOpts(), k = JSON.stringify([o.marks, o.images, st.sbp]); if (k === tkey && total) { check(); return; }
      tkey = k; total = null; var my = ++tseq; check();
      Promise.resolve(st.sbp && hasSb ? THK.sb.maps() : null).then(function (M) { if (M) { o.sbMap = M.sbMap; o.sbNo = M.sbNo; o.sbLabel = M.sbLabel; } return THK.pr.count(d, o); }).then(function (n) { if (my === tseq) { total = n; check(); } }, function () { if (my === tseq) { var i = box.querySelector('#xinfo'); if (i) i.textContent = ''; } });
    }

    function later(fn) { A.syncOut(); setTimeout(function () { A.persist(); fn(); }, 60); }
    function go() {
      var f = st.fmt, name = A.fname();
      try {
        if (f === 'pdf') {
          var o = pdfOpts(), spec = st.mode === 'range' ? st.range : '';
          if (st.mode === 'range' && !THK.pr.parse(spec)) { A.toast('Type pages like 15-17 or 3, 8, 12-14'); return false; }
          later(function () {
            Promise.resolve(st.sbp && hasSb ? THK.sb.maps() : null).then(function (M) {
              if (M) { o.sbMap = M.sbMap; o.sbNo = M.sbNo; o.sbLabel = M.sbLabel; }
              if (spec) return THK.pr.print(d, o, spec); return THK.printScript(d, o);
            }).catch(function (e) { A.toast((e && e.message) || 'Could not make the PDF'); });
          });
        } else if (f === 'sb') later(function () { THK.sb.exportPdf(); });
        else if (f === 'pres') later(function () { THK.pro.present(); });
        else if (f === 'docx') { A.syncOut(); A.deliverBin(name + '.docx', MIME.docx, THK.x.docx(d, { cover: st.cover })); }
        else if (f === 'epub') { A.syncOut(); A.deliverBin(name + '.epub', 'application/epub+zip', THK.x.epub(d, {})); }
        else if (f === 'fdx') { A.syncOut(); A.deliver(name + '.fdx', 'application/xml', THK.toFDX(d)); }
        else if (f === 'fountain') { A.syncOut(); A.deliver(name + '.fountain', 'text/plain', THK.toFountain(d, true)); }
        else if (THK.fmt && THK.fmt.LIST.some(function (x) { return x[0] === f; })) { A.syncOut(); A.toast('Preparing…'); THK.fmt.build(f, d).then(function (r) { if (typeof r.data === 'string') A.deliver(name + '.' + r.ext, r.mime, r.data); else A.deliverBin(name + '.' + r.ext, r.mime, r.data); }).catch(function (e) { A.toast('Export failed: ' + ((e && e.message) || e)); }); }
        else if (f === 'bak') A.deliver(name + '.finnish', 'application/json', A.wrapFile());
      } catch (e) { A.toast('Export failed: ' + (e && e.message)); }
    }
    draw();
    A.dlg('Export', box, [{ l: 'Cancel' }, { l: 'Export', cls: 'pri', fn: go }]);
  };

  var st = document.createElement('style'); st.textContent =
    '.xdlg{display:flex;flex-direction:column;gap:8px;min-width:0}.xdlg .ddp{width:100%;justify-content:space-between}.xopts{display:flex;flex-direction:column;gap:8px}' +
    '.xdlg .xrow{display:flex;flex-wrap:wrap;gap:8px}.xdlg .xrng{width:100%}.xinfo{margin-top:-2px;min-height:1.2em}.xinfo.bad{color:#e5484d;opacity:1}.xdlg .xsub{opacity:.78;line-height:1.45}';
  document.head.appendChild(st);
})();
