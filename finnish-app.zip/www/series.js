/* Series (light) – a show folder holding episodes. Each episode is an ordinary script with d.series = { id, show, ep, epTitle, mc }.
   Episodes of one show share characters and locations (suggested while writing), have an episode title page, teaser / act / tag markers with page breaks,
   and a multi-camera switch (double-spaced dialogue, scenes lettered A, B, C, description in capitals). */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, S = THK.series = {};
  var A = function () { return THK.app; };
  var MARK = [
    { id: 'xcold', n: 'Cold open', al: 'left', ind: 0, col: 'f', up: 1, b: 1 },
    { id: 'xecold', n: 'End of cold open', al: 'left', ind: 0, col: 'f', up: 1, b: 1 },
    { id: 'xact', n: 'Act', al: 'center', ind: 0, col: 'f', up: 1, b: 1, u: 1 },
    { id: 'xeact', n: 'End of act', al: 'center', ind: 0, col: 'f', up: 1, b: 1 },
    { id: 'xtag', n: 'Tag', al: 'center', ind: 0, col: 'f', up: 1, b: 1, u: 1 },
    { id: 'xeep', n: 'End of episode', al: 'center', ind: 0, col: 'f', up: 1, b: 1 }
  ];
  var ORD = ['One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven'];
  function sid() { return 's' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function ensureMarks(d) {
    d.ct = d.ct || []; MARK.forEach(function (m) { if (!d.ct.some(function (t) { return t.id === m.id; })) d.ct.push(Object.assign({ c: '', pre: '', suf: '', i: 0 }, m)); });
    if (THK.el && THK.el.apply) THK.el.apply(d);
  }
  S.ensureMarks = ensureMarks;
  function titleOf(s) { return (s.show || 'Untitled show') + ' — Episode ' + s.ep + (s.epTitle ? ': ' + s.epTitle : ''); }

  /* ---- what the other episodes of the show contain ---- */
  var CACHE = {};
  S.refresh = function (d) {
    if (!d || !d.series) return Promise.resolve();
    var id = d.series.id; return A().DB.all().then(function (ds) {
      var chars = {}, locs = {}, eps = [];
      ds.forEach(function (x) {
        if (!x.series || x.series.id !== id) return; eps.push({ id: x.id, ep: x.series.ep, t: x.series.epTitle });
        (x.blocks || []).forEach(function (b) {
          var t = String(b.x || '').trim(); if (!t) return;
          if (b.t === 'char') { var n = t.replace(/\(.*?\)/g, '').replace(/\s+/g, ' ').trim().toUpperCase(); if (n) chars[n] = (chars[n] || 0) + 1; }
          else if (b.t === 'scene' && THK.parseHeading) { var p = THK.parseHeading(b); if (p.loc) { var k = p.loc.toUpperCase(); locs[k] = (locs[k] || 0) + 1; } }
        });
      });
      var top = function (o) { return Object.keys(o).sort(function (a, b) { return o[b] - o[a]; }); };
      CACHE[id] = { chars: top(chars), locs: top(locs), eps: eps.sort(function (a, b) { return a.ep - b.ep; }) };
    }).catch(function () { });
  };
  S.cast = function (d) { var c = d && d.series && CACHE[d.series.id]; return c ? c.chars : []; };

  /* ---- home screen ---- */
  S.sorter = function (a, b) {
    var sa = a.series ? String(a.series.show).toLowerCase() : null, sb = b.series ? String(b.series.show).toLowerCase() : null;
    if (!sa && !sb) return b.updated - a.updated; if (!sa) return -1; if (!sb) return 1;
    return sa === sb ? a.series.ep - b.series.ep : (sa < sb ? -1 : 1);
  };
  S.tag = function (d) { return d.series ? 'Series' : d.fmt === 'two' ? 'Two column' : 'Standard'; };
  var lastHead = null;
  S.groupHead = function (list, d) {
    if (!d.series) { lastHead = null; return; } if (lastHead === d.series.id) return; lastHead = d.series.id;
    list.appendChild(A().el('div', 'xsub', '<b>' + A().esc(d.series.show) + '</b> · show folder'));
  };
  S.resetHead = function () { lastHead = null; };

  /* ---- new episode ---- */
  S.start = function () {
    var a = A(), el = a.el;
    a.DB.all().then(function (ds) {
      var shows = {}; ds.forEach(function (d) { if (d.series) { var s = shows[d.series.id] = shows[d.series.id] || { id: d.series.id, show: d.series.show, n: 0, mc: d.series.mc }; s.n = Math.max(s.n, d.series.ep); } });
      var list = Object.keys(shows).map(function (k) { return shows[k]; });
      var body = el('div', 'xdlg'), sel = el('select', 't'), nm = el('input', 't'), ep = el('input', 't'), et = el('input', 't'), mc = el('input'); mc.type = 'checkbox';
      sel.innerHTML = '<option value="">New show</option>' + list.map(function (s) { return '<option value="' + s.id + '">' + a.esc(s.show) + '</option>'; }).join('');
      nm.placeholder = 'Name of the show'; ep.type = 'number'; ep.min = 1; ep.value = 1; et.placeholder = 'Episode title (optional)';
      function lab(t) { return el('label', '', t); }
      if (list.length) { body.appendChild(lab('Show')); body.appendChild(sel); }
      body.appendChild(lab('Show name')); body.appendChild(nm); body.appendChild(lab('Episode number')); body.appendChild(ep); body.appendChild(lab('Episode title')); body.appendChild(et);
      var r = el('label', '', ''); r.style.cssText = 'display:flex;gap:10px;align-items:center;margin-top:12px'; r.appendChild(mc); r.appendChild(document.createTextNode('Multi-camera (double-spaced dialogue, scenes lettered A, B, C)')); body.appendChild(r);
      sel.onchange = function () { var s = list.filter(function (x) { return x.id === sel.value; })[0]; nm.disabled = !!s; if (s) { nm.value = s.show; ep.value = s.n + 1; mc.checked = !!s.mc; } else { nm.value = ''; ep.value = 1; } };
      a.dlg('New episode', body, [{ l: 'Cancel' }, { l: 'Create', cls: 'pri', fn: function () {
        var s0 = list.filter(function (x) { return x.id === sel.value; })[0], show = (s0 ? s0.show : nm.value).trim();
        if (!show) { a.toast('Give the show a name'); return false; }
        var ser = { id: s0 ? s0.id : sid(), show: show, ep: Math.max(1, +ep.value || 1), epTitle: et.value.trim(), mc: mc.checked };
        var d = a.newDoc('std', 'a4', { title: titleOf(ser), writer: '', director: '', date: '' });
        d.series = ser; ensureMarks(d); if (ser.mc && THK.layouts) { /* multi-camera keeps the layout; spacing and letters come from the series flag */ }
        a.openDoc(d); setTimeout(function () { a.toast('Episode ' + ser.ep + ' created · ⋯ menu → Series for acts and markers'); }, 400);
      } }]);
    });
  };

  /* ---- inside an episode ---- */
  function insert(d, t, text, pb, afterCur) {
    var a = A(), cb = a.cur && a.cb, i = cb ? d.blocks.indexOf(cb) : d.blocks.length - 1; if (i < 0) i = d.blocks.length - 1;
    var blk = { id: a.uid(), t: t, x: text || '' }; if (pb) blk.pb = true; d.blocks.splice(i + 1, 0, blk); return blk;
  }
  function done(d, focusBlk) { var a = A(); a.renderAll(); a.dirty(); if (a.persist) a.persist(); if (focusBlk) a.focusBlock(focusBlk.id); }
  function actCount(d) { return d.blocks.filter(function (b) { return b.t === 'xact'; }).length; }
  function addAct() {
    var a = A(), d = a.cur; ensureMarks(d); a.snap && a.snap(); var n = actCount(d) + 1;
    var hasCold = d.blocks.some(function (b) { return b.t === 'xcold'; }); if (n === 1 && !hasCold) { /* first act begins straight after the teaser */ }
    if (n > 1) insert(d, 'xeact', 'End of act ' + ORD[n - 2].toLowerCase());
    var b = insert(d, 'xact', 'Act ' + (ORD[n - 1] || n), true); var s = insert(d, 'scene', ''); done(d, s);
  }
  function addMark(t, label, pb) { var a = A(), d = a.cur; ensureMarks(d); a.snap && a.snap(); var b = insert(d, t, label, pb); var nx = insert(d, t === 'xeep' ? 'action' : 'scene', ''); done(d, nx); }
  function refreshTitle(d) { if (d.series) { d.title = titleOf(d.series); d.cfm = d.cfm || {}; delete d.cfm.title; } }

  S.dialog = function () {
    var a = A(), d = a.cur, el = a.el; if (!d) return a.toast('Open a script first');
    var body = el('div', 'xdlg'), ser = d.series;
    function row(label, sub, fn, on) { var b = el('button', 'btn' + (on ? ' on' : ''), '<b>' + a.esc(label) + '</b>' + (sub ? '<br><small>' + a.esc(sub) + '</small>' : '')); b.style.cssText = 'display:block;width:100%;text-align:left;margin:6px 0;height:auto;padding:10px 14px;white-space:normal'; b.onclick = fn; body.appendChild(b); return b; }
    if (!ser) {
      body.appendChild(el('p', '', 'Turn this script into an episode of a show to get a title page, teaser/act/tag markers and the multi-camera layout.'));
      row('Make this an episode', 'Adds a show folder and the series markers', function () {
        var nm = el('input', 't'); nm.placeholder = 'Name of the show';
        a.dlg('Show name', nm, [{ l: 'Cancel' }, { l: 'Continue', cls: 'pri', fn: function () { var s = nm.value.trim(); if (!s) { a.toast('Give the show a name'); return false; } d.series = { id: sid(), show: s, ep: 1, epTitle: '', mc: false }; ensureMarks(d); refreshTitle(d); a.applyLook(); a.renderAll(); a.dirty(); a.persist && a.persist(); setTimeout(S.dialog, 200); } }]);
      });
      return a.dlg('Series', body, [{ l: 'Close', cls: 'pri' }]);
    }
    body.appendChild(el('div', 'xsub', '<b>' + a.esc(ser.show) + '</b> · Episode ' + ser.ep + (ser.epTitle ? ' · ' + a.esc(ser.epTitle) : '')));
    row('Episode title page…', 'Show name, episode number and title', function () {
      var f = el('div', ''), n = el('input', 't'), e = el('input', 't'), t = el('input', 't'); n.value = ser.show; e.type = 'number'; e.value = ser.ep; t.value = ser.epTitle;
      f.appendChild(el('label', '', 'Show name')); f.appendChild(n); f.appendChild(el('label', '', 'Episode number')); f.appendChild(e); f.appendChild(el('label', '', 'Episode title')); f.appendChild(t);
      a.dlg('Episode title page', f, [{ l: 'Cancel' }, { l: 'Save', cls: 'pri', fn: function () { ser.show = n.value.trim() || ser.show; ser.ep = Math.max(1, +e.value || 1); ser.epTitle = t.value.trim(); refreshTitle(d); a.renderAll(); a.applyLook(); a.dirty(); a.persist && a.persist(); a.toast('Title page updated'); } }]);
    });
    row('Cold open (teaser)', 'Marks the start of the teaser', function () { addMark('xcold', 'Cold open', false); });
    row('End of cold open', 'Closes the teaser', function () { addMark('xecold', 'End cold open', false); });
    row('New act', 'Closes the last act and starts the next on a new page', addAct);
    row('Tag', 'A short closing scene after the last act, on a new page', function () { addMark('xtag', 'Tag', true); });
    row('End of episode', '', function () { addMark('xeep', 'End of episode', false); });
    row('Multi-camera layout: ' + (ser.mc ? 'On' : 'Off'), 'Double-spaced dialogue, scenes lettered A, B, C, description in capitals', function () { a.snap && a.snap(); ser.mc = !ser.mc; a.applyLook(); a.renderAll(); a.dirty(); a.persist && a.persist(); a.toast('Multi-camera ' + (ser.mc ? 'on' : 'off')); }, ser.mc);
    var c = CACHE[ser.id];
    var box = el('div', 'xsub', 'Loading the rest of the show…'); body.appendChild(box);
    S.refresh(d).then(function () {
      c = CACHE[ser.id]; if (!c) return; box.innerHTML = '';
      box.appendChild(el('div', '', '<b>' + c.eps.length + ' episode' + (c.eps.length === 1 ? '' : 's') + ' in this show</b>'));
      if (c.chars.length) { box.appendChild(el('div', '', 'Characters: ' + a.esc(c.chars.slice(0, 14).join(', ')) + ' – offered as suggestions in every episode.')); }
      if (c.locs.length) { box.appendChild(el('div', '', 'Locations: ' + a.esc(c.locs.slice(0, 10).join(', ')))); }
    });
    a.dlg('Series', body, [{ l: 'Done', cls: 'pri' }]);
  };
})();
