/* finnish – extra screenplay file formats.
   Export + import: .txt .csv .rtf .html .md .odt .xlsx .celtx .zip (whole project) and .screenplay / .cxscript / .sbx (best-effort containers).
   (.fountain, .fdx, .docx, .epub, .pdf and the finnish backup live in export.js / import.js / extras.js.) */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, F = THK.fmt = {};
  var enc = new TextEncoder();
  function uid() { return Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4); }
  function xe(s) { return String(s == null ? '' : s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function bytes(s) { return typeof s === 'string' ? enc.encode(s) : s; }
  function decode(u8) { // utf-8 (with or without BOM); falls back to Windows-1252 for old files
    var s; try { s = new TextDecoder('utf-8', { fatal: true }).decode(u8); } catch (e) { s = new TextDecoder('windows-1252').decode(u8); }
    return s.replace(/^\uFEFF/, '');
  }

  /* ---------------------------------------------------------------- zip (write with compression, read anything) */
  var CRC = (function () { var t = []; for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(u) { var c = 0xFFFFFFFF; for (var i = 0; i < u.length; i++) c = CRC[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function deflate(u8) {
    if (typeof CompressionStream === 'undefined') return Promise.resolve(null);
    return new Response(new Blob([u8]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer().then(function (ab) { return new Uint8Array(ab); }, function () { return null; });
  }
  F.zip = function (files, stored) { // files: {name: string|Uint8Array}; stored: names kept uncompressed (e.g. "mimetype")
    var names = Object.keys(files), parts = [], cd = [], off = 0, sto = stored || [];
    function w16(a, v) { a.push(v & 255, (v >> 8) & 255); } function w32(a, v) { a.push(v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >>> 24) & 255); }
    return names.reduce(function (p, n) {
      return p.then(function () {
        var d = bytes(files[n]), nm = enc.encode(n), c = crc32(d), small = d.length < 64 || sto.indexOf(n) >= 0 || /\.(png|jpe?g|webp|gif|zip|docx|xlsx|odt|epub)$/i.test(n);
        return (small ? Promise.resolve(null) : deflate(d)).then(function (z) {
          var m = z && z.length < d.length ? 8 : 0, body = m ? z : d, h = [];
          w32(h, 0x04034b50); w16(h, 20); w16(h, 0x0800); w16(h, m); w16(h, 0); w16(h, 0x5821); w32(h, c); w32(h, body.length); w32(h, d.length); w16(h, nm.length); w16(h, 0);
          parts.push(new Uint8Array(h), nm, body);
          var e = []; w32(e, 0x02014b50); w16(e, 20); w16(e, 20); w16(e, 0x0800); w16(e, m); w16(e, 0); w16(e, 0x5821); w32(e, c); w32(e, body.length); w32(e, d.length); w16(e, nm.length); w16(e, 0); w16(e, 0); w16(e, 0); w16(e, 0); w32(e, 0); w32(e, off);
          cd.push(new Uint8Array(e), nm); off += h.length + nm.length + body.length;
        });
      });
    }, Promise.resolve()).then(function () {
      var cdLen = cd.reduce(function (n, p) { return n + p.length; }, 0), end = []; w32(end, 0x06054b50); w16(end, 0); w16(end, 0); w16(end, names.length); w16(end, names.length); w32(end, cdLen); w32(end, off); w16(end, 0);
      var all = parts.concat(cd, [new Uint8Array(end)]), len = all.reduce(function (n, p) { return n + p.length; }, 0), out = new Uint8Array(len), q = 0; all.forEach(function (p) { out.set(p, q); q += p.length; }); return out;
    });
  };
  function u16(b, o) { return b[o] | (b[o + 1] << 8); } function u32(b, o) { return (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0; }
  F.unzip = function (buf) { // -> Promise<{name: Uint8Array}> (everything, so small project files only)
    var b = new Uint8Array(buf), e = b.length - 22; while (e >= 0 && u32(b, e) !== 0x06054b50) e--;
    if (e < 0) return Promise.reject(new Error('This is not a valid zip-based file.'));
    var n = u16(b, e + 10), p = u32(b, e + 16), list = [];
    for (var i = 0; i < n; i++) {
      if (u32(b, p) !== 0x02014b50) break; var nl = u16(b, p + 28), xl = u16(b, p + 30), cl = u16(b, p + 32);
      list.push({ name: new TextDecoder().decode(b.subarray(p + 46, p + 46 + nl)), m: u16(b, p + 10), cs: u32(b, p + 20), off: u32(b, p + 42) }); p += 46 + nl + xl + cl;
    }
    var out = {};
    return list.reduce(function (pr, en) {
      return pr.then(function () {
        if (/\/$/.test(en.name)) return; var o = en.off, ds = o + 30 + u16(b, o + 26) + u16(b, o + 28), raw = b.subarray(ds, ds + en.cs);
        if (en.m === 0) { out[en.name] = raw.slice(); return; }
        if (typeof DecompressionStream === 'undefined') throw new Error('This device cannot unpack compressed files. Open the file on a newer phone or save it as .fdx / .txt first.');
        return new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer().then(function (ab) { out[en.name] = new Uint8Array(ab); });
      });
    }, Promise.resolve()).then(function () { return out; });
  };
  function xml(u8) { return new DOMParser().parseFromString(decode(u8), 'application/xml'); }
  function tags(n, name) { return Array.prototype.slice.call(n.getElementsByTagNameNS('*', name)); }

  /* ---------------------------------------------------------------- reading the script as plain lines */
  var LABEL = { scene: 'Scene Heading', action: 'Action', char: 'Character', paren: 'Parenthetical', dial: 'Dialogue', trans: 'Transition', shot: 'Shot', note: 'Note' };
  function lines(d) { // [{t, x, fm, no, pb, spk}]
    var SNM = THK.sceneNums ? THK.sceneNums(d) : {}, out = [], spk = '';
    d.blocks.forEach(function (b) {
      var t = b.t, x = b.x || '', fm = (b.fm && b.fm.x) || null, no = '';
      if (t === 'img') return;
      if (t === 'scene') { no = SNM[b.id] || ''; if (!(fm && fm.length) && THK.stripSn) x = THK.stripSn(x); if (b.x2) x += ' – ' + b.x2; }
      else if (['action', 'char', 'paren', 'dial', 'trans', 'shot', 'note'].indexOf(t) < 0) { var ct = THK.el && THK.el.get(d, t); if (ct) { x = ct.pre + (ct.up ? x.toUpperCase() : x) + ct.suf; fm = null; } t = 'action'; }
      if (!x.trim() && !b.pb) return;
      if (t === 'char') spk = x.trim().replace(/\s*\(.*\)\s*$/, ''); else if (t === 'scene' || t === 'action' || t === 'trans' || t === 'shot') spk = '';
      out.push({ t: t, x: x, fm: fm, no: no, pb: !!b.pb, spk: (t === 'dial' || t === 'paren' || t === 'char') ? spk : '' });
    });
    return out;
  }
  function segs(x, fm) { // [{s, b, i, u}] – bold / italic / underline runs
    var pts = [0, x.length]; (fm || []).forEach(function (r) { pts.push(r.s, r.e); });
    pts = pts.filter(function (p, i, a) { return p >= 0 && p <= x.length && a.indexOf(p) === i; }).sort(function (a, b) { return a - b; });
    var o = []; for (var i = 0; i < pts.length - 1; i++) {
      var p = pts[i], q = pts[i + 1], a = { s: x.slice(p, q) }; (fm || []).forEach(function (r) { if (r.s <= p && p < r.e) { if (r.b) a.b = 1; if (r.i) a.i = 1; if (r.u) a.u = 1; } }); if (a.s) o.push(a);
    } return o;
  }
  function meta(d) { return { title: d.title || 'Untitled', writer: d.writer || d.author || '', director: d.director || '', date: d.date || '' }; }
  function wrap(text, w) {
    var out = []; String(text).split('\n').forEach(function (para) {
      var words = para.split(/(\s+)/), cur = '';
      words.forEach(function (tk) {
        var len = Array.from(cur + tk).length;
        if (len > w && cur.trim()) { out.push(cur.replace(/\s+$/, '')); cur = tk.replace(/^\s+/, ''); } else cur += tk;
        while (Array.from(cur).length > w) { var ch = Array.from(cur); out.push(ch.slice(0, w).join('')); cur = ch.slice(w).join(''); }
      }); out.push(cur.replace(/\s+$/, ''));
    }); return out;
  }
  function pad(n) { return new Array(Math.max(0, n) + 1).join(' '); }

  /* ---------------------------------------------------------------- TXT */
  F.toTxt = function (d) {
    var m = meta(d), o = [], W = 60;
    function ctr(s) { return pad(Math.floor((W - Array.from(s).length) / 2)) + s; }
    o.push('', '', '', '', ctr(m.title.toUpperCase()), ''); if (m.writer) o.push(ctr('Written by ' + m.writer), ''); if (m.director) o.push(ctr('Director: ' + m.director), ''); if (m.date) o.push(ctr(m.date)); o.push('', '\f');
    lines(d).forEach(function (l) {
      if (l.pb) o.push('\f');
      var x = l.x.replace(/\s+$/, '');
      if (l.t === 'scene') { o.push('', (l.no ? l.no + '  ' : '') + x.toUpperCase(), ''); }
      else if (l.t === 'char') { o.push('', pad(22) + x.toUpperCase()); }
      else if (l.t === 'paren') wrap('(' + x.replace(/^\(|\)$/g, '') + ')', 25).forEach(function (r) { o.push(pad(16) + r); });
      else if (l.t === 'dial') wrap(x, 35).forEach(function (r) { o.push(pad(10) + r); });
      else if (l.t === 'trans') { var u = x.toUpperCase(); o.push('', pad(Math.max(0, W - Array.from(u).length)) + u, ''); }
      else if (l.t === 'shot') o.push('', x.toUpperCase(), '');
      else if (l.t === 'note') { o.push(''); wrap('[[' + x + ']]', W).forEach(function (r) { o.push(r); }); }
      else { o.push(''); wrap(x, W).forEach(function (r) { o.push(r); }); }
    });
    return o.join('\n').replace(/\n{4,}/g, '\n\n\n') + '\n';
  };

  /* ---------------------------------------------------------------- tables (CSV / XLSX) */
  var HEAD = ['Scene', 'Element', 'Character', 'Text'];
  function table(d) { var rows = [HEAD.slice()]; lines(d).forEach(function (l) { rows.push([l.no === '' ? '' : String(l.no), LABEL[l.t] || 'Action', l.spk, l.x]); }); return rows; }
  F.toCsv = function (d) {
    return '\uFEFF' + table(d).map(function (r) { return r.map(function (c) { c = String(c); return /[",\r\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(','); }).join('\r\n') + '\r\n';
  };
  function parseCsv(text) {
    var rows = [], row = [], cell = '', q = false, delim = null;
    var first = text.split(/\r?\n/)[0] || ''; delim = (first.match(/;/g) || []).length > (first.match(/,/g) || []).length ? ';' : ((first.match(/\t/g) || []).length > (first.match(/,/g) || []).length ? '\t' : ',');
    for (var i = 0; i < text.length; i++) {
      var c = text[i];
      if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
      else if (c === '"') q = true; else if (c === delim) { row.push(cell); cell = ''; }
      else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
      else cell += c;
    }
    if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
    return rows.filter(function (r) { return r.some(function (c) { return String(c).trim() !== ''; }); });
  }
  var KIND = [[/^(scene|slug|heading|sceneheading|scene heading)/, 'scene'], [/^(parenth|paren|wryly)/, 'paren'], [/^(char|speaker|name)/, 'char'], [/^(dial|speech|line)/, 'dial'], [/^(trans)/, 'trans'], [/^(shot|camera)/, 'shot'], [/^(note)/, 'note'], [/^(action|general|description|desc)/, 'action']];
  function kindOf(s) { s = String(s || '').toLowerCase().replace(/[^a-z ]/g, '').trim(); for (var i = 0; i < KIND.length; i++) if (KIND[i][0].test(s)) return KIND[i][1]; return ''; }
  function fromTable(rows, fname) {
    if (!rows.length) throw new Error('This table is empty.');
    var hd = rows[0].map(function (h) { return String(h || '').toLowerCase().trim(); });
    var ci = hd.findIndex(function (h) { return /^(element|type|style|kind|format)$/.test(h); }), ti = hd.findIndex(function (h) { return /^(text|content|line|script|dialogue|description|words)$/.test(h); });
    var d = THK.newImportDoc(fname.replace(/\.[^.]+$/, ''));
    if (ci >= 0 && ti >= 0) {
      rows.slice(1).forEach(function (r) {
        var t = kindOf(r[ci]) || 'action', x = String(r[ti] == null ? '' : r[ti]).replace(/\r/g, '').trim(); if (!x) return;
        if (t === 'paren') x = x.replace(/^\(\s*|\s*\)$/g, ''); var b = { id: uid(), t: t, x: x }; if (t === 'scene') b.x2 = ''; d.blocks.push(b);
      });
      return fixNotes(d);
    }
    var paras = []; rows.forEach(function (r) { var t = r.filter(function (c) { return String(c).trim(); }).join(' ').trim(); if (t) paras.push({ text: t, runs: [], jc: '', ind: 0, sty: '', bold: false }); });
    return THK.docxToScript(paras, fname);
  }
  function fixNotes(d) { d.blocks.forEach(function (b) { if (b.t === 'action' || b.t === 'note') { var m = /^\[\[([\s\S]*)\]\]$/.exec((b.x || '').trim()); if (m) { b.t = 'note'; b.x = m[1].trim(); } } }); return d; }
  function langOf(d) { try { var s = d.blocks.map(function (b) { return b.x; }).join(' ').slice(0, 6000), l = THK.detectLang ? THK.detectLang(s) : ''; if (l && THK.lang && THK.lang(l) && THK.lang(l).id === l) { d.lang = l; d.font = THK.defaultFont(l); } else if (!d.lang) { d.lang = 'en'; d.font = 'CourierPrime'; } } catch (e) { } return d; }

  /* ---------------------------------------------------------------- XLSX */
  function colName(i) { var s = ''; i++; while (i > 0) { var m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; }
  F.toXlsx = function (d) {
    var rows = table(d), sd = rows.map(function (r, ri) {
      return '<row r="' + (ri + 1) + '">' + r.map(function (c, ci) {
        c = String(c); if (c === '') return '';
        if (ci === 0 && ri > 0 && /^\d+$/.test(c)) return '<c r="' + colName(ci) + (ri + 1) + '"><v>' + c + '</v></c>';
        return '<c r="' + colName(ci) + (ri + 1) + '" t="inlineStr"' + (ri === 0 ? ' s="1"' : ' s="2"') + '><is><t xml:space="preserve">' + xe(c) + '</t></is></c>';
      }).join('') + '</row>';
    }).join('');
    var H = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
    return F.zip({
      '[Content_Types].xml': H + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>',
      '_rels/.rels': H + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
      'xl/workbook.xml': H + '<workbook xmlns="' + NS + '" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Script" sheetId="1" r:id="rId1"/></sheets></workbook>',
      'xl/_rels/workbook.xml.rels': H + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
      'xl/styles.xml': H + '<styleSheet xmlns="' + NS + '"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs></styleSheet>',
      'xl/worksheets/sheet1.xml': H + '<worksheet xmlns="' + NS + '"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols><col min="1" max="1" width="8" customWidth="1"/><col min="2" max="2" width="16" customWidth="1"/><col min="3" max="3" width="20" customWidth="1"/><col min="4" max="4" width="90" customWidth="1"/></cols><sheetData>' + sd + '</sheetData></worksheet>'
    });
  };
  F.parseXlsx = function (buf, fname) {
    return F.unzip(buf).then(function (z) {
      if (!z['xl/workbook.xml']) throw new Error('This does not look like an Excel (.xlsx) file.');
      var sheetPath = 'xl/worksheets/sheet1.xml';
      try {
        var wb = xml(z['xl/workbook.xml']), sh = tags(wb, 'sheet')[0], rid = sh && (sh.getAttribute('r:id') || sh.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id'));
        if (rid && z['xl/_rels/workbook.xml.rels']) { tags(xml(z['xl/_rels/workbook.xml.rels']), 'Relationship').forEach(function (r) { if (r.getAttribute('Id') === rid) { var tg = r.getAttribute('Target').replace(/^\//, ''); sheetPath = /^xl\//.test(tg) ? tg : 'xl/' + tg; } }); }
      } catch (e) { }
      if (!z[sheetPath]) { var k = Object.keys(z).filter(function (n) { return /^xl\/worksheets\/sheet\d+\.xml$/.test(n); })[0]; if (!k) throw new Error('No sheet found in this Excel file.'); sheetPath = k; }
      var ss = []; if (z['xl/sharedStrings.xml']) tags(xml(z['xl/sharedStrings.xml']), 'si').forEach(function (si) { ss.push(tags(si, 't').map(function (t) { return t.textContent; }).join('')); });
      var rows = [];
      tags(xml(z[sheetPath]), 'row').forEach(function (r) {
        var out = [], max = -1;
        tags(r, 'c').forEach(function (c) {
          var ref = c.getAttribute('r') || '', m = /^([A-Z]+)/.exec(ref), ci = 0; if (m) for (var i = 0; i < m[1].length; i++) ci = ci * 26 + m[1].charCodeAt(i) - 64; ci = m ? ci - 1 : max + 1; max = ci;
          var t = c.getAttribute('t'), v = tags(c, 'v')[0], val = '';
          if (t === 's') val = ss[+(v && v.textContent)] || ''; else if (t === 'inlineStr') val = tags(c, 't').map(function (x) { return x.textContent; }).join(''); else if (v) val = v.textContent;
          out[ci] = val;
        });
        for (var j = 0; j < out.length; j++) if (out[j] == null) out[j] = ''; rows.push(out);
      });
      return fromTable(rows.filter(function (r) { return r.some(function (c) { return String(c).trim(); }); }), fname);
    });
  };

  /* ---------------------------------------------------------------- RTF */
  function rtfEsc(s) {
    var o = ''; for (var i = 0; i < s.length; i++) { var c = s.charCodeAt(i); if (c === 92) o += '\\\\'; else if (c === 123) o += '\\{'; else if (c === 125) o += '\\}'; else if (c === 10) o += '\\line '; else if (c === 9) o += '\\tab '; else if (c < 32) { } else if (c < 128) o += s[i]; else o += '\\u' + (c > 32767 ? c - 65536 : c) + '?'; }
    return o;
  }
  F.toRtf = function (d) {
    var m = meta(d), P = THK.paperOf(d), tw = function (mm) { return Math.round(parseFloat(mm) * 56.69); }, o = '{\\rtf1\\ansi\\ansicpg1252\\deff0\\uc1{\\fonttbl{\\f0\\fmodern\\fcharset0 Courier New;}{\\f1\\fnil\\fcharset1 Nirmala UI;}}\\paperw' + tw(P.w) + '\\paperh' + tw(P.h) + '\\margl1700\\margr1200\\margt1300\\margb1100\\deflang1033\\f0\\fs24\n';
    o += '{\\info{\\title ' + rtfEsc(m.title) + '}{\\author ' + rtfEsc(m.writer) + '}}\n';
    o += '\\pard\\qc\\sb3200\\b\\fs48 ' + rtfEsc(m.title) + '\\b0\\fs24\\par\n'; if (m.writer) o += '\\pard\\qc\\sb240 Written by ' + rtfEsc(m.writer) + '\\par\n'; if (m.director) o += '\\pard\\qc Director: ' + rtfEsc(m.director) + '\\par\n'; if (m.date) o += '\\pard\\qc ' + rtfEsc(m.date) + '\\par\n'; o += '\\page\n';
    function run(l, base) { return segs(l.x, l.fm).map(function (s) { var cw = (s.b || base === 'b' ? '\\b' : '') + (s.i ? '\\i' : '') + (s.u ? '\\ul' : ''); return '{' + cw + (cw ? ' ' : '') + rtfEsc(s.s) + '}'; }).join(''); }
    lines(d).forEach(function (l) {
      var pre = (l.pb ? '\\pagebb' : '');
      if (l.t === 'scene') o += '\\pard' + pre + '\\keepn\\sb360\\sa120\\li0 ' + (l.no ? '\\b ' + l.no + '\\tab\\b0 ' : '') + run(l, 'b') + '\\par\n';
      else if (l.t === 'char') o += '\\pard' + pre + '\\keepn\\sb200\\li3000 ' + run(l, 'b') + '\\par\n';
      else if (l.t === 'paren') o += '\\pard' + pre + '\\keepn\\li2300\\ri2300 (' + run({ x: l.x.replace(/^\(|\)$/g, ''), fm: null }) + ')\\par\n';
      else if (l.t === 'dial') o += '\\pard' + pre + '\\sa200\\li1440\\ri1440 ' + run(l) + '\\par\n';
      else if (l.t === 'trans') o += '\\pard' + pre + '\\qr\\sb200\\sa200 ' + run(l, 'b') + '\\par\n';
      else if (l.t === 'shot') o += '\\pard' + pre + '\\sb200\\sa200 ' + run(l, 'b') + '\\par\n';
      else if (l.t === 'note') o += '\\pard' + pre + '\\sa200 [[' + rtfEsc(l.x) + ']]\\par\n';
      else o += '\\pard' + pre + '\\sa200 ' + run(l) + '\\par\n';
    });
    return o + '}';
  };
  F.parseRtf = function (text, fname) {
    var i = 0, n = text.length, stack = [], st = { b: 0, i: 0, u: 0, skip: 0, uc: 1 }, paras = [], cur, out = '', runs = [], lastCut = 0;
    var jc = '', ind = 0, bytesBuf = [];
    var SKIP = /^(fonttbl|colortbl|stylesheet|info|pict|header|footer|footnote|listtable|listoverridetable|rsidtbl|generator|themedata|colorschememapping|latentstyles|datastore|fldinst|xmlnstbl|private|object|shppict|nonshppict|bkmkstart|bkmkend)$/;
    function newPara() { paras.push({ text: out, runs: runs, jc: jc, ind: ind, sty: '', bold: false }); out = ''; runs = []; cur = null; }
    function put(s) {
      if (st.skip) return; if (!s) return; var a = {}; if (st.b) a.b = 1; if (st.i) a.i = 1; if (st.u) a.u = 1;
      if (a.b || a.i || a.u) { var last = runs[runs.length - 1]; if (last && last.e === out.length && last.b === a.b && last.i === a.i && last.u === a.u) last.e += s.length; else runs.push(Object.assign({ s: out.length, e: out.length + s.length }, a)); }
      out += s;
    }
    function flushBytes() { if (bytesBuf.length) { put(new TextDecoder('windows-1252').decode(new Uint8Array(bytesBuf))); bytesBuf = []; } }
    while (i < n) {
      var c = text[i];
      if (c === '{') { flushBytes(); stack.push(Object.assign({}, st)); i++; if (text[i] === '\\' && text[i + 1] === '*') { st.skip = 1; } continue; }
      if (c === '}') { flushBytes(); st = stack.pop() || st; i++; continue; }
      if (c === '\\') {
        var nx = text[i + 1];
        if (nx === '\\' || nx === '{' || nx === '}') { flushBytes(); put(nx); i += 2; continue; }
        if (nx === "'") { var hex = text.substr(i + 2, 2); bytesBuf.push(parseInt(hex, 16) || 63); i += 4; continue; }
        if (nx === '~') { flushBytes(); put(' '); i += 2; continue; } if (nx === '-' || nx === '_') { flushBytes(); put(nx === '_' ? '-' : ''); i += 2; continue; } if (nx === '\n' || nx === '\r') { flushBytes(); newPara(); i += 2; continue; }
        var m = /^\\([a-zA-Z]+)(-?\d+)? ?/.exec(text.slice(i, i + 40)); if (!m) { i++; continue; }
        flushBytes(); var w = m[1], v = m[2] == null ? null : +m[2]; i += m[0].length;
        if (SKIP.test(w)) { st.skip = 1; continue; }
        if (w === 'par' || w === 'sect') newPara(); else if (w === 'line') put('\n'); else if (w === 'tab') put('  ');
        else if (w === 'page' || w === 'pagebb') { } else if (w === 'pard') { jc = ''; ind = 0; }
        else if (w === 'qc') jc = 'center'; else if (w === 'qr') jc = 'right'; else if (w === 'qj') jc = 'both'; else if (w === 'ql') jc = '';
        else if (w === 'li' || w === 'fi' && false) ind = v || 0; else if (w === 'b') st.b = v === 0 ? 0 : 1; else if (w === 'i') st.i = v === 0 ? 0 : 1; else if (w === 'ul') st.u = v === 0 ? 0 : 1; else if (w === 'ulnone') st.u = 0;
        else if (w === 'uc') st.uc = v == null ? 1 : v;
        else if (w === 'u') { var cp = v < 0 ? v + 65536 : v; put(String.fromCharCode(cp)); var skipN = st.uc; while (skipN > 0 && i < n) { if (text[i] === '\\' && text[i + 1] === "'") { i += 4; } else i++; skipN--; } }
        else if (w === 'emdash') put('—'); else if (w === 'endash') put('–'); else if (w === 'lquote') put('‘'); else if (w === 'rquote') put('’'); else if (w === 'ldblquote') put('“'); else if (w === 'rdblquote') put('”'); else if (w === 'bullet') put('•');
        continue;
      }
      if (c === '\r' || c === '\n') { i++; continue; }
      flushBytes(); var j = i; while (j < n && text[j] !== '\\' && text[j] !== '{' && text[j] !== '}' && text[j] !== '\r' && text[j] !== '\n') j++; put(text.slice(i, j)); i = j;
    }
    flushBytes(); if (out) newPara();
    paras = paras.map(function (p) { p.text = p.text.replace(/\u00a0/g, ' ').replace(/[ \t]+$/g, ''); return p; });
    return fromParas(paras, fname);
  };

  /* explicit paragraph types (our own files) go straight in; foreign files use the same guessing as Word import */
  var STY = [[/^(scene ?heading|sceneheading|slug ?line|slugline|scene)$/, 'scene'], [/^(character|char|speaker)$/, 'char'], [/^(parenthetical|paren|parentheses)$/, 'paren'], [/^(dialogue|dialog|speech)$/, 'dial'], [/^(transition)$/, 'trans'], [/^(shot)$/, 'shot'], [/^(action|general|description)$/, 'action'], [/^(note|notes)$/, 'note']];
  function styT(s) { s = String(s || '').toLowerCase().replace(/[_\-]20/g, ' ').replace(/[^a-z ]/g, ' ').replace(/\s+/g, ' ').trim(); for (var i = 0; i < STY.length; i++) if (STY[i][0].test(s)) return STY[i][1]; return ''; }
  function fromParas(paras, fname) {
    var tagged = paras.filter(function (p) { return p.t; }).length, kinds = {}; paras.forEach(function (p) { if (p.t) kinds[p.t] = 1; });
    if (tagged >= 3 && Object.keys(kinds).length >= 2) {
      var d = THK.newImportDoc(fname.replace(/\.[^.]+$/, ''));
      paras.forEach(function (p) {
        var t = p.t || 'action', x = p.text.replace(/\u00a0/g, ' ').replace(/[ \t]+$/g, '').replace(/^\s+/, ''); if (!x.trim()) return;
        if (t === 'paren') x = x.replace(/^\(\s*|\s*\)$/g, ''); if (t === 'char') x = x.replace(/[:：]\s*$/, '');
        var lead = p.text.match(/^\s*/)[0].length;
        if (t === 'scene') x = x.replace(/^\d+[A-Za-z]?(\s*[.)]\s*|\s{2,}|\t)(?=\S)/, '');
        var b = { id: uid(), t: t, x: x }; if (t === 'scene') b.x2 = '';
        var rr = (p.runs || []).map(function (r) { return Object.assign({}, r, { s: Math.max(0, r.s - lead), e: Math.max(0, r.e - lead) }); }).filter(function (r) { return r.e > r.s && r.s < x.length && t !== 'paren'; }); if (rr.length) b.fm = { x: rr };
        d.blocks.push(b);
      });
      if (!d.blocks.length) throw new Error('No text found.'); return langOf(fixNotes(d));
    }
    paras.forEach(function (p) { if (/^\s*(\d+[A-Za-z]?\s*[.)]?\s*)(INT|EXT|I\/E|EST)\b/i.test(p.text)) p.text = p.text.replace(/^\s*\d+[A-Za-z]?\s*[.)]?\s+/, '').replace(/\s{2,}\d+[A-Za-z]?\s*$/, ''); });
    return langOf(fixNotes(THK.docxToScript(paras, fname)));
  }

  /* ---------------------------------------------------------------- HTML */
  var CLS = { scene: 'sceneheading', action: 'action', char: 'character', paren: 'parenthetical', dial: 'dialogue', trans: 'transition', shot: 'shot', note: 'note' };
  function inlineHtml(l) { return segs(l.x, l.fm).map(function (s) { var h = xe(s.s).replace(/\n/g, '<br>'); if (s.u) h = '<u>' + h + '</u>'; if (s.i) h = '<i>' + h + '</i>'; if (s.b) h = '<b>' + h + '</b>'; return h; }).join(''); }
  F.toHtml = function (d) {
    var m = meta(d), rtl = THK.lang && THK.lang(d.lang) && THK.lang(d.lang).rtl, stack = (THK.font(d.font) || {}).stack || "'Courier New',monospace";
    var body = '<header class="title"><h1>' + xe(m.title) + '</h1>' + (m.writer ? '<p>Written by ' + xe(m.writer) + '</p>' : '') + (m.director ? '<p>Director: ' + xe(m.director) + '</p>' : '') + (m.date ? '<p>' + xe(m.date) + '</p>' : '') + '</header>';
    lines(d).forEach(function (l) {
      var cls = CLS[l.t] || 'action', h = inlineHtml(l); if (l.pb) body += '<div class="pb"></div>';
      if (l.t === 'paren') h = '(' + inlineHtml({ x: l.x.replace(/^\(|\)$/g, ''), fm: null }) + ')';
      if (l.t === 'note') h = '[[' + xe(l.x) + ']]';
      body += '<p class="' + cls + '"' + (l.t === 'scene' && l.no ? ' data-scene="' + xe(l.no) + '"' : '') + '>' + h + '</p>\n';
    });
    return '<!DOCTYPE html>\n<html lang="' + xe(d.lang || 'en') + '"' + (rtl ? ' dir="rtl"' : '') + '><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="generator" content="finnish"><title>' + xe(m.title) + '</title>' +
      '<style>body{margin:0;background:#e9e9ee;color:#111}main{max-width:6.5in;margin:24px auto;background:#fff;padding:1in 1in 1in 1.4in;box-shadow:0 4px 24px rgba(0,0,0,.18);font:12pt/1.25 ' + stack + ';box-sizing:border-box}' +
      '.title{text-align:center;margin:2in 0 1.4in}.title h1{font-size:26pt;margin:0 0 .5em}.title p{margin:.3em 0}p{margin:0 0 1em;white-space:pre-wrap}.sceneheading{font-weight:bold;text-transform:uppercase;margin-top:1.6em}.sceneheading[data-scene]::before{content:attr(data-scene) "  "}' +
      '.character{margin:1em 0 0 2.2in;font-weight:bold;text-transform:uppercase}.parenthetical{margin:0 1.5in 0 1.6in}.dialogue{margin:0 1in 1em 1in}.transition{text-align:right;font-weight:bold;text-transform:uppercase}.shot{font-weight:bold;text-transform:uppercase}.note{color:#777;font-style:italic}.pb{break-after:page;border-top:1px dashed #bbb;margin:1em 0}' +
      '@media print{body{background:#fff}main{box-shadow:none;margin:0;max-width:none}}</style></head><body><main>' + body + '</main></body></html>';
  };
  function cssLen(v, tw) { // css length -> twips
    var m = /(-?[\d.]+)\s*(px|pt|in|cm|mm|em|rem|%)?/.exec(v || ''); if (!m) return 0; var n = parseFloat(m[1]); switch (m[2]) { case 'in': return n * 1440; case 'cm': return n * 567; case 'mm': return n * 56.7; case 'pt': return n * 20; case 'em': case 'rem': return n * 240; case '%': return (tw || 9000) * n / 100; default: return n * 15; }
  }
  F.parseHtml = function (html, fname) {
    var doc = new DOMParser().parseFromString(html, 'text/html'); Array.prototype.forEach.call(doc.querySelectorAll('script,style,head,noscript,svg,img,video,audio'), function (n) { n.remove(); });
    var BLOCK = /^(p|div|h[1-6]|li|pre|blockquote|tr|section|article|header|footer|main|ul|ol|table|tbody|aside|dd|dt)$/i, paras = [], title = (doc.title || '').trim();
    function hasBlock(n) { return Array.prototype.some.call(n.children, function (c) { return BLOCK.test(c.tagName) && !(c.tagName === 'DIV' && c.classList.contains('pb')); }); }
    function walk(n) {
      if (n.nodeType !== 1) return; if (n.matches && n.matches('header.title')) return; if (BLOCK.test(n.tagName) && !hasBlock(n)) { leaf(n); return; }
      Array.prototype.forEach.call(n.childNodes, function (c) { if (c.nodeType === 3 && c.textContent.trim() && !BLOCK.test(n.tagName)) leaf(c); else walk(c); });
    }
    function leaf(n) {
      var text = '', runs = [];
      function inl(x, a) {
        if (x.nodeType === 3) { var s = x.textContent.replace(/\s*\n\s*/g, ' '); if (!s) return; if (a.b || a.i || a.u) runs.push(Object.assign({ s: text.length, e: text.length + s.length }, a)); text += s; return; }
        if (x.nodeType !== 1) return; var tg = x.tagName.toLowerCase(); if (tg === 'br') { text += '\n'; return; }
        var b = Object.assign({}, a), st = (x.getAttribute('style') || '').toLowerCase(); if (/^(b|strong)$/.test(tg) || /font-weight:\s*(bold|[6-9]00)/.test(st)) b.b = 1; if (/^(i|em|cite)$/.test(tg) || /font-style:\s*italic/.test(st)) b.i = 1; if (tg === 'u' || /text-decoration[^;]*underline/.test(st)) b.u = 1;
        Array.prototype.forEach.call(x.childNodes, function (c) { inl(c, b); });
      }
      if (n.nodeType === 3) inl(n, {}); else inl(n, {}); text = text.replace(/\u00a0/g, ' ').replace(/[ \t]+/g, ' ').replace(/ ?\n ?/g, '\n').trim(); if (!text) return;
      var lead = 0; var el = n.nodeType === 1 ? n : n.parentNode, st2 = (el.getAttribute('style') || '').toLowerCase(), al = (/text-align:\s*(\w+)/.exec(st2) || [])[1] || el.getAttribute('align') || '', ml = /margin-left:\s*([^;]+)/.exec(st2) || /padding-left:\s*([^;]+)/.exec(st2);
      var cls = (el.className || '').toString().split(/\s+/).map(styT).filter(Boolean)[0] || styT(el.getAttribute('data-type') || el.getAttribute('data-element')) || '';
      if (/^h[1-6]$/i.test(el.tagName) && !cls) cls = '';
      var jc = /center/.test(al) ? 'center' : /right/.test(al) ? 'right' : /justify/.test(al) ? 'both' : '';
      paras.push({ text: text, runs: runs.filter(function (r) { return r.e > r.s; }), jc: jc, ind: ml ? cssLen(ml[1]) : 0, sty: /^h[1-3]$/i.test(el.tagName) ? 'heading' : '', bold: false, t: cls });
      if (cls === 'scene' && el.getAttribute('data-scene') && false) lead = 0;
    }
    walk(doc.body);
    if (!paras.length) throw new Error('No readable text in this web page.');
    var tagged = paras.filter(function (p) { return p.t; }).length; if (tagged >= 3 && paras[0].text === title && !paras[0].t) paras.shift();
    var d = fromParas(paras, fname); if (title && (!d.title || d.title === fname.replace(/\.[^.]+$/, ''))) d.title = title;
    var h1 = doc.querySelector('header.title h1'); if (h1) { d.title = h1.textContent.trim(); Array.prototype.forEach.call(doc.querySelectorAll('header.title p'), function (q) { var t = q.textContent.trim(), m; if ((m = /^Written by\s+(.*)$/.exec(t))) d.writer = m[1]; else if ((m = /^Director:\s*(.*)$/.exec(t))) d.director = m[1]; else if (t) d.date = t; }); } return d;
  };

  /* ---------------------------------------------------------------- Markdown */
  function mdInline(l) { return segs(l.x, l.fm).map(function (s) { var t = s.s.replace(/\*/g, '\\*'); if (s.u) t = '<u>' + t + '</u>'; if (s.b && s.i) t = '***' + t + '***'; else if (s.b) t = '**' + t + '**'; else if (s.i) t = '*' + t + '*'; return t; }).join(''); }
  F.toMd = function (d) {
    var m = meta(d), o = ['# ' + m.title, ''];
    var by = [m.writer && 'Written by ' + m.writer, m.director && 'Director: ' + m.director, m.date].filter(Boolean); if (by.length) o.push('*' + by.join(' · ') + '*', '');
    lines(d).forEach(function (l) {
      if (l.pb) o.push('---', '');
      if (l.t === 'scene') o.push('## ' + (l.no ? l.no + '. ' : '') + l.x.toUpperCase(), '');
      else if (l.t === 'char') o.push('**' + l.x.trim().toUpperCase() + '**');
      else if (l.t === 'paren') o.push('*(' + l.x.replace(/^\(|\)$/g, '') + ')*');
      else if (l.t === 'dial') o.push('> ' + mdInline(l).replace(/\n/g, '  \n> '), '');
      else if (l.t === 'trans') o.push('→ ' + l.x.toUpperCase(), '');
      else if (l.t === 'shot') o.push('`' + l.x.toUpperCase() + '`', '');
      else if (l.t === 'note') o.push('<!-- ' + l.x.replace(/-->/g, '- ->') + ' -->', '');
      else o.push(mdInline(l), '');
    });
    return o.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
  };
  function mdRuns(s) { // *italic* **bold** ***both*** <u>x</u> \*
    var out = '', runs = [], i = 0;
    while (i < s.length) {
      var m = /^(\*\*\*|\*\*|\*|_)(?=\S)([\s\S]*?\S)\1/.exec(s.slice(i)), u = /^<u>([\s\S]*?)<\/u>/.exec(s.slice(i));
      if (s[i] === '\\' && /[*_`\\>#]/.test(s[i + 1] || '')) { out += s[i + 1]; i += 2; }
      else if (u) { var a = out.length; out += u[1]; runs.push({ s: a, e: out.length, u: 1 }); i += u[0].length; }
      else if (m && (m[1] !== '_' || /\W|^$/.test(s[i - 1] || ''))) { var a2 = out.length, inner = mdRuns(m[2]); out += inner.text; var r = { s: a2, e: out.length }; if (m[1] === '***') { r.b = 1; r.i = 1; } else if (m[1] === '**') r.b = 1; else r.i = 1; runs.push(r); inner.runs.forEach(function (q) { runs.push({ s: q.s + a2, e: q.e + a2, b: q.b, i: q.i, u: q.u }); }); i += m[0].length; }
      else { out += s[i]; i++; }
    }
    return { text: out, runs: runs };
  }
  F.parseMd = function (text, fname) {
    var L = text.replace(/\r/g, '').split('\n'), paras = [], acc = [], title = '', byline = '', i = 0, FM = /^---\s*$/;
    if (FM.test(L[0] || '')) { var e = L.findIndex(function (x, k) { return k > 0 && FM.test(x); }); if (e > 0) { L.slice(1, e).forEach(function (x) { var m = /^title:\s*(.+)$/i.exec(x); if (m) title = m[1].replace(/^["']|["']$/g, ''); }); i = e + 1; } }
    function push(t, raw) { var r = mdRuns(raw.trim()); if (r.text.trim()) paras.push({ text: r.text, runs: r.runs, jc: '', ind: 0, sty: '', bold: false, t: t }); }
    function flush() { if (acc.length) { push('', acc.join('\n')); acc = []; } }
    var dial = [];
    function flushD() { if (dial.length) { push('dial', dial.join('\n')); dial = []; } }
    for (; i < L.length; i++) {
      var l = L[i], t = l.trim(), m;
      if (!t) { flush(); flushD(); continue; }
      if ((m = /^#{1}\s+(.*)$/.exec(t)) && !title && !paras.length) { title = m[1]; continue; }
      if (title && !paras.length && !byline && (m = /^\*(Written by[^*]*|Director:[^*]*)\*$/.exec(t))) { byline = m[1]; continue; }
      if ((m = /^#{1,6}\s+(.*)$/.exec(t))) { flush(); flushD(); push('scene', m[1].replace(/\s*#+\s*$/, '').replace(/^\d+[A-Za-z]?\s*[.)]\s+/, '')); continue; }
      if (/^(\*{3,}|-{3,}|_{3,})$/.test(t)) { flush(); flushD(); if (paras.length) paras.push({ text: '', runs: [], pb: true, t: 'pb', jc: '', ind: 0, sty: '', bold: false }); continue; }
      if ((m = /^>\s?(.*)$/.exec(t))) { flush(); dial.push(m[1].replace(/\s{2,}$/, '')); continue; }
      flushD();
      if ((m = /^\*\*([^*]+)\*\*$/.exec(t)) || (m = /^__([^_]+)__$/.exec(t))) { flush(); push('char', m[1]); continue; }
      if ((m = /^[*_]\((.*)\)[*_]$/.exec(t)) || (m = /^\((.*)\)$/.exec(t)) && paras.length && /char|paren|dial/.test(paras[paras.length - 1].t)) { flush(); push('paren', m[1]); continue; }
      if ((m = /^(?:→|->|=>)\s*(.+)$/.exec(t))) { flush(); push('trans', m[1]); continue; }
      if ((m = /^`([^`]+)`$/.exec(t))) { flush(); push('shot', m[1]); continue; }
      if ((m = /^<!--\s*([\s\S]*?)\s*-->$/.exec(t))) { flush(); push('note', m[1]); continue; }
      if (/^!\[.*\]\(.*\)$/.test(t)) continue;
      acc.push(t.replace(/^[-*+]\s+(?=\S)/, '').replace(/\s{2,}$/, ''));
    }
    flush(); flushD();
    var pbAt = {}; var clean = []; paras.forEach(function (p) { if (p.t === 'pb') { pbAt[clean.length] = 1; } else clean.push(p); });
    var d = fromParas(clean, fname); if (title) d.title = title.replace(/\*+/g, '').trim();
    if (byline) byline.split(/\s*·\s*/).forEach(function (q) { var m; if ((m = /^Written by\s+(.*)$/.exec(q))) d.writer = m[1]; else if ((m = /^Director:\s*(.*)$/.exec(q))) d.director = m[1]; else if (q) d.date = q; });
    var bl = d.blocks; Object.keys(pbAt).forEach(function (k) { /* page breaks are only kept when the blocks line up 1:1 */ if (bl.length === clean.length && bl[+k]) bl[+k].pb = true; });
    return d;
  };

  /* ---------------------------------------------------------------- ODT */
  F.toOdt = function (d) {
    var m = meta(d), NSX = 'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0"';
    var H = '<?xml version="1.0" encoding="UTF-8"?>', P = THK.paperOf(d), mmOf = function (v) { return parseFloat(v); };
    function ps(name, disp, props, txt) { return '<style:style style:name="' + name + '" style:display-name="' + disp + '" style:family="paragraph"><style:paragraph-properties ' + props + '/><style:text-properties ' + (txt || '') + '/></style:style>'; }
    var styles = H + '<office:document-styles ' + NSX + ' office:version="1.2"><office:font-face-decls><style:font-face style:name="Courier New" svg:font-family="\'Courier New\'" style:font-family-generic="modern"/></office:font-face-decls><office:styles>' +
      '<style:default-style style:family="paragraph"><style:text-properties style:font-name="Courier New" fo:font-size="12pt"/></style:default-style>' +
      '<style:style style:name="Standard" style:family="paragraph" style:class="text"><style:text-properties style:font-name="Courier New" fo:font-size="12pt"/></style:style>' +
      ps('sceneheading', 'sceneheading', 'fo:margin-top="0.17in" fo:margin-bottom="0.08in" fo:keep-with-next="always"', 'fo:font-weight="bold"') + ps('action', 'action', 'fo:margin-bottom="0.14in"') + ps('character', 'character', 'fo:margin-top="0.1in" fo:margin-left="2.2in" fo:keep-with-next="always"', 'fo:font-weight="bold"') +
      ps('parenthetical', 'parenthetical', 'fo:margin-left="1.6in" fo:margin-right="1.5in" fo:keep-with-next="always"') + ps('dialogue', 'dialogue', 'fo:margin-left="1in" fo:margin-right="1in" fo:margin-bottom="0.14in"') + ps('transition', 'transition', 'fo:text-align="end" fo:margin-bottom="0.14in"', 'fo:font-weight="bold"') +
      ps('shot', 'shot', 'fo:margin-bottom="0.14in"', 'fo:font-weight="bold"') + ps('note', 'note', 'fo:margin-bottom="0.14in"', 'fo:font-style="italic"') + ps('titlepage', 'titlepage', 'fo:text-align="center"') +
      '</office:styles><office:automatic-styles><style:page-layout style:name="pm1"><style:page-layout-properties fo:page-width="' + mmOf(P.w) + 'mm" fo:page-height="' + mmOf(P.h) + 'mm" fo:margin-top="22mm" fo:margin-bottom="20mm" fo:margin-left="32mm" fo:margin-right="20mm"/></style:page-layout></office:automatic-styles><office:master-styles><style:master-page style:name="Standard" style:page-layout-name="pm1"/></office:master-styles></office:document-styles>';
    var auto = '<style:style style:name="PB" style:family="paragraph"><style:paragraph-properties fo:break-before="page"/></style:style>', cmb = {};
    function spanStyle(s) { var k = (s.b ? 'b' : '') + (s.i ? 'i' : '') + (s.u ? 'u' : ''); if (!k) return ''; if (!cmb[k]) { cmb[k] = 1; auto += '<style:style style:name="T' + k + '" style:family="text"><style:text-properties' + (s.b ? ' fo:font-weight="bold"' : '') + (s.i ? ' fo:font-style="italic"' : '') + (s.u ? ' style:text-underline-style="solid" style:text-underline-width="auto" style:text-underline-color="font-color"' : '') + '/></style:style>'; } return 'T' + k; }
    function inl(x, fm) { return segs(x, fm).map(function (s) { var t = xe(s.s).replace(/\n/g, '<text:line-break/>').replace(/  +/g, function (q) { return ' <text:s text:c="' + (q.length - 1) + '"/>'; }), sn = spanStyle(s); return sn ? '<text:span text:style-name="' + sn + '">' + t + '</text:span>' : t; }).join(''); }
    var body = '<text:p text:style-name="titlepage">' + xe(m.title) + '</text:p>' + (m.writer ? '<text:p text:style-name="titlepage">Written by ' + xe(m.writer) + '</text:p>' : '') + (m.director ? '<text:p text:style-name="titlepage">Director: ' + xe(m.director) + '</text:p>' : '') + (m.date ? '<text:p text:style-name="titlepage">' + xe(m.date) + '</text:p>' : '');
    var first = true; lines(d).forEach(function (l) {
      var cls = CLS[l.t] || 'action', h = inl(l.x, l.fm); if (l.t === 'paren') h = '(' + inl(l.x.replace(/^\(|\)$/g, ''), null) + ')'; if (l.t === 'note') h = '[[' + xe(l.x) + ']]';
      if (l.t === 'scene' && l.no) h = '<text:span text:style-name="Tb">' + xe(l.no) + '</text:span><text:tab/>' + h; if (l.t === 'scene' && l.no && !cmb.b) { cmb.b = 1; auto += '<style:style style:name="Tb" style:family="text"><style:text-properties fo:font-weight="bold"/></style:style>'; }
      body += '<text:p text:style-name="' + (l.pb || first ? 'PB' + cls : cls) + '">' + h + '</text:p>'; if (l.pb || first) { var nm = 'PB' + cls; if (!cmb[nm]) { cmb[nm] = 1; auto += '<style:style style:name="' + nm + '" style:family="paragraph" style:parent-style-name="' + cls + '"><style:paragraph-properties fo:break-before="page"/></style:style>'; } } first = false;
    });
    var content = H + '<office:document-content ' + NSX + ' office:version="1.2"><office:automatic-styles>' + auto + '</office:automatic-styles><office:body><office:text>' + body + '</office:text></office:body></office:document-content>';
    return F.zip({
      'mimetype': 'application/vnd.oasis.opendocument.text', 'content.xml': content, 'styles.xml': styles,
      'meta.xml': H + '<office:document-meta ' + NSX + ' office:version="1.2"><office:meta><dc:title>' + xe(m.title) + '</dc:title><meta:initial-creator>' + xe(m.writer) + '</meta:initial-creator><meta:generator>finnish</meta:generator></office:meta></office:document-meta>',
      'META-INF/manifest.xml': H + '<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2"><manifest:file-entry manifest:full-path="/" manifest:media-type="application/vnd.oasis.opendocument.text"/><manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/><manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/><manifest:file-entry manifest:full-path="meta.xml" manifest:media-type="text/xml"/></manifest:manifest>'
    }, ['mimetype']);
  };
  F.parseOdt = function (buf, fname) {
    return F.unzip(buf).then(function (z) {
      if (!z['content.xml']) throw new Error('This does not look like an OpenDocument (.odt) file.');
      var sty = {};
      function readStyles(u8) {
        if (!u8) return; tags(xml(u8), 'style').forEach(function (s) {
          var name = s.getAttributeNS('*', 'name') || s.getAttribute('style:name'), o = { parent: s.getAttribute('style:parent-style-name') || '', disp: s.getAttribute('style:display-name') || '' };
          tags(s, 'paragraph-properties').forEach(function (p) { o.al = p.getAttribute('fo:text-align') || o.al; var ml = p.getAttribute('fo:margin-left') || p.getAttribute('fo:margin-start'); if (ml) o.ml = ml; });
          tags(s, 'text-properties').forEach(function (p) { if (/bold|[6-9]00/.test(p.getAttribute('fo:font-weight') || '')) o.b = 1; if ((p.getAttribute('fo:font-style') || '') === 'italic') o.i = 1; var u = p.getAttribute('style:text-underline-style'); if (u && u !== 'none') o.u = 1; });
          if (name) sty[name] = o;
        });
      }
      readStyles(z['styles.xml']); readStyles(z['content.xml']);
      function chain(n, k) { var seen = 0, s = sty[n]; while (s && seen++ < 8) { if (s[k] != null) return s[k]; s = sty[s.parent]; } return null; }
      function nameOf(n) { var out = []; var s = sty[n], k = 0; while (s && k++ < 8) { out.push(s.disp || ''); s = sty[s.parent]; } return [n].concat(out); }
      var paras = [], tp = [], doc = xml(z['content.xml']), body = tags(doc, 'text')[0] || doc.documentElement;
      function para(p) {
        var text = '', runs = [];
        function inl(x, a) {
          if (x.nodeType === 3) { var s = x.textContent; if (!s) return; if (a.b || a.i || a.u) runs.push(Object.assign({ s: text.length, e: text.length + s.length }, a)); text += s; return; }
          if (x.nodeType !== 1) return; var ln = x.localName; if (ln === 'line-break') { text += '\n'; return; } if (ln === 'tab') { text += '  '; return; } if (ln === 's') { var c = +(x.getAttribute('text:c') || 1); text += new Array(c + 1).join(' '); return; }
          var b = Object.assign({}, a); if (ln === 'span') { var sn = x.getAttribute('text:style-name'); if (chain(sn, 'b')) b.b = 1; if (chain(sn, 'i')) b.i = 1; if (chain(sn, 'u')) b.u = 1; }
          if (ln === 'note' || ln === 'annotation') return; Array.prototype.forEach.call(x.childNodes, function (c) { inl(c, b); });
        }
        Array.prototype.forEach.call(p.childNodes, function (c) { inl(c, {}); });
        var sn = p.getAttribute('text:style-name') || '', names = nameOf(sn), t = '';
        for (var i = 0; i < names.length && !t; i++) t = styT(names[i]);
        var al = chain(sn, 'al') || '', ml = chain(sn, 'ml'); var jc = /center/.test(al) ? 'center' : /^(end|right)/.test(al) ? 'right' : /justify/.test(al) ? 'both' : '';
        text = text.replace(/\u00a0/g, ' ').replace(/[ \t]+$/g, ''); if (!text.trim()) return;
        if (names.some(function (q) { return /^titlepage$/i.test(q); })) { tp.push(text.trim()); return; }
        paras.push({ text: text, runs: runs, jc: jc, ind: ml ? cssLen(ml.replace('in', 'in')) : 0, sty: p.localName === 'h' ? 'heading' : names.join(' ').toLowerCase(), bold: !!chain(sn, 'b'), t: t });
      }
      function walk(n) { Array.prototype.forEach.call(n.childNodes, function (c) { if (c.nodeType !== 1) return; if (c.localName === 'p' || c.localName === 'h') para(c); else walk(c); }); }
      walk(body);
      if (!paras.length) throw new Error('No text found in this OpenDocument file.');
      var d = fromParas(paras, fname); tp.forEach(function (q, k) { var m; if (k === 0) d.title = q; else if ((m = /^Written by\s+(.*)$/.exec(q))) d.writer = m[1]; else if ((m = /^Director:\s*(.*)$/.exec(q))) d.director = m[1]; else d.date = q; }); try { var mt = z['meta.xml'] && tags(xml(z['meta.xml']), 'title')[0]; if (mt && mt.textContent.trim() && !/^(untitled)?$/i.test(mt.textContent.trim())) d.title = mt.textContent.trim(); } catch (e) { } return d;
    });
  };

  /* ---------------------------------------------------------------- containers: .celtx, .screenplay, .cxscript, .sbx, project .zip */
  function sceneNoteFile(kind) { return 'This ' + kind + ' file was written by finnish. The full script is stored as FDX, Fountain and finnish JSON inside, so any of them can be pulled out with a zip tool.'; }
  F.toCeltx = function (d) {
    var m = meta(d), H = '<?xml version="1.0" encoding="UTF-8"?>', html = F.toHtml(d).replace(/<style>[\s\S]*?<\/style>/, '');
    var rdf = H + '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:cx="http://celtx.com/NS/v1/"><rdf:Description rdf:about="#project"><rdf:type rdf:resource="http://celtx.com/NS/v1/Project"/><dc:title>' + xe(m.title) + '</dc:title><cx:doctype>script</cx:doctype><cx:document rdf:resource="#script1"/></rdf:Description><rdf:Description rdf:about="#script1"><rdf:type rdf:resource="http://celtx.com/NS/v1/Script"/><dc:title>' + xe(m.title) + '</dc:title><cx:localFile>script1.html</cx:localFile></rdf:Description></rdf:RDF>';
    return F.zip({ 'project.rdf': rdf, 'script1.html': html, 'script.fdx': THK.toFDX(d), 'script.fountain': THK.toFountain(d, true), 'README.txt': sceneNoteFile('.celtx') });
  };
  F.toScriptty = function (d) {
    var T = { scene: 'scene_heading', action: 'action', char: 'character', paren: 'parenthetical', dial: 'dialogue', trans: 'transition', shot: 'shot', note: 'action' }, m = meta(d);
    return JSON.stringify({ meta: { title: m.title, author: m.writer }, doc: { type: 'doc', content: lines(d).map(function (l) { return { type: T[l.t] || 'action', content: [{ type: 'text', text: l.t === 'paren' ? '(' + l.x.replace(/^\(|\)$/g, '') + ')' : l.x }] }; }) } }, null, 1);
  };
  F.toContainer = function (d, ext) { // .cxscript / .sbx – the originals are private formats, so these are open containers the apps' own importers may or may not accept
    var A = THK.app; return F.zip({ 'script.fdx': THK.toFDX(d), 'script.fountain': THK.toFountain(d, true), 'script.finnish': A.wrapFile(), 'README.txt': sceneNoteFile('.' + ext) });
  };
  function dataUri(u) { var m = /^data:([^;,]+)?(;base64)?,([\s\S]*)$/.exec(u || ''); if (!m) return null; var bin; try { bin = m[2] ? atob(m[3]) : decodeURIComponent(m[3]); } catch (e) { return null; } var b = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i) & 255; return { mime: m[1] || 'application/octet-stream', bytes: b }; }
  function extOf(mime) { return ({ 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif', 'image/svg+xml': 'svg' })[mime] || 'bin'; }
  F.toProject = function (d) { // everything: backup + every document format + all pictures
    var A = THK.app, files = {}, name = A.fname(), assets = [], info = [];
    files['project/' + name + '.finnish'] = A.wrapFile(); files['documents/' + name + '.fountain'] = THK.toFountain(d, true); files['documents/' + name + '.fdx'] = THK.toFDX(d);
    files['documents/' + name + '.txt'] = F.toTxt(d); files['documents/' + name + '.md'] = F.toMd(d); files['documents/' + name + '.html'] = F.toHtml(d); files['documents/' + name + '.csv'] = F.toCsv(d); files['documents/' + name + '.rtf'] = F.toRtf(d); files['documents/' + name + '.screenplay'] = F.toScriptty(d);
    try { files['documents/' + name + '.docx'] = THK.x.docx(d, { cover: true }); } catch (e) { info.push('Word file could not be added: ' + e.message); }
    Object.keys(d.imgs || {}).forEach(function (k) { var u = dataUri(d.imgs[k]); if (u) { files['assets/pictures/' + k + '.' + extOf(u.mime)] = u.bytes; assets.push('pictures/' + k); } });
    if (d.sb && d.sb.panels) d.sb.panels.forEach(function (p, i) { ['bg', 'ink'].forEach(function (f) { var u = p[f] && typeof p[f] === 'string' && dataUri(p[f]); if (u) { files['assets/storyboard/panel-' + (i + 1) + '-' + (f === 'bg' ? 'picture' : 'drawing') + '.' + extOf(u.mime)] = u.bytes; assets.push('storyboard/panel-' + (i + 1)); } }); });
    var seq = Promise.resolve(); // the other document formats are built asynchronously
    seq = seq.then(function () { return F.toXlsx(d); }).then(function (x) { files['documents/' + name + '.xlsx'] = x; return F.toOdt(d); }).then(function (o) { files['documents/' + name + '.odt'] = o; return F.toCeltx(d); }).then(function (c) { files['documents/' + name + '.celtx'] = c; });
    return seq.then(function () {
      files['README.txt'] = 'finnish project: ' + name + '\r\n\r\nproject/    – the finnish backup (open it in finnish to restore everything: script, covers, pictures, storyboard, history)\r\ndocuments/  – the script in every export format\r\nassets/     – every picture and storyboard drawing as a normal image file (' + assets.length + ' file(s))\r\n' + (info.length ? '\r\nNote: ' + info.join('; ') + '\r\n' : '') + '\r\nA PDF is not included here – use Export ▸ PDF in the app for that.\r\n';
      return F.zip(files);
    });
  };

  /* ---------------------------------------------------------------- the one entry point for the Export window */
  F.LIST = [ // [id, label, description, ext, mime]
    ['txt', 'Plain text (.txt)', 'The script laid out like a typed page: scene headings, centred names, indented dialogue.', 'txt', 'text/plain'],
    ['rtf', 'Rich Text (.rtf)', 'Opens in Word, WordPad, Pages and LibreOffice with bold, italic and underline kept.', 'rtf', 'application/rtf'],
    ['odt', 'OpenDocument (.odt)', 'Opens in LibreOffice, OpenOffice and Google Docs. Scene styles are named.', 'odt', 'application/vnd.oasis.opendocument.text'],
    ['html', 'Web page (.html)', 'One self-contained page that opens in any browser and prints cleanly.', 'html', 'text/html'],
    ['md', 'Markdown (.md)', 'Readable plain text with headings for scenes. Reads back into finnish exactly.', 'md', 'text/markdown'],
    ['csv', 'Spreadsheet table (.csv)', 'One row per line: scene number, element, character and text. Works with Excel and Sheets.', 'csv', 'text/csv'],
    ['xlsx', 'Excel workbook (.xlsx)', 'The same table as a real Excel sheet with a frozen header row.', 'xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
    ['celtx', 'Celtx (.celtx) – experimental', 'A Celtx-style project. Modern Celtx imports Fountain / FDX most reliably – both are inside.', 'celtx', 'application/zip'],
    ['screenplay', 'Scriptty (.screenplay) – experimental', 'A Scriptty-style file. If it does not open, use Fountain or FDX.', 'screenplay', 'application/json'],
    ['cxscript', 'CX Script (.cxscript) – experimental', 'The format is private, so this is a container holding FDX, Fountain and a finnish backup.', 'cxscript', 'application/zip'],
    ['sbx', 'SBX (.sbx) – experimental', 'The format is private, so this is a container holding FDX, Fountain and a finnish backup.', 'sbx', 'application/zip'],
    ['zip', 'Whole project (.zip)', 'Everything: the backup, the script in every format, and all pictures and storyboard drawings as files.', 'zip', 'application/zip']
  ];
  F.build = function (id, d) { // -> Promise<{ext, mime, data}>
    var meta0 = F.LIST.filter(function (x) { return x[0] === id; })[0]; if (!meta0) return Promise.reject(new Error('Unknown format'));
    var make = { txt: F.toTxt, rtf: F.toRtf, odt: F.toOdt, html: F.toHtml, md: F.toMd, csv: F.toCsv, xlsx: F.toXlsx, celtx: F.toCeltx, screenplay: F.toScriptty, zip: F.toProject, cxscript: function (x) { return F.toContainer(x, 'cxscript'); }, sbx: function (x) { return F.toContainer(x, 'sbx'); } }[id];
    return Promise.resolve(make(d)).then(function (data) { return { ext: meta0[3], mime: meta0[4], data: data }; });
  };

  /* ---------------------------------------------------------------- import */
  F.EXT = ['txt', 'csv', 'rtf', 'html', 'htm', 'md', 'markdown', 'odt', 'xlsx', 'celtx', 'cxscript', 'sbx', 'zip'];
  function fromText(text, fname) { // typed screenplay layout (indented) or Fountain
    var raw = text.replace(/\r/g, '').replace(/\f/g, '\n\n').split('\n'), ne = raw.filter(function (l) { return l.trim(); }), ind = ne.filter(function (l) { return /^ {8,}\S/.test(l) || /^\t+\S/.test(l); }).length;
    if (ne.length >= 8 && ind / ne.length > 0.2) {
      var paras = [], cur = null; raw.forEach(function (l) {
        if (!l.trim()) { cur = null; return; } var lead = (l.match(/^[ \t]*/)[0].replace(/\t/g, '    ')).length, t = l.trim();
        if (cur && cur.lead === lead) { cur.text += '\n' + t; return; }
        var cen = lead > 4 && Math.abs(lead - (60 - Array.from(t).length - lead)) <= 2; cur = { lead: lead, text: t, runs: [], jc: cen && lead < 30 ? 'center' : (lead >= 38 ? 'right' : ''), ind: lead * 144, sty: '', bold: false }; paras.push(cur);
      });
      paras.forEach(function (p) { if (p.jc === 'right' && !/^[A-Z0-9 .:\-']+$/.test(p.text)) { p.jc = ''; } });
      return fromParas(paras, fname);
    }
    var d = THK.newImportDoc(fname.replace(/\.[^.]+$/, '')); d.blocks = THK.parseFountain(text).map(function (b) { b.id = b.id || uid(); return b; }); if (!d.blocks.length) throw new Error('This text file is empty.'); return langOf(fixNotes(d));
  }
  F.fromText = fromText;
  function sniff(z, fname) { // a zip of unknown origin
    var n = Object.keys(z), pick = function (re) { return n.filter(function (k) { return re.test(k); })[0]; };
    var bak = pick(/\.finnish$/i) || (z['project.json'] ? 'project.json' : '');
    if (bak) { var o = JSON.parse(decode(z[bak])); if (o && o.app === 'finnish' && o.docs) return Promise.resolve(o.docs); }
    if (z['word/document.xml']) return THK.parseDocx(zbuf(z), fname).then(function (d) { return [d]; });
    var fdx = pick(/\.fdx$/i); if (fdx) return Promise.resolve([THK.parseFDX(decode(z[fdx]))]);
    var ft = pick(/\.fountain$/i); if (ft) return Promise.resolve([fromText(decode(z[ft]), fname)]);
    var sp = pick(/\.screenplay$/i); if (sp) { try { return Promise.resolve(THK.parseScriptty(JSON.parse(decode(z[sp])))); } catch (e) { } }
    var ht = pick(/(^|\/)script[^\/]*\.html?$/i) || pick(/\.html?$/i); if (ht) return Promise.resolve([F.parseHtml(decode(z[ht]), fname)]);
    var tx = pick(/\.(txt|md)$/i); if (tx) return Promise.resolve([/\.md$/i.test(tx) ? F.parseMd(decode(z[tx]), fname) : fromText(decode(z[tx]), fname)]);
    var js = pick(/\.json$/i); if (js) { var oj = JSON.parse(decode(z[js])); return Promise.resolve(oj.app === 'finnish' ? oj.docs : THK.parseScriptty(oj)); }
    return Promise.reject(new Error('This archive does not contain a script finnish can read (looked for .finnish, .fdx, .fountain, .html, .txt).'));
  }
  var ZB = null; function zbuf(z) { return z.__buf; }
  F.importFile = function (file) { // -> Promise<docs[]>
    var name = file.name, ext = (name.split('.').pop() || '').toLowerCase();
    if (/^(txt|csv|rtf|html|htm|md|markdown)$/.test(ext)) {
      return file.arrayBuffer().then(function (ab) {
        var t = decode(new Uint8Array(ab)), d;
        if (ext === 'txt') d = fromText(t, name); else if (ext === 'csv') d = fromTable(parseCsv(t), name); else if (ext === 'rtf') d = F.parseRtf(t, name); else if (/html?/.test(ext)) d = F.parseHtml(t, name); else d = F.parseMd(t, name);
        return [d];
      });
    }
    return file.arrayBuffer().then(function (ab) {
      var u8 = new Uint8Array(ab), isZip = u8[0] === 0x50 && u8[1] === 0x4B;
      if (ext === 'xlsx') return F.parseXlsx(ab, name).then(function (d) { return [d]; });
      if (ext === 'odt') return F.parseOdt(ab, name).then(function (d) { return [d]; });
      if (isZip) {
        return F.unzip(ab).then(function (z) {
          Object.defineProperty(z, '__buf', { value: ab, enumerable: false });
          if (z['content.xml'] && /opendocument/.test(decode(z['mimetype'] || new Uint8Array()))) return F.parseOdt(ab, name).then(function (d) { return [d]; });
          if (z['xl/workbook.xml']) return F.parseXlsx(ab, name).then(function (d) { return [d]; });
          if (z['project.rdf'] || ext === 'celtx') { var h = Object.keys(z).filter(function (k) { return /\.html?$/i.test(k); }).sort(function (a, b) { return /script/i.test(b) - /script/i.test(a); })[0]; if (h) return [F.parseHtml(decode(z[h]), name)]; }
          return sniff(z, name);
        });
      }
      var t = decode(u8); // not a zip: JSON, XML, HTML or plain text under a private extension
      if (/^\s*[\[{]/.test(t)) { var o = JSON.parse(t); return o && o.app === 'finnish' ? o.docs : THK.parseScriptty(o); }
      if (THK.isFDX(t)) return [THK.parseFDX(t)];
      if (/^\s*(<!doctype html|<html)/i.test(t)) return [F.parseHtml(t, name)];
      if (/^\s*</.test(t)) { var tmp = new DOMParser().parseFromString(t, 'application/xml'); if (!tmp.getElementsByTagName('parsererror').length) { var ps = []; tags(tmp, 'Paragraph').forEach(function (p) { ps.push({ text: p.textContent, runs: [], jc: '', ind: 0, sty: (p.getAttribute('Type') || '').toLowerCase(), bold: false }); }); if (!ps.length) tags(tmp, 'p').forEach(function (p) { ps.push({ text: p.textContent, runs: [], jc: '', ind: 0, sty: (p.getAttribute('class') || p.getAttribute('type') || '').toLowerCase(), bold: false }); }); if (ps.length) return [fromParas(ps, name)]; } }
      return [fromText(t, name)];
    });
  };
})();
