/* Full-screen cover page editor: real paper size, pinch-zoom, every element is its own layer. */
(function () {
  'use strict';
  var A = THK.app, el = A.el, esc = A.esc, $ = A.$, S = A.S, CV = THK.cv, E = THK.cvEd = {};
  var d = null, sel = null, z = 1, PW = 794, PH = 1123, view, stage, page, cvc, cvo, R1, R2, hist = [], hi = -1, ptr = {}, mode = null, preview = false, editing = null, built = false, fitMode = true, gx = null, gy = null, exitT = 0, picker = null;
  var PAL = ['#000000', '#ffffff', '#1f3a5f', '#7a1f2b', '#0f5f4d', '#b7791f', '#5a3e8a', '#c2410c', '#1d4ed8', '#be185d', '#444444', '#9ca3af', '#e5dccb', '#f4f1ea'];
  var PAPERS = [['a4', 'A4'], ['letter', 'Letter'], ['legal', 'Legal'], ['a5', 'A5'], ['custom', 'Custom']];

  function item(id) { return d.cl.items.filter(function (i) { return i.id === id; })[0]; }
  function cur() { return sel ? item(sel) : null; }
  function mm2px(v) { return v * 96 / 25.4; }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function rnd(v) { return Math.round(v * 100) / 100; }

  /* ---------------------------------------------------------------- history */
  function snap() {
    var s = JSON.stringify({ cl: d.cl, paper: d.paper, pw: d.pw, ph: d.ph, cvs: d.cv, cvo: d.cvo }); if (hist[hi] === s) return;
    hist = hist.slice(0, hi + 1); hist.push(s); if (hist.length > 60) hist.shift(); hi = hist.length - 1; A.dirty(); tools();
  }
  function restore(s) {
    var o = JSON.parse(s); d.cl = o.cl; d.paper = o.paper; if (o.pw) d.pw = o.pw; else delete d.pw; if (o.ph) d.ph = o.ph; else delete d.ph; if (o.cvs) d.cv = o.cvs; if (o.cvo) d.cvo = o.cvo;
    if (sel && !item(sel)) sel = null; layout(); draw(); tools(); A.dirty();
  }
  function undo() { if (hi > 0) { hi--; restore(hist[hi]); } }
  function redo() { if (hi < hist.length - 1) { hi++; restore(hist[hi]); } }

  /* ---------------------------------------------------------------- build the screen once */
  function build() {
    if (built) return; built = true;
    view = $('#cvView'); stage = $('#cvStage'); page = $('#cvPage'); cvc = $('#cvc'); cvo = $('#cvo'); R1 = $('#cR1'); R2 = $('#cR2');
    var f = $('#cAcc'); f.innerHTML = '';
    var fit = pill('Fit', function () { fitMode = true; fitPage(); }); fit.id = 'cFit';
    var pv = pill('Preview', function () { enterPreview(); }); var dn = pill('Done', function () { finish(); }, 'pri');
    f.appendChild(fit); f.appendChild(pv); f.appendChild(dn);
    view.addEventListener('pointerdown', pdown); view.addEventListener('pointermove', pmove); view.addEventListener('pointerup', pup); view.addEventListener('pointercancel', pup); view.addEventListener('contextmenu', function (e) { if (!editing) e.preventDefault(); });
    view.addEventListener('wheel', function (e) { if (!(e.ctrlKey || e.metaKey)) return; e.preventDefault(); zoomAt(e.clientX, e.clientY, z * (e.deltaY < 0 ? 1.1 : 1 / 1.1)); }, { passive: false });
    document.addEventListener('keydown', keys);
    window.addEventListener('resize', function () { if (!$('#cvEd').hidden) { if (fitMode || preview) fitPage(); } });
    var st = document.createElement('style'); st.textContent = CV.layerCss() + CSS; document.head.appendChild(st);
  }
  function pill(t, fn, cls, title) { var b = el('button', 'btn' + (cls ? ' ' + cls : ''), esc(t)); b.type = 'button'; b.onmousedown = function (e) { e.preventDefault(); }; b.onclick = function (e) { fn(e.currentTarget, e); }; if (title) b.title = title; return b; }

  E.open = function () {
    d = A.cur; if (!d) return A.toast('Open a script first');
    try { if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); } catch (e) { }
    build(); if (!d.cl) { d.cl = CV.fromStyle(d); A.dirty(); }
    sel = null; editing = null; preview = false; hist = []; hi = -1; fitMode = true; ptr = {}; mode = null;
    A.show('cvEd'); document.documentElement.classList.remove('cvpv');
    layout(); draw(); snap(); tools(); top1(); setTimeout(function () { fitPage(); }, 30); setTimeout(fitPage, 250);
    THK.loadFont(d.titleFont || d.font);
  };
  E.back = function () { if (!d) return false; if (preview) { exitPreview(); return true; } if (editing) { endEdit(); return true; } finish(); return true; };
  function finish() {
    endEdit(); preview = false; document.documentElement.classList.remove('cvpv'); try { A.persist(); } catch (e) { }
    A.applyLook(); A.renderAll(); A.show('app'); A.toast('Cover saved ✓');
  }

  /* ---------------------------------------------------------------- layout / zoom */
  function layout() { var D = CV.dim(d); PW = mm2px(D.w); PH = mm2px(D.h); cvc.style.width = PW + 'px'; cvc.style.height = PH + 'px'; page.style.width = PW + 'px'; page.style.height = PH + 'px'; applyZ(); }
  function applyZ() {
    var pad = preview ? 10 : 28; page.style.transform = 'scale(' + z + ')'; page.style.setProperty('--z', z); stage.style.width = (PW * z + pad * 2) + 'px'; stage.style.height = (PH * z + pad * 2) + 'px'; page.style.left = pad + 'px'; page.style.top = pad + 'px';
    var fb = $('#cFit'); if (fb) fb.classList.toggle('on', fitMode);
  }
  function fitPage() {
    if (!view) return; var pad = preview ? 10 : 28, vw = view.clientWidth, vh = view.clientHeight; if (!vw || !vh) return;
    z = clamp(Math.min((vw - pad * 2) / PW, (vh - pad * 2) / PH), .1, 4); applyZ(); view.scrollLeft = 0; view.scrollTop = 0; overlay();
  }
  function zoomAt(cx, cy, nz) {
    nz = clamp(nz, .15, 5); var r = page.getBoundingClientRect(), px = (cx - r.left) / z, py = (cy - r.top) / z; z = nz; fitMode = false; applyZ();
    var r2 = page.getBoundingClientRect(); view.scrollLeft += (r2.left + px * z) - cx; view.scrollTop += (r2.top + py * z) - cy; overlay();
  }

  /* ---------------------------------------------------------------- drawing */
  function draw() { cvc.innerHTML = CV.pageHtml(d, !preview); cvc.classList.toggle('edit', !preview); overlay(); }
  function itemEl(id) { return cvc.querySelector('.cvi[data-i="' + id + '"]'); }
  function repaint(it) {
    var e = itemEl(it.id), t = document.createElement('div'); t.innerHTML = CV.itemHtml(d, it, true);
    if (!t.firstChild) { if (e) e.remove(); } else if (e) e.replaceWith(t.firstChild); else draw();
    overlay();
  }
  function overlay() {
    cvo.innerHTML = ''; var it = cur(); if (!it || preview || it.hide) return;
    var o = el('div', 'csel'); o.style.cssText = 'left:' + it.x + '%;top:' + it.y + '%;width:' + it.w + '%;height:' + it.h + '%;' + (it.r ? 'transform:rotate(' + it.r + 'deg);' : '');
    ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'].forEach(function (h) { var x = el('i', 'hd h-' + h); x.dataset.h = h; o.appendChild(x); });
    var rot = el('i', 'hr'); rot.dataset.h = 'rot'; o.appendChild(rot); cvo.appendChild(o);
    if (gx != null) { var g = el('div', 'cg gv'); g.style.left = gx + '%'; cvo.appendChild(g); } if (gy != null) { var g2 = el('div', 'cg gh'); g2.style.top = gy + '%'; cvo.appendChild(g2); }
  }
  function select(id) { if (editing && editing.id !== id) endEdit(); sel = id; overlay(); tools(); }

  /* ---------------------------------------------------------------- pointer handling (move / resize / rotate / pan / pinch) */
  function pt(e) { var r = page.getBoundingClientRect(); return { x: (e.clientX - r.left) / z, y: (e.clientY - r.top) / z }; }
  function pdown(e) {
    if (preview) { exitPreview(); return; }
    if (editing && e.target.closest && e.target.closest('.cvt[contenteditable]')) return;
    try { view.setPointerCapture(e.pointerId); } catch (x) { }
    ptr[e.pointerId] = { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, t: Date.now(), moved: false };
    var ids = Object.keys(ptr);
    if (ids.length === 2) { startPinch(); return; }
    var t = e.target, hd = t.closest && t.closest('.hd,.hr'), it = cur(), P = pt(e);
    if (hd && it) {
      var h = hd.dataset.h; mode = h === 'rot' ? { k: 'rot', it: it, c: center(it) } : { k: 'size', it: it, h: h, p0: P, b: { x: it.x, y: it.y, w: it.w, h: it.h, s: it.s } };
      return;
    }
    var ie = t.closest && t.closest('.cvi'); var hit = ie && item(ie.dataset.i);
    if (hit && !hit.lock) {
      var was = sel === hit.id; if (!was) select(hit.id);
      mode = { k: 'move', it: hit, p0: P, b: { x: hit.x, y: hit.y }, was: was };
    } else {
      if (sel) { select(null); }
      mode = { k: 'pan', sl: view.scrollLeft, st: view.scrollTop };
    }
  }
  function center(it) { var r = page.getBoundingClientRect(); return { x: r.left + (it.x + it.w / 2) / 100 * PW * z, y: r.top + (it.y + it.h / 2) / 100 * PH * z }; }
  function pmove(e) {
    var p = ptr[e.pointerId]; if (!p) return; var dx = e.clientX - p.x, dy = e.clientY - p.y; if (Math.abs(e.clientX - p.sx) + Math.abs(e.clientY - p.sy) > (e.pointerType === 'mouse' ? 4 : 10) || p.moved) p.moved = true; p.x = e.clientX; p.y = e.clientY;
    if (!mode) return;
    if (mode.k === 'pinch') { doPinch(); return; }
    if (!p.moved) return;
    var P = pt(e), it = mode.it;
    if (mode.k === 'pan') { view.scrollLeft = mode.sl - (e.clientX - p.sx); view.scrollTop = mode.st - (e.clientY - p.sy); if (fitMode) { fitMode = false; var fb = $('#cFit'); if (fb) fb.classList.remove('on'); } return; }
    if (mode.k === 'move') {
      var nx = mode.b.x + (P.x - mode.p0.x) / PW * 100, ny = mode.b.y + (P.y - mode.p0.y) / PH * 100, th = 7 / z / PW * 100, thy = 7 / z / PH * 100; gx = gy = null;
      var cx = nx + it.w / 2, cy = ny + it.h / 2;
      if (Math.abs(cx - 50) < th) { nx = 50 - it.w / 2; gx = 50; } else if (Math.abs(nx) < th) { nx = 0; gx = 0; } else if (Math.abs(nx + it.w - 100) < th) { nx = 100 - it.w; gx = 100; }
      if (Math.abs(cy - 50) < thy) { ny = 50 - it.h / 2; gy = 50; } else if (Math.abs(ny) < thy) { ny = 0; gy = 0; } else if (Math.abs(ny + it.h - 100) < thy) { ny = 100 - it.h; gy = 100; }
      it.x = rnd(nx); it.y = rnd(ny); place(it); return;
    }
    if (mode.k === 'rot') { var c = mode.c, a = Math.atan2(e.clientY - c.y, e.clientX - c.x) * 180 / Math.PI + 90; a = ((a % 360) + 360) % 360; if (a > 180) a -= 360; var q = Math.round(a / 15) * 15; if (Math.abs(a - q) < 4) a = q; it.r = Math.round(a * 10) / 10; if (!it.r) delete it.r; place(it); return; }
    if (mode.k === 'size') { resize(it, P); }
  }
  function place(it) {
    var e = itemEl(it.id); if (e) { e.style.left = it.x + '%'; e.style.top = it.y + '%'; e.style.width = it.w + '%'; e.style.height = it.h + '%'; e.style.transform = it.r ? 'rotate(' + it.r + 'deg)' : ''; }
    var o = cvo.querySelector('.csel'); if (o) { o.style.left = it.x + '%'; o.style.top = it.y + '%'; o.style.width = it.w + '%'; o.style.height = it.h + '%'; o.style.transform = it.r ? 'rotate(' + it.r + 'deg)' : ''; }
    var g = cvo.querySelectorAll('.cg'); [].forEach.call(g, function (x) { x.remove(); });
    if (gx != null) { var a = el('div', 'cg gv'); a.style.left = gx + '%'; cvo.appendChild(a); } if (gy != null) { var b = el('div', 'cg gh'); b.style.top = gy + '%'; cvo.appendChild(b); }
  }
  function resize(it, P) {
    var b = mode.b, h = mode.h, sx = h.indexOf('e') >= 0 ? 1 : h.indexOf('w') >= 0 ? -1 : 0, sy = h.indexOf('s') >= 0 ? 1 : h.indexOf('n') >= 0 ? -1 : 0;
    var w0 = b.w / 100 * PW, h0 = b.h / 100 * PH, cx0 = (b.x + b.w / 2) / 100 * PW, cy0 = (b.y + b.h / 2) / 100 * PH, r = (it.r || 0) * Math.PI / 180, cs = Math.cos(r), sn = Math.sin(r);
    var ddx = P.x - mode.p0.x, ddy = P.y - mode.p0.y, ldx = ddx * cs + ddy * sn, ldy = -ddx * sn + ddy * cs;
    var nw = Math.max(8, w0 + sx * ldx), nh = Math.max(8, h0 + sy * ldy);
    if (sx && sy) { var k = Math.max(nw / w0, nh / h0); nw = w0 * k; nh = h0 * k; if (it.k === 'text' && b.s) it.s = Math.max(4, rnd(b.s * k)); }
    var lcx = sx * (nw - w0) / 2, lcy = sy * (nh - h0) / 2, gcx = cx0 + lcx * cs - lcy * sn, gcy = cy0 + lcx * sn + lcy * cs;
    it.w = rnd(nw / PW * 100); it.h = rnd(nh / PH * 100); it.x = rnd((gcx - nw / 2) / PW * 100); it.y = rnd((gcy - nh / 2) / PH * 100);
    if (it.k === 'text' && sx && sy) { var tx = itemEl(it.id); if (tx) { var t = tx.querySelector('.cvt'); if (t) t.style.fontSize = it.s + 'pt'; } }
    place(it);
  }
  function pup(e) {
    var p = ptr[e.pointerId]; delete ptr[e.pointerId]; try { view.releasePointerCapture(e.pointerId); } catch (x) { }
    var left = Object.keys(ptr).length;
    if (mode && mode.k === 'pinch') { if (left < 2) { var done = mode; mode = null; if (done.item) { snap(); repaint(done.it); } else if (left === 1) { /* keep panning with the remaining finger */ var q = ptr[Object.keys(ptr)[0]]; q.sx = q.x; q.sy = q.y; mode = { k: 'pan', sl: view.scrollLeft, st: view.scrollTop }; } } return; }
    if (!mode) return;
    var m = mode; mode = null; gx = gy = null;
    if (m.k === 'move' || m.k === 'size' || m.k === 'rot') {
      if (p && p.moved) { if (m.k !== 'move') repaint(m.it); else overlay(); snap(); }
      else if (m.k === 'move') { if (m.was && m.it.k === 'text') startEdit(m.it); else overlay(); }
    }
  }
  function startPinch() {
    var ids = Object.keys(ptr), a = ptr[ids[0]], b = ptr[ids[1]], it = cur(), dist = Math.hypot(a.x - b.x, a.y - b.y) || 1, mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2, onItem = false;
    if (it && !it.lock) { var o = cvo.querySelector('.csel'); if (o) { var r = o.getBoundingClientRect(); var pad = 30; onItem = [a, b].every(function (q) { return q.x > r.left - pad && q.x < r.right + pad && q.y > r.top - pad && q.y < r.bottom + pad; }); } }
    mode = { k: 'pinch', d0: dist, z0: z, it: it, item: onItem, b: it ? { x: it.x, y: it.y, w: it.w, h: it.h, s: it.s } : null, mx: mx, my: my, id: ids };
  }
  function doPinch() {
    var m = mode, a = ptr[m.id[0]], b = ptr[m.id[1]]; if (!a || !b) return; var dist = Math.hypot(a.x - b.x, a.y - b.y) || 1, k = dist / m.d0;
    if (m.item && m.it) {
      var it = m.it, cx = m.b.x + m.b.w / 2, cy = m.b.y + m.b.h / 2, nw = clamp(m.b.w * k, 1, 400), kk = nw / m.b.w, nh = m.b.h * kk;
      it.w = rnd(nw); it.h = rnd(nh); it.x = rnd(cx - nw / 2); it.y = rnd(cy - nh / 2); if (it.k === 'text' && m.b.s) it.s = Math.max(4, rnd(m.b.s * kk));
      place(it); var e = itemEl(it.id); if (e && it.k === 'text') { var t = e.querySelector('.cvt'); if (t) t.style.fontSize = it.s + 'pt'; }
      return;
    }
    var mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2; zoomAt(mx, my, m.z0 * k);
    view.scrollLeft -= (mx - m.mx); view.scrollTop -= (my - m.my); m.mx = mx; m.my = my;
  }

  /* ---------------------------------------------------------------- in-place text editing */
  function startEdit(it) {
    if (it.lock || it.k !== 'text') return; endEdit(); var e = itemEl(it.id); if (!e) return; var t = e.querySelector('.cvt'); if (!t) return;
    editing = { id: it.id, t: t }; t.contentEditable = 'plaintext-only'; if (t.contentEditable !== 'plaintext-only') t.contentEditable = 'true'; t.spellcheck = false; t.classList.add('editing');
    t.addEventListener('input', onEditInput); t.addEventListener('keydown', onEditKey); t.addEventListener('blur', onEditBlur);
    if (it.bind && (d.cfm || {})[it.bind]) { /* rich runs would no longer match – plain text from here on */ }
    t.focus(); var r = document.createRange(); r.selectNodeContents(t); r.collapse(false); var s = getSelection(); s.removeAllRanges(); s.addRange(r);
  }
  function readEdit() { var t = editing.t, v = t.innerText.replace(/ /g, ' ').replace(/\n$/, ''); return v; }
  function onEditInput() { if (!editing) return; var it = item(editing.id), v = readEdit(); if (it.bind) { d[it.bind] = v; if (d.cfm) { delete d.cfm[it.bind]; } } else it.t = v; A.dirty(); }
  function onEditKey(e) {
    if (e.key === 'Escape') { e.preventDefault(); return endEdit(); }
    if (e.ctrlKey || e.metaKey) return;
    if (e.key.length === 1 && S.ml && /[A-Za-z]/.test(e.key) && !e.altKey && THK.phon) { e.preventDefault(); THK.phon.type(e.key); onEditInput(); return; }
    if (e.key === 'Backspace' && THK.phon && THK.phon.st.buf) { var s = getSelection(); if (s.rangeCount && s.anchorNode === THK.phon.st.node && s.anchorOffset === THK.phon.st.off && s.isCollapsed) { e.preventDefault(); THK.phon.back(); onEditInput(); return; } }
    if (THK.phon) THK.phon.st.buf = '';
  }
  function onEditBlur() { setTimeout(function () { if (editing && document.activeElement !== editing.t) endEdit(); }, 60); }
  function endEdit() {
    if (!editing) return; var e = editing; editing = null; e.t.removeEventListener('input', onEditInput); e.t.removeEventListener('keydown', onEditKey); e.t.removeEventListener('blur', onEditBlur);
    var it = item(e.id); if (it) { var v = (function () { var x = e.t.innerText.replace(/ /g, ' ').replace(/\n$/, ''); return x; })(); if (it.bind) { d[it.bind] = v; if (d.cfm) delete d.cfm[it.bind]; } else it.t = v; repaint(it); snap(); }
  }

  /* ---------------------------------------------------------------- keyboard (desktop) */
  function keys(e) {
    if ($('#cvEd').hidden) return; if (editing) return; if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
    var mod = e.ctrlKey || e.metaKey, k = e.key, it = cur();
    if (preview) { if (k === 'Escape') exitPreview(); return; }
    if (mod && k.toLowerCase() === 'z') { e.preventDefault(); return e.shiftKey ? redo() : undo(); }
    if (mod && k.toLowerCase() === 'y') { e.preventDefault(); return redo(); }
    if (mod && k.toLowerCase() === 'd' && it) { e.preventDefault(); return dup(it); }
    if (!it) return;
    if (k === 'Delete' || k === 'Backspace') { e.preventDefault(); return del(it); }
    if (k === 'Escape') return select(null);
    var st = e.shiftKey ? 2 : .4; if (k === 'ArrowLeft') it.x = rnd(it.x - st); else if (k === 'ArrowRight') it.x = rnd(it.x + st); else if (k === 'ArrowUp') it.y = rnd(it.y - st); else if (k === 'ArrowDown') it.y = rnd(it.y + st); else return;
    e.preventDefault(); place(it); clearTimeout(keys.t); keys.t = setTimeout(snap, 400);
  }

  /* ---------------------------------------------------------------- item operations */
  function add(it, name) { it.id = CV.nid(); if (name && !it.n) it.n = name; d.cl.items.push(it); sel = it.id; draw(); tools(); snap(); return it; }
  function dup(it) { var c = JSON.parse(JSON.stringify(it)); c.id = CV.nid(); c.x = rnd(Math.min(95, it.x + 3)); c.y = rnd(Math.min(95, it.y + 2)); c.n = (it.n || 'Item') + ' copy'; if (c.bind) { delete c.bind; c.t = CV.textOf(d, it); } d.cl.items.push(c); sel = c.id; draw(); tools(); snap(); }
  function del(it) { endEdit(); d.cl.items = d.cl.items.filter(function (x) { return x !== it; }); if (sel === it.id) sel = null; draw(); tools(); snap(); }
  function order(it, how) {
    var a = d.cl.items, i = a.indexOf(it); if (i < 0) return; a.splice(i, 1);
    if (how === 'front') a.push(it); else if (how === 'back') a.unshift(it); else if (how === 'up') a.splice(Math.min(a.length, i + 1), 0, it); else a.splice(Math.max(0, i - 1), 0, it);
    draw(); snap();
  }
  function setP(it, props, commit) { Object.keys(props).forEach(function (k) { if (props[k] === '' || props[k] == null || props[k] === false) delete it[k]; else it[k] = props[k]; }); repaint(it); if (commit !== false) snap(); }
  function newText(bind, t, o) {
    var tc = d.textColor || '#000000', it = { k: 'text', n: bind ? CV.BIND[bind] : 'Text', x: 15, y: 40, w: 70, h: 8, s: bind === 'title' ? 34 : 14, al: 'center', c: tc, f: bind === 'title' ? (d.titleFont || d.font) : d.font, va: 'middle' };
    if (bind) it.bind = bind; else it.t = t || 'Your text'; if (bind === 'title') { it.b = 1; it.h = 14; it.y = 30; }
    for (var k in o) it[k] = o[k]; return it;
  }
  function loadImage(file, max, cb) {
    var fr = new FileReader(); fr.onload = function () {
      var im = new Image(); im.onload = function () {
        var s = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.max(1, Math.round(im.width * s)); c.height = Math.max(1, Math.round(im.height * s));
        var g = c.getContext('2d'); g.drawImage(im, 0, 0, c.width, c.height); var png = /png|gif|webp|svg/.test(file.type); var out = png ? c.toDataURL('image/png') : c.toDataURL('image/jpeg', .88);
        if (png && out.length > 2200000) out = c.toDataURL('image/jpeg', .88); cb(out, im.width, im.height);
      }; im.onerror = function () { A.toast('That image could not be read'); }; im.src = fr.result;
    }; fr.onerror = function () { A.toast('That file could not be read'); }; fr.readAsDataURL(file);
  }
  function pickImage(max, cb) {
    if (picker) picker.remove(); picker = document.createElement('input'); picker.type = 'file'; picker.accept = 'image/*'; picker.style.display = 'none'; document.body.appendChild(picker);
    picker.onchange = function () { var f = picker.files && picker.files[0]; if (f) loadImage(f, max, cb); }; picker.click();
  }

  /* ---------------------------------------------------------------- top bars */
  function top1() {
    R1.innerHTML = '';
    R1.appendChild(pill('Add', addMenu, '', 'Add a title, text, image, border…'));
    R1.appendChild(pill('Layers', layersDlg)); R1.appendChild(pill('Templates', templatesDlg)); R1.appendChild(pill('Page', pageDlg));
    var u = pill('Undo', undo); u.id = 'cUndo'; var r = pill('Redo', redo); r.id = 'cRedo'; R1.appendChild(u); R1.appendChild(r);
    var lg = pill(THK.lang(S.lang).native, function (b) { A.langMenu(b); }, S.ml ? 'on' : '', 'Typing language'); lg.id = 'cLang'; R1.appendChild(lg);
  }
  E.refresh = function () { var l = $('#cLang'); if (l && !$('#cvEd').hidden) { l.textContent = THK.lang(S.lang).native; l.classList.toggle('on', !!S.ml); } };
  function tools() {
    var u = $('#cUndo'), r = $('#cRedo'); if (u) u.classList.toggle('dis', hi <= 0); if (r) r.classList.toggle('dis', hi >= hist.length - 1);
    R2.innerHTML = ''; var it = cur();
    if (!it) { R2.appendChild(el('span', 'chint', 'Tap anything on the page to edit it  ·  pinch to zoom  ·  use Add for new items')); return; }
    var tg = function (label, key, title) { var b = pill(label, function () { setP(it, (function () { var o = {}; o[key] = it[key] ? 0 : 1; return o; })()); tools(); }, it[key] ? 'on' : '', title); return b; };
    if (it.k === 'text') {
      R2.appendChild(pill('Edit text', function () { startEdit(it); }, 'pri'));
      R2.appendChild(pill('Font', fontPop)); R2.appendChild(pill('Size', sizePop)); R2.appendChild(pill('Colour', function (a) { colorPop(a, it.c || d.textColor || '#000000', function (c, fin) { setP(it, { c: c }, fin); }); }));
      var b1 = tg('B', 'b', 'Bold'); b1.style.fontWeight = 800; var i1 = tg('I', 'i', 'Italic'); i1.style.fontStyle = 'italic'; var u1 = tg('U', 'u', 'Underline'); u1.style.textDecoration = 'underline';
      R2.appendChild(b1); R2.appendChild(i1); R2.appendChild(u1); R2.appendChild(tg('CAPS', 'up', 'Capital letters'));
      R2.appendChild(pill('Align', alignPop)); R2.appendChild(pill('Spacing', spacingPop)); R2.appendChild(pill('Box', boxPop)); R2.appendChild(pill('Opacity', opPop)); R2.appendChild(tg('Shadow', 'sh'));
    } else if (it.k === 'img') {
      R2.appendChild(pill('Replace', function () { pickImage(1600, function (src) { setP(it, { src: src }); }); }, 'pri'));
      R2.appendChild(pill('Fit', fitPop)); R2.appendChild(pill('Corners', radPop)); R2.appendChild(pill('Border', boxPop)); R2.appendChild(pill('Opacity', opPop)); R2.appendChild(tg('Shadow', 'sh'));
    } else {
      R2.appendChild(pill('Fill', function (a) { colorPop(a, it.fill || '', function (c, fin) { setP(it, { fill: c }, fin); }, true); }, 'pri'));
      R2.appendChild(pill('Border', boxPop)); if (it.k === 'rect') R2.appendChild(pill('Corners', radPop)); R2.appendChild(pill('Opacity', opPop)); R2.appendChild(pill('Blur', blurPop)); R2.appendChild(tg('Shadow', 'sh'));
    }
    R2.appendChild(pill('Arrange', arrangePop)); R2.appendChild(pill(it.lock ? 'Unlock' : 'Lock', function () { setP(it, { lock: it.lock ? 0 : 1 }); select(sel); }, it.lock ? 'on' : ''));
    R2.appendChild(pill('Copy', function () { dup(it); })); R2.appendChild(pill('Delete', function () { del(it); }, 'danger'));
  }

  /* ---------------------------------------------------------------- small controls used inside pop-overs */
  function rng(m, label, min, max, step, val, fn, fmt) {
    var r = el('div', 'crg'), l = el('span', '', esc(label)), v = el('b', '', ''), i = el('input'); i.type = 'range'; i.min = min; i.max = max; i.step = step; i.value = val; fmt = fmt || function (x) { return x; }; v.textContent = fmt(+val);
    i.oninput = function () { v.textContent = fmt(+i.value); fn(+i.value, false); }; i.onchange = function () { fn(+i.value, true); }; r.appendChild(l); r.appendChild(i); r.appendChild(v); m.appendChild(r); return i;
  }
  function seg(m, label, opts, get, set) {
    if (label) m.appendChild(el('div', 'chd', esc(label))); var r = el('div', 'cseg'); m.appendChild(r);
    opts.forEach(function (o) { var b = el('button', 'btn sm' + (get() === o[0] ? ' on' : ''), esc(o[1])); b.type = 'button'; b.onmousedown = function (e) { e.preventDefault(); }; b.onclick = function () { set(o[0]); [].forEach.call(r.children, function (c) { c.classList.remove('on'); }); b.classList.add('on'); }; r.appendChild(b); });
  }
  function colorBox(m, val, fn, none) {
    var g = el('div', 'csw'); m.appendChild(g); var pal = PAL.slice(); [d.textColor, d.pageColor, (d.cvo || {}).acc].forEach(function (c) { if (c && pal.indexOf(c) < 0) pal.unshift(c); });
    pal.forEach(function (c) { var s = el('button', 'sw' + ((val || '').toLowerCase() === c.toLowerCase() ? ' on' : '')); s.type = 'button'; s.style.background = c; s.onmousedown = function (e) { e.preventDefault(); }; s.onclick = function () { fn(c, true); [].forEach.call(g.querySelectorAll('.sw'), function (x) { x.classList.remove('on'); }); s.classList.add('on'); }; g.appendChild(s); });
    var ci = el('input'); ci.type = 'color'; ci.className = 'swc'; ci.value = /^#[0-9a-f]{6}$/i.test(val || '') ? val : '#888888'; ci.title = 'Any colour'; ci.oninput = function () { fn(ci.value, false); }; ci.onchange = function () { fn(ci.value, true); }; g.appendChild(ci);
    if (none) { var n = el('button', 'btn sm', 'None'); n.type = 'button'; n.onclick = function () { fn('', true); }; g.appendChild(n); }
  }
  function popup(anchor, fill, cls) { A.pop(anchor, function (m, close) { m.classList.add('cpop'); if (cls) m.classList.add(cls); fill(m, close); }, { cls: 'cpm' }); }
  function colorPop(a, val, fn, none) { popup(a, function (m) { m.appendChild(el('div', 'chd', 'Colour')); colorBox(m, val, fn, none); }); }
  function fontList(m, it) {
    var lang = S.lang, mine = THK.fontsFor(lang, false), disp = THK.fontsFor(lang, true).filter(function (f) { return mine.indexOf(f) < 0; }), en = THK.fontsFor('en', true).filter(function (f) { return mine.indexOf(f) < 0 && disp.indexOf(f) < 0; });
    var cur0 = it.f || (it.bind === 'title' ? (d.titleFont || d.font) : d.font);
    var grp = function (t, l) { if (!l.length) return; m.appendChild(el('div', 'chd', esc(t))); l.forEach(function (f) { THK.loadFont(f.id); var b = el('button', 'btn sm cfont' + (f.id === cur0 ? ' on' : ''), esc(f.label)); b.type = 'button'; b.style.fontFamily = f.stack; b.onmousedown = function (e) { e.preventDefault(); }; b.onclick = function () { setP(it, { f: f.id }); [].forEach.call(m.querySelectorAll('.cfont'), function (x) { x.classList.remove('on'); }); b.classList.add('on'); }; m.appendChild(b); }); };
    grp(THK.lang(lang).name + ' fonts', mine); grp('Display fonts', disp); grp('English display fonts', en);
  }
  function fontPop(a) { var it = cur(); if (!it) return; popup(a, function (m) { var l = el('div', 'cfl'); m.appendChild(l); fontList(l, it); }, 'wide'); }
  function sizePop(a) {
    var it = cur(); if (!it) return; popup(a, function (m) {
      m.appendChild(el('div', 'chd', 'Text size (pt)')); var row = el('div', 'cseg'), n = el('input'), ap = function (v, f) { v = clamp(Math.round(v * 2) / 2, 4, 300); n.value = v; setP(it, { s: v }, f !== false); }; n.type = 'number'; n.className = 'cnum'; n.value = it.s || 12; n.step = 1; n.onchange = function () { ap(+n.value || 12); };
      var mi = pill('−', function () { ap((it.s || 12) - 1); }), pl = pill('+', function () { ap((it.s || 12) + 1); }); row.appendChild(mi); row.appendChild(n); row.appendChild(pl); m.appendChild(row);
      var q = el('div', 'cseg'); [8, 10, 12, 14, 18, 24, 32, 44, 60, 90].forEach(function (v) { q.appendChild(pill(String(v), function () { ap(v); }, 'sm')); }); m.appendChild(q);
    });
  }
  function alignPop(a) {
    var it = cur(); if (!it) return; popup(a, function (m) {
      seg(m, 'Align', [['left', 'Left'], ['center', 'Centre'], ['right', 'Right'], ['justify', 'Justify']], function () { return it.al || 'left'; }, function (v) { setP(it, { al: v }); });
      seg(m, 'Position in the box', [['top', 'Top'], ['middle', 'Middle'], ['bottom', 'Bottom']], function () { return it.va || 'top'; }, function (v) { setP(it, { va: v }); });
    });
  }
  function spacingPop(a) {
    var it = cur(); if (!it) return; popup(a, function (m) {
      rng(m, 'Letters', -0.05, 0.6, 0.01, it.ls || 0, function (v, f) { setP(it, { ls: v }, f); }, function (v) { return v.toFixed(2) + ' em'; });
      rng(m, 'Lines', 0.8, 2.6, 0.05, it.lh || 1.25, function (v, f) { setP(it, { lh: v }, f); }, function (v) { return v.toFixed(2); });
    });
  }
  function opPop(a) { var it = cur(); if (!it) return; popup(a, function (m) { rng(m, 'Opacity', 0.05, 1, 0.05, it.op == null ? 1 : it.op, function (v, f) { setP(it, { op: v >= 1 ? '' : v }, f); }, function (v) { return Math.round(v * 100) + '%'; }); }); }
  function blurPop(a) { var it = cur(); if (!it) return; popup(a, function (m) { rng(m, 'Soft edge', 0, 40, 1, it.bl || 0, function (v, f) { setP(it, { bl: v }, f); }, function (v) { return v + ' mm'; }); }); }
  function radPop(a) { var it = cur(); if (!it) return; popup(a, function (m) { rng(m, 'Corner radius', 0, 60, 1, it.rad || 0, function (v, f) { setP(it, { rad: v }, f); }, function (v) { return v + ' mm'; }); }); }
  function fitPop(a) { var it = cur(); if (!it) return; popup(a, function (m) { seg(m, 'Picture fit', [['cover', 'Fill'], ['contain', 'Fit inside'], ['fill', 'Stretch']], function () { return it.fit || 'cover'; }, function (v) { setP(it, { fit: v }); }); }); }
  function boxPop(a) {
    var it = cur(); if (!it) return; popup(a, function (m) {
      if (it.k !== 'img') { m.appendChild(el('div', 'chd', 'Fill')); colorBox(m, it.fill || '', function (c, f) { setP(it, { fill: c }, f); }, true); }
      m.appendChild(el('div', 'chd', 'Border colour')); colorBox(m, it.bc || '', function (c, f) { setP(it, { bc: c, bw: it.bw || 1 }, f); });
      rng(m, 'Border width', 0, 12, 0.25, it.bw || 0, function (v, f) { setP(it, { bw: v, bc: it.bc || d.textColor || '#000000' }, f); }, function (v) { return v + ' pt'; });
      seg(m, 'Border style', [['solid', 'Solid'], ['double', 'Double'], ['dashed', 'Dashed'], ['dotted', 'Dotted']], function () { return it.bs || 'solid'; }, function (v) { setP(it, { bs: v === 'solid' ? '' : v, bw: Math.max(it.bw || 0, v === 'double' ? 3 : 1) }); });
      if (it.k !== 'ellipse') rng(m, 'Corner radius', 0, 60, 1, it.rad || 0, function (v, f) { setP(it, { rad: v }, f); }, function (v) { return v + ' mm'; });
      if (it.k === 'text') rng(m, 'Inner space', 0, 30, 0.5, it.pd || 0, function (v, f) { setP(it, { pd: v }, f); }, function (v) { return v + ' mm'; });
    });
  }
  function arrangePop(a) {
    var it = cur(); if (!it) return; popup(a, function (m) {
      m.appendChild(el('div', 'chd', 'Layer order')); var r = el('div', 'cseg'); m.appendChild(r);
      [['To front', 'front'], ['Forward', 'up'], ['Backward', 'down'], ['To back', 'back']].forEach(function (o) { r.appendChild(pill(o[0], function () { order(it, o[1]); }, 'sm')); });
      m.appendChild(el('div', 'chd', 'Place on page')); var r2 = el('div', 'cseg'); m.appendChild(r2);
      [['Centre across', function () { it.x = rnd(50 - it.w / 2); }], ['Centre down', function () { it.y = rnd(50 - it.h / 2); }], ['Full width', function () { it.x = 0; it.w = 100; }], ['Fill page', function () { it.x = 0; it.y = 0; it.w = 100; it.h = 100; }], ['Straighten', function () { delete it.r; }]].forEach(function (o) { r2.appendChild(pill(o[0], function () { o[1](); place(it); repaint(it); snap(); }, 'sm')); });
      rng(m, 'Rotate', -180, 180, 1, it.r || 0, function (v, f) { if (v) it.r = v; else delete it.r; place(it); if (f) snap(); }, function (v) { return v + '°'; });
    });
  }

  /* ---------------------------------------------------------------- Add menu */
  function addMenu(a) {
    var has = function (b) { return d.cl.items.some(function (i) { return i.bind === b; }); }, tc = d.textColor || '#000000', ac = (d.cvo || {}).acc || tc;
    var bound = function (b, label, o) { return { l: label, fn: function () { if (has(b)) { var ex = d.cl.items.filter(function (i) { return i.bind === b; })[0]; if (ex.hide) { ex.hide = 0; delete ex.hide; } select(ex.id); draw(); A.toast(label + ' is already on the cover – selected it'); } else { var it = newText(b, '', o); add(it); } } }; };
    A.menu(a, [
      { hd: 'Titles & names' }, bound('title', 'Main title'), bound('writer', 'Writer name', { y: 56, s: 15, h: 5 }), bound('director', 'Director name', { y: 66, s: 15, h: 5 }), bound('date', 'Date', { y: 90, s: 9, h: 4 }), bound('basedOn', 'Based on…', { y: 76, s: 10.5, h: 4, i: 1 }), bound('contact', 'Contact details', { x: 9, y: 88, w: 42, h: 7, s: 8.5, al: 'left' }), bound('draft', 'Draft / version', { x: 51, y: 88, w: 40, h: 4, s: 8.5, al: 'right' }),
      { hr: 1 }, { hd: 'Text' }, { l: 'Custom text', fn: function () { add(newText('', 'Your text', { s: 16 })); } }, { l: 'Subtitle / tagline', fn: function () { add(newText('', 'A subtitle goes here', { y: 48, s: 14, i: 1, h: 6 }), 'Subtitle'); } }, { l: 'Quote', fn: function () { add(newText('', '“A line from the film”', { y: 70, s: 13, i: 1, h: 10 }), 'Quote'); } },
      { hr: 1 }, { hd: 'Pictures' }, { l: 'Image / logo…', fn: function () { pickImage(1600, function (src, w, h) { var asp = h / w, ww = 40, hh = ww * (PW / PH) * asp; if (hh > 60) { hh = 60; ww = hh / (PW / PH) / asp; } add({ k: 'img', n: 'Image', x: rnd(50 - ww / 2), y: rnd(Math.max(2, 40 - hh / 2)), w: rnd(ww), h: rnd(hh), src: src, fit: 'contain' }); }); } },
      { l: 'Background image…', fn: function () { pickImage(2000, function (src) { d.cl.bg.img = src; d.cl.bg.fit = d.cl.bg.fit || 'cover'; draw(); snap(); }); } },
      { hr: 1 }, { hd: 'Borders & shapes' },
      { l: 'Border frame', fn: function () { add({ k: 'rect', n: 'Frame', x: 6, y: 4.2, w: 88, h: 91.6, fill: '', bw: 1.4, bc: ac }); } },
      { l: 'Double border', fn: function () { add({ k: 'rect', n: 'Double frame', x: 5.5, y: 4, w: 89, h: 92, fill: '', bw: 4.5, bs: 'double', bc: ac }); } },
      { l: 'Rectangle', fn: function () { add({ k: 'rect', n: 'Rectangle', x: 25, y: 35, w: 50, h: 18, fill: ac }); } },
      { l: 'Rounded box', fn: function () { add({ k: 'rect', n: 'Rounded box', x: 25, y: 35, w: 50, h: 18, fill: ac, rad: 6 }); } },
      { l: 'Circle', fn: function () { add({ k: 'ellipse', n: 'Circle', x: 30, y: 30, w: 40, h: 28.3, fill: ac }); } },
      { l: 'Horizontal line', fn: function () { add({ k: 'rect', n: 'Line', x: 25, y: 50, w: 50, h: .2, fill: ac }); } },
      { l: 'Vertical line', fn: function () { add({ k: 'rect', n: 'Line', x: 50, y: 30, w: .3, h: 30, fill: ac }); } },
      { l: 'Colour wash (soft glow)', fn: function () { add({ k: 'ellipse', n: 'Glow', x: 15, y: 20, w: 70, h: 45, fill: ac, op: .3, bl: 24 }); } }
    ]);
  }

  /* ---------------------------------------------------------------- Layers dialog */
  function layersDlg() {
    endEdit(); var box = el('div', 'cly'), dd;
    function paint() {
      box.innerHTML = ''; var items = d.cl.items.slice().reverse();
      if (!items.length) box.appendChild(el('p', '', 'The cover is empty. Use Add to put something on it.'));
      items.forEach(function (it) {
        var r = el('div', 'clr' + (it.id === sel ? ' cur' : '') + (it.hide ? ' off' : '')), nm = it.k === 'text' ? ((CV.textOf(d, it) || '').split('\n')[0].slice(0, 30)) : '';
        var h = el('div', 'clh', '<b>' + esc(it.n || it.k) + '</b><small>' + esc(nm ? '“' + nm + '”' : it.k === 'img' ? 'Picture' : it.k === 'ellipse' ? 'Circle' : it.k === 'rect' ? 'Shape' : '') + '</small>'); h.onclick = function () { select(it.id); paint(); };
        var a = el('div', 'cseg');
        a.appendChild(pill('Up', function () { order(it, 'up'); paint(); }, 'sm')); a.appendChild(pill('Down', function () { order(it, 'down'); paint(); }, 'sm'));
        a.appendChild(pill(it.hide ? 'Show' : 'Hide', function () { setP(it, { hide: it.hide ? 0 : 1 }); draw(); paint(); }, 'sm')); a.appendChild(pill(it.lock ? 'Unlock' : 'Lock', function () { setP(it, { lock: it.lock ? 0 : 1 }); paint(); }, 'sm'));
        a.appendChild(pill('Delete', function () { del(it); paint(); }, 'sm danger')); r.appendChild(h); r.appendChild(a); box.appendChild(r);
      });
    }
    paint(); dd = A.dlg('Layers', box, [{ l: 'Close', cls: 'pri' }], { nofocus: true });
  }

  /* ---------------------------------------------------------------- Templates dialog */
  var tpl = { acc: '', lbl: '' };
  function templatesDlg() {
    endEdit(); var box = el('div', 'ctp'), dd, D = CV.dim(d);
    tpl.acc = tpl.acc || (d.cvo || {}).acc || ''; tpl.lbl = tpl.lbl || ((d.cvo || {}).lbl || '');
    function opts() { return { acc: tpl.acc || '', lbl: tpl.lbl || '', sz: 1 }; }
    function paint() {
      box.innerHTML = ''; box.appendChild(el('div', 'chd', 'Accent colour'));
      var sw = el('div', 'csw'); box.appendChild(sw);
      var none = el('button', 'btn sm' + (!tpl.acc ? ' on' : ''), 'Text colour'); none.type = 'button'; none.onclick = function () { tpl.acc = ''; paint(); }; sw.appendChild(none);
      CV.SWATCHES.forEach(function (c) { var s = el('button', 'sw' + (tpl.acc === c ? ' on' : '')); s.type = 'button'; s.style.background = c; s.onclick = function () { tpl.acc = c; paint(); }; sw.appendChild(s); });
      var ci = el('input'); ci.type = 'color'; ci.className = 'swc'; ci.value = tpl.acc || '#1f3a5f'; ci.onchange = function () { tpl.acc = ci.value; paint(); }; sw.appendChild(ci);
      seg(box, 'Name labels', [['', 'Automatic'], ['by', 'Written by'], ['plain', 'Writer :']], function () { return tpl.lbl; }, function (v) { tpl.lbl = v; paint(); });
      box.appendChild(el('div', 'chd', 'Designs – tap one to use it'));
      var g = el('div', 'cgr'); box.appendChild(g);
      CV.STYLES.forEach(function (s) {
        var c = el('button', 'cth'); c.type = 'button'; var td = Object.assign({}, d, { cl: CV.template(d, s[0], opts()) }), W = 84, k = W / PW;
        var tn = el('div', 'cthp'); tn.style.cssText = 'width:' + W + 'px;height:' + (PH * k) + 'px'; var inner = el('div', 'cvpg'); inner.style.cssText = 'width:' + PW + 'px;height:' + PH + 'px;transform:scale(' + k + ');transform-origin:0 0'; inner.innerHTML = CV.pageHtml(td, false); tn.appendChild(inner); c.appendChild(tn); c.appendChild(el('span', '', esc(s[1])));
        c.onclick = function () {
          var go = function () { var cl = CV.template(d, s[0], opts()); d.cl = cl; d.cv = s[0]; d.cvo = Object.assign({}, d.cvo || {}, { acc: tpl.acc || undefined, lbl: tpl.lbl || undefined }); Object.keys(d.cvo).forEach(function (k) { if (d.cvo[k] == null) delete d.cvo[k]; }); sel = null; draw(); tools(); snap(); dd.close(); A.toast(s[1] + ' design applied'); };
          if (hist.length > 1) A.confirmD('Use the ' + s[1] + ' design?', 'This replaces everything on the cover with the new design. You can undo it.', go, 'Use design'); else go();
        };
        g.appendChild(c);
      });
    }
    paint(); dd = A.dlg('Cover designs', box, [{ l: 'Close', cls: 'pri' }], { nofocus: true }); dd.classList.add('wide');
  }

  /* ---------------------------------------------------------------- Page dialog (size + background) */
  function pageDlg() {
    endEdit(); var box = el('div', 'cpg'), dd;
    function paint() {
      box.innerHTML = ''; var bg = d.cl.bg;
      box.appendChild(el('div', 'chd', 'Page size')); var pr = el('div', 'cseg'); box.appendChild(pr);
      PAPERS.forEach(function (p) { var b = el('button', 'btn sm' + (d.paper === p[0] ? ' on' : ''), esc(p[1])); b.type = 'button'; b.onclick = function () { setSize(p[0]); paint(); }; pr.appendChild(b); });
      if (d.paper === 'custom') {
        var cr = el('div', 'cseg'), w = el('input', 'cnum'), h = el('input', 'cnum'); w.type = h.type = 'number'; w.value = d.pw || 210; h.value = d.ph || 297; w.min = 60; w.max = 600; h.min = 80; h.max = 900;
        var ap = function () { d.pw = clamp(+w.value || 210, 60, 600); d.ph = clamp(+h.value || 297, 80, 900); layout(); draw(); fitMode && fitPage(); snap(); };
        w.onchange = h.onchange = ap; cr.appendChild(w); cr.appendChild(el('span', '', '×')); cr.appendChild(h); cr.appendChild(el('span', '', 'mm')); box.appendChild(cr);
      }
      box.appendChild(el('div', 'cnote', 'The page size is the size of your printed script. ' + esc(THK.paperOf(d).n) + ': ' + Math.round(CV.dim(d).w) + ' × ' + Math.round(CV.dim(d).h) + ' mm.'));
      box.appendChild(el('div', 'chd', 'Background colour')); colorBox(box, bg.c || d.pageColor || '#ffffff', function (c, f) { bg.c = c; draw(); if (f) snap(); });
      box.appendChild(el('div', 'chd', 'Background picture')); var ir = el('div', 'cseg'); box.appendChild(ir);
      ir.appendChild(pill(bg.img ? 'Change picture' : 'Choose picture', function () { pickImage(2000, function (src) { bg.img = src; bg.fit = bg.fit || 'cover'; draw(); snap(); paint(); }); }, 'pri sm'));
      if (bg.img) {
        ir.appendChild(pill('Remove', function () { delete bg.img; draw(); snap(); paint(); }, 'sm danger'));
        seg(box, 'Picture fit', [['cover', 'Fill page'], ['contain', 'Fit inside'], ['fill', 'Stretch'], ['tile', 'Tile']], function () { return bg.fit || 'cover'; }, function (v) { bg.fit = v; draw(); snap(); });
        rng(box, 'Picture opacity', 0.05, 1, 0.05, bg.op == null ? 1 : bg.op, function (v, f) { bg.op = v >= 1 ? undefined : v; draw(); if (f) snap(); }, function (v) { return Math.round(v * 100) + '%'; });
        rng(box, 'Blur', 0, 20, 1, bg.bl || 0, function (v, f) { bg.bl = v || undefined; draw(); if (f) snap(); }, function (v) { return v + ' mm'; });
        rng(box, 'Shift picture ↔', 0, 100, 1, bg.fx == null ? 50 : bg.fx, function (v, f) { bg.fx = v; draw(); if (f) snap(); }, function (v) { return v + '%'; });
        rng(box, 'Shift picture ↕', 0, 100, 1, bg.fy == null ? 50 : bg.fy, function (v, f) { bg.fy = v; draw(); if (f) snap(); }, function (v) { return v + '%'; });
        box.appendChild(el('div', 'chd', 'Tint over the picture (makes text easier to read)'));
        seg(box, '', [['', 'None'], ['#000000', 'Dark'], ['#ffffff', 'Light']], function () { return bg.ov || ''; }, function (v) { bg.ov = v || undefined; if (v && !bg.ova) bg.ova = .35; draw(); snap(); paint(); });
        if (bg.ov) rng(box, 'Tint strength', 0.05, 0.95, 0.05, bg.ova || .35, function (v, f) { bg.ova = v; draw(); if (f) snap(); }, function (v) { return Math.round(v * 100) + '%'; });
      }
    }
    function setSize(id) { d.paper = id; if (id === 'custom') { d.pw = d.pw || 210; d.ph = d.ph || 297; } layout(); draw(); if (fitMode) fitPage(); snap(); }
    paint(); dd = A.dlg('Page', box, [{ l: 'Done', cls: 'pri' }], { nofocus: true }); dd.classList.add('wide');
  }

  /* ---------------------------------------------------------------- preview without any tools */
  function enterPreview() {
    endEdit(); preview = true; sel = null; document.documentElement.classList.add('cvpv'); draw(); applyZ(); setTimeout(fitPage, 30);
    var h = $('#cvHint'); if (!h) { h = el('div', 'cexit', 'Tap anywhere to leave preview'); h.id = 'cvHint'; $('#cvEd').appendChild(h); } h.classList.add('show'); clearTimeout(exitT); exitT = setTimeout(function () { h.classList.remove('show'); }, 2200);
  }
  function exitPreview() { preview = false; document.documentElement.classList.remove('cvpv'); var h = $('#cvHint'); if (h) h.classList.remove('show'); draw(); tools(); applyZ(); setTimeout(function () { fitMode ? fitPage() : 0; }, 30); }

  /* ---------------------------------------------------------------- look */
  var CSS =
    '#cvEd{padding:0;display:flex;flex-direction:column;overflow:hidden}' +
    '#cTop{margin:max(8px,env(safe-area-inset-top)) 8px 0;border-radius:26px;padding:6px 8px;display:flex;flex-direction:column;align-items:stretch;gap:6px;z-index:5;min-width:0}' +
    '#cTop .crow{min-width:0;width:100%;display:flex;gap:6px;align-items:center;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;touch-action:pan-x;padding:1px 0}#cTop .crow::-webkit-scrollbar{display:none}' +
    '#cTop .crow .btn{flex:0 0 auto;min-height:36px;padding:6px 14px;font-size:14px}#cTop .btn.dis{opacity:.4;pointer-events:none}' +
    '#cTop #cR2{border-top:1px solid var(--edge);padding-top:6px;min-height:46px}#cTop .chint{font-size:12.5px;color:var(--ink2);padding:0 8px;white-space:nowrap}' +
    '#cAcc{margin:0 8px max(8px,env(safe-area-inset-bottom));border-radius:26px;padding:6px;display:flex;gap:6px;align-items:center;z-index:5}#cAcc .btn{flex:1 1 0}' +
    '#cvView{flex:1;min-height:0;overflow:auto;display:flex;touch-action:none;overscroll-behavior:contain;margin:6px 0;-webkit-overflow-scrolling:touch;user-select:none;-webkit-user-select:none}' +
    '#cvStage{position:relative;margin:auto;flex:0 0 auto}' +
    '#cvPage{position:absolute;transform-origin:0 0;--z:1}#cvPage #cvc{box-shadow:0 10px 40px rgba(0,0,0,.28),0 0 0 1px rgba(128,128,128,.28);border-radius:1px}' +
    '#cvc.edit .cvi{cursor:move}#cvc.edit .cvi.lk{cursor:default}#cvc.edit .cvt:empty::before{content:attr(data-ph);opacity:.35;pointer-events:none}#cvc .cvt.editing{outline:none;cursor:text;user-select:text;-webkit-user-select:text;caret-color:#e5484d;touch-action:auto;-webkit-user-modify:read-write-plaintext-only}' +
    '#cvo{position:absolute;inset:0;pointer-events:none}.csel{position:absolute;outline:calc(1.6px / var(--z)) solid #5e6cf2;box-shadow:0 0 0 calc(3px / var(--z)) rgba(255,255,255,.55),0 0 0 calc(4px / var(--z)) rgba(94,108,242,.25);pointer-events:none}' +
    '.csel .hd{position:absolute;width:calc(20px / var(--z));height:calc(20px / var(--z));margin:calc(-10px / var(--z)) 0 0 calc(-10px / var(--z));background:#fff;border:calc(2px / var(--z)) solid #5e6cf2;border-radius:50%;pointer-events:auto;touch-action:none;box-shadow:0 1px 4px rgba(0,0,0,.3)}' +
    '.csel .hd::after{content:"";position:absolute;inset:calc(-12px / var(--z))}.csel .hr::after{content:"";position:absolute;inset:calc(-14px / var(--z))}' +
    '.hd.h-nw{left:0;top:0}.hd.h-n{left:50%;top:0}.hd.h-ne{left:100%;top:0}.hd.h-e{left:100%;top:50%}.hd.h-se{left:100%;top:100%}.hd.h-s{left:50%;top:100%}.hd.h-sw{left:0;top:100%}.hd.h-w{left:0;top:50%}' +
    '.csel .hr{position:absolute;left:50%;top:calc(-34px / var(--z));width:calc(19px / var(--z));height:calc(19px / var(--z));margin-left:calc(-9.5px / var(--z));background:#5e6cf2;border:calc(2px / var(--z)) solid #fff;border-radius:50%;pointer-events:auto;touch-action:none;box-shadow:0 1px 4px rgba(0,0,0,.3)}' +
    '.csel .hr::after{content:"";position:absolute;inset:calc(-12px / var(--z))}.csel .hr::before{content:"";position:absolute;left:50%;top:100%;width:calc(1.6px / var(--z));height:calc(15px / var(--z));background:#5e6cf2;margin-left:calc(-.8px / var(--z))}' +
    '.cg{position:absolute;background:#ff3b8d;opacity:.85}.cg.gv{top:0;bottom:0;width:calc(1.2px / var(--z))}.cg.gh{left:0;right:0;height:calc(1.2px / var(--z))}' +
    '.cvpv #cTop,.cvpv #cAcc{display:none}.cvpv #cvView{margin:0;background:rgba(0,0,0,.0)}.cexit{position:fixed;left:50%;bottom:max(22px,env(safe-area-inset-bottom));transform:translateX(-50%);padding:9px 18px;border-radius:999px;background:rgba(20,20,26,.72);color:#fff;font-size:13px;opacity:0;pointer-events:none;transition:opacity .35s;z-index:9;backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px)}.cexit.show{opacity:1}' +
    '.menu.cpm{padding:10px 12px;min-width:250px;max-width:min(92vw,360px);max-height:68vh;overflow:auto}.cpm .chd,.cpg .chd,.ctp .chd{font-size:11px;text-transform:uppercase;letter-spacing:.6px;color:var(--ink2);font-weight:600;margin:10px 2px 6px}' +
    '.menu.cpm .btn{display:inline-flex;width:auto;justify-content:center;align-items:center;text-align:center;padding:7px 13px;font-size:13.5px;border-radius:999px;min-height:34px}.menu.cpm .btn:not(.on):not(.pri){background:var(--glass);border:1px solid var(--edge);color:var(--ink)}.menu.cpm .btn.pri{color:#fff}' +
    '.cpm.wide{min-width:min(92vw,330px)}.cpm .cfl{display:flex;flex-wrap:wrap;gap:6px}.cpm .cfl .chd{flex:0 0 100%}.cfont{font-size:15px!important;white-space:nowrap}' +
    '.cseg{display:flex;flex-wrap:wrap;gap:6px;align-items:center}.cseg .btn{padding:7px 13px}.cnum{width:78px;padding:8px 10px;border-radius:14px;border:1px solid var(--edge);background:var(--glass2);color:var(--ink);font:inherit;text-align:center}' +
    '.crg{display:grid;grid-template-columns:86px 1fr 56px;align-items:center;gap:8px;margin:8px 0;font-size:13px}.crg b{font-weight:600;text-align:right;font-size:12px}.crg input[type=range]{width:100%;accent-color:#5e6cf2}' +
    '.csw{display:flex;flex-wrap:wrap;gap:7px;align-items:center}.csw .sw{width:30px;height:30px;border-radius:50%;border:2px solid var(--edge);padding:0;cursor:pointer;flex:0 0 30px}.csw .sw.on{outline:3px solid #5e6cf2;outline-offset:2px}.csw .swc{width:38px;height:30px;border:0;padding:0;background:none}' +
    '.cpg,.ctp,.cly{display:flex;flex-direction:column;gap:4px;max-height:64vh;overflow:auto;padding-right:2px}.cnote{font-size:12px;color:var(--ink2);margin-top:4px}' +
    '.cgr{display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:10px}.cth{display:flex;flex-direction:column;align-items:center;gap:6px;border:1px solid var(--edge);background:var(--glass2);border-radius:18px;padding:8px 6px 7px;cursor:pointer;color:var(--ink);font:inherit;font-size:12.5px}.cth:active{transform:scale(.97)}.cthp{overflow:hidden;border-radius:3px;box-shadow:0 2px 8px rgba(0,0,0,.25);pointer-events:none}.cthp .cvpg{pointer-events:none}' +
    '.clr{border:1px solid var(--edge);border-radius:18px;padding:8px 10px;background:var(--glass2);display:flex;flex-direction:column;gap:6px}.clr.cur{outline:2px solid #5e6cf2}.clr.off{opacity:.55}.clh{display:flex;flex-direction:column;cursor:pointer}.clh small{color:var(--ink2);font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}';
  window.addEventListener('pagehide', function () { });
  E.cur = function () { return d; };
  THK.x.coverDlg = E.open; if (THK.pro) THK.pro.coverDlg = E.open;
})();
