/* Network helper for Google's free translate service. On Android the request goes through Capacitor's native HTTP (no browser CORS rules,
   works the same as any normal app); on the web / desktop it uses fetch. It never trusts navigator.onLine (some phones report "offline" while connected). */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, N = THK.net = {};
  var BASE = 'https://translate.googleapis.com/translate_a/single';
  function nativeHttp() { try { var c = window.Capacitor; if (c && c.isNativePlatform && c.isNativePlatform() && c.Plugins && c.Plugins.CapacitorHttp) return c.Plugins.CapacitorHttp; } catch (e) { } return null; }
  function parse(d) { if (typeof d === 'string') { try { return JSON.parse(d); } catch (e) { throw new Error('Google sent an unreadable answer'); } } return d; }
  var HOSTS = [['https://translate.googleapis.com/translate_a/single', 'gtx'], ['https://translate.google.com/translate_a/single', 'gtx'], ['https://clients5.google.com/translate_a/single', 'dict-chrome-ex']];
  var lastAt = 0, chain = Promise.resolve(), GAP = 450, hostI = 0;
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function httpErr(st) { var e = new Error('Google answered ' + st); e.status = st; return e; }
  function once(o, host) {
    var dts = (o.dt || ['t']).map(function (x) { return 'dt=' + x; }).join('&'), qs = 'client=' + host[1] + '&dj=0&' + dts, sl = o.sl || 'auto', tl = o.tl || 'en', H = nativeHttp();
    if (H) {
      return H.request({ url: host[0] + '?' + qs, method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Accept': '*/*', 'User-Agent': 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36' }, data: { sl: sl, tl: tl, q: o.q }, responseType: 'json', connectTimeout: 15000, readTimeout: 25000 })
        .then(function (r) { if (!r || r.status !== 200) throw httpErr(r && r.status); return parse(r.data); });
    }
    var body = qs + '&sl=' + encodeURIComponent(sl) + '&tl=' + encodeURIComponent(tl) + '&q=' + encodeURIComponent(o.q);
    return fetch(host[0], { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' }, body: body }).then(function (r) { if (!r.ok) throw httpErr(r.status); return r.json(); }, function (e) {
      if (o.q.length > 1500) throw e;
      return fetch(host[0] + '?' + body).then(function (r) { if (!r.ok) throw httpErr(r.status); return r.json(); });
    });
  }
  /* One request at a time with a short gap (Google answers 429 when asked too fast); on 429/5xx wait, switch to another Google address and try again. */
  function run(o) {
    var tries = 0;
    function go() {
      var wait = Math.max(0, lastAt + GAP - Date.now());
      return sleep(wait).then(function () { lastAt = Date.now(); return once(o, HOSTS[hostI % HOSTS.length]); }).catch(function (e) {
        var st = e && e.status, soft = !st || st === 429 || st >= 500 || st === 403;
        if (!soft || ++tries > 2) throw e;
        hostI++; var back = st === 429 ? Math.min(8000, 1200 * tries) : 800 * tries; GAP = Math.min(1500, GAP + 150);
        return sleep(back).then(go);
      });
    }
    return go();
  }
  /* Second service (the free one Microsoft Edge uses) – used when Google refuses (429 / blocked). Plain translation only. */
  var tok = null, tokAt = 0, gBad = 0;
  function fixLang(l) { return l === 'zh-Hans' ? 'zh-CN' : l === 'zh-Hant' ? 'zh-TW' : l; }
  function msToken() {
    if (tok && Date.now() - tokAt < 8 * 60000) return Promise.resolve(tok);
    var H = nativeHttp(), p = H ? H.request({ url: 'https://edge.microsoft.com/translate/auth', method: 'GET', responseType: 'text', connectTimeout: 15000, readTimeout: 20000 }).then(function (r) { if (!r || r.status !== 200) throw httpErr(r && r.status); return String(r.data); })
      : fetch('https://edge.microsoft.com/translate/auth').then(function (r) { if (!r.ok) throw httpErr(r.status); return r.text(); });
    return p.then(function (t) { tok = String(t).trim(); tokAt = Date.now(); return tok; });
  }
  function msTranslate(o) {
    var lines = String(o.q).split('\n'), body = JSON.stringify(lines.map(function (t) { return { Text: t }; }));
    return msToken().then(function (t) {
      var url = 'https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&to=' + encodeURIComponent(o.tl || 'en') + (o.sl && o.sl !== 'auto' ? '&from=' + encodeURIComponent(o.sl) : ''), H = nativeHttp(), hd = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + t };
      var req = H ? H.request({ url: url, method: 'POST', headers: hd, data: JSON.parse(body), responseType: 'json', connectTimeout: 15000, readTimeout: 30000 }).then(function (r) { if (!r || r.status !== 200) throw httpErr(r && r.status); return parse(r.data); })
        : fetch(url, { method: 'POST', headers: hd, body: body }).then(function (r) { if (!r.ok) throw httpErr(r.status); return r.json(); });
      return req;
    }).then(function (arr) {
      if (!Array.isArray(arr) || arr.length !== lines.length) throw new Error('unexpected answer');
      var out = arr.map(function (x) { return (x.translations && x.translations[0] && x.translations[0].text) || ''; }).join('\n');
      var sl = arr[0] && arr[0].detectedLanguage ? fixLang(arr[0].detectedLanguage.language) : (o.sl || 'auto');
      return [[[out, o.q]], null, sl];
    });
  }
  /* Extra free services (no key): Lingva (open Google front-ends, several mirrors) and MyMemory. Used when Google and Microsoft both refuse. */
  var LINGVA = ['https://lingva.ml', 'https://lingva.lunar.icu', 'https://translate.plausibility.cloud', 'https://lingva.garudalinux.org'];
  function getJSON(url) {
    var H = nativeHttp();
    if (H) return H.request({ url: url, method: 'GET', responseType: 'json', connectTimeout: 12000, readTimeout: 25000 }).then(function (r) { if (!r || r.status !== 200) throw httpErr(r && r.status); return parse(r.data); });
    return fetch(url).then(function (r) { if (!r.ok) throw httpErr(r.status); return r.json(); });
  }
  function lingva(line, o, i) {
    if (!line.trim()) return Promise.resolve('');
    var n = 0;
    function go() { var host = LINGVA[(i + n) % LINGVA.length]; return getJSON(host + '/api/v1/' + encodeURIComponent(o.sl || 'auto') + '/' + encodeURIComponent(o.tl || 'en') + '/' + encodeURIComponent(line)).then(function (j) { if (!j || typeof j.translation !== 'string') throw new Error('bad answer'); return j.translation; }).catch(function (e) { if (++n >= LINGVA.length) throw e; return go(); }); }
    return go();
  }
  function myMemory(line, o) {
    if (!line.trim()) return Promise.resolve('');
    var parts = line.match(/[\s\S]{1,450}(?:\s|$)/g) || [line];
    return parts.reduce(function (p, part) { return p.then(function (acc) {
      return getJSON('https://api.mymemory.translated.net/get?q=' + encodeURIComponent(part) + '&langpair=' + encodeURIComponent((o.sl && o.sl !== 'auto' ? o.sl : 'Autodetect') + '|' + (o.tl || 'en'))).then(function (j) { var t = j && j.responseData && j.responseData.translatedText; if (typeof t !== 'string' || !t || /MYMEMORY WARNING|INVALID/i.test(t)) throw new Error('MyMemory refused'); return acc + t; });
    }); }, Promise.resolve(''));
  }
  function altTranslate(o) {
    var lines = String(o.q).split('\n'), out = [];
    return lines.reduce(function (p, l, i) { return p.then(function () { return lingva(l, o, i).catch(function () { return myMemory(l, o); }).then(function (t) { out[i] = t; }); }); }, Promise.resolve())
      .then(function () { return [[[out.join('\n'), o.q]], null, o.sl || 'auto']; });
  }
  /* o: { sl, tl, dt:['t','rm'], q } → parsed JSON (Google's shape). Order: Google → Microsoft → Lingva/MyMemory; a service that failed is skipped for 5 minutes. */
  var bad = { ms: 0, alt: 0 };
  N.gtx = function (o) {
    var plain = (o.dt || ['t']).every(function (x) { return x === 't'; });
    var p = chain.then(function () {
      if (!plain || Date.now() >= gBad) { return run(o).catch(function (e) { if (!plain) throw e; gBad = Date.now() + 2 * 60000; return fallback(e); }); }
      return fallback(null);
      function fallback(e0) {
        var errs = [e0 && e0.message ? 'Google: ' + e0.message : null];
        var st = e0 && e0.status;
        function tryMs() { if (Date.now() < bad.ms) return Promise.reject(new Error('skipped')); return msTranslate(o).catch(function (e) { bad.ms = Date.now() + 10 * 60000; errs.push('Microsoft: ' + e.message); throw e; }); }
        function tryAlt() { return altTranslate(o).catch(function (e) { errs.push('Free mirrors: ' + e.message); throw e; }); }
        return tryMs().catch(tryAlt).catch(function () { var er = new Error(errs.filter(Boolean).join(' · ') || 'failed'); er.status = st; throw er; });
      }
    });
    chain = p.catch(function () { }); return p;
  };
  N.explain = function (e) { return 'The translation services could not be reached (' + ((e && e.message) || 'network') + '). Check the connection and try again in a minute.'; };
})();
