/* Custom element types (Flashback, Voiceover, Subtitle, Playback song …).
   Stored on the script as d.ct = [{id,n,al,ind,col,up,b,i,u,c,pre,suf}] and used as block type  b.t = id.  */
(function () {
  'use strict';
  var A = THK.app, el = A.el, esc = A.esc, E = THK.el = {};
  var BASE = ['scene', 'action', 'char', 'paren', 'dial', 'trans', 'shot', 'note'];
  /* ready-made suggestions (one tap) */
  E.PRESETS = [
    { n: 'Flashback', al: 'left', ind: 0, col: 'f', up: 1, b: 1 },
    { n: 'Voiceover', al: 'left', ind: 16, col: 'r', i: 1 },
    { n: 'Subtitle', al: 'center', ind: 20, col: 'r', i: 1, pre: '[', suf: ']' },
    { n: 'Playback song', al: 'center', ind: 20, col: 'f', i: 1, pre: '♪ ', suf: ' ♪' },
    { n: 'Super', al: 'center', ind: 10, col: 'f', up: 1, b: 1 },
    { n: 'Insert', al: 'left', ind: 0, col: 'l', up: 1 },
    { n: 'Title card', al: 'center', ind: 10, col: 'f', up: 1, b: 1 }
  ];
  E.COLS = [['', 'Text'], ['soft', 'Soft'], ['#b4483a', '#b4483a'], ['#2f6f5e', '#2f6f5e'], ['#3a5ba9', '#3a5ba9'], ['#8a5a1f', '#8a5a1f'], ['#7a4a9a', '#7a4a9a']];
  var sig = '';

  E.clean = function (t) {
    if (!t || typeof t !== 'object' || !/^x[a-z0-9]{3,10}$/.test(t.id || '')) return null;
    return { id: t.id, n: String(t.n || 'Element').slice(0, 28), al: ['left', 'center', 'right'].indexOf(t.al) >= 0 ? t.al : 'left', ind: Math.max(0, Math.min(40, +t.ind || 0)), col: ['l', 'r', 'f'].indexOf(t.col) >= 0 ? t.col : 'f',
      up: t.up ? 1 : 0, b: t.b ? 1 : 0, i: t.i ? 1 : 0, u: t.u ? 1 : 0, c: /^(soft|#[0-9a-f]{6})$/i.test(t.c || '') ? t.c : '', pre: String(t.pre || '').slice(0, 8), suf: String(t.suf || '').slice(0, 8) };
  };
  E.list = function (d) { return (d && d.ct) || []; };
  E.get = function (d, id) { var l = E.list(d); for (var i = 0; i < l.length; i++) if (l[i].id === id) return l[i]; return null; };
  E.isCustom = function (id) { return BASE.indexOf(id) < 0; };
  E.newId = function (d) { var id; do { id = 'x' + Math.random().toString(36).slice(2, 7); } while (E.get(d, id)); return id; };

  function cssStr(s) { return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, ' ') + '"'; }
  function look(t) {
    var c = 'text-align:' + t.al + ';' + (t.up ? 'text-transform:uppercase;' : '') + (t.b ? 'font-weight:700;' : '') + (t.i ? 'font-style:italic;' : '') + (t.u ? 'text-decoration:underline;' : '');
    if (t.c === 'soft') c += 'opacity:.68;'; else if (t.c) c += 'color:' + t.c + ';';
    return c;
  }
  /* mode 'ed' = editor, 'pr' = print */
  E.css = function (d, mode) {
    var pr = mode === 'pr', out = '';
    E.list(d).forEach(function (t) {
      var k = (pr ? '.b.' : '#page .b.') + t.id, two = d.fmt === 'two', pg = pr ? '' : '#page', rl = (two ? '' : '') ;
      if (!two) out += (pr ? '' : '#page.std ') + '.b.' + t.id + '{margin-left:' + t.ind + '%;margin-right:' + t.ind + '%;' + look(t) + '}';
      else {
        var sc = pr ? '' : '#page.two ';
        out += sc + '.b.' + t.id + '{clear:both;' + look(t) + (t.col === 'l' ? 'width:' + (pr ? 46 : 47) + '%;text-align:left;' : t.col === 'r' ? 'clear:none;margin-left:calc(50% + ' + (pr ? '3mm' : '.8em') + ');margin-right:0;text-align:left;' : 'margin-left:' + Math.min(t.ind, 25) + '%;margin-right:' + Math.min(t.ind, 25) + '%;') + '}';
      }
      if (t.pre) out += (pr ? '' : '#page ') + '.b.' + t.id + (pr ? '::before' : ' .ed:not(:empty)::before') + '{content:' + cssStr(t.pre) + (pr ? '' : ';opacity:.8') + '}';
      if (t.suf) out += (pr ? '' : '#page ') + '.b.' + t.id + (pr ? '::after' : ' .ed:not(:empty)::after') + '{content:' + cssStr(t.suf) + (pr ? '' : ';opacity:.8') + '}';
    });
    return out;
  };
  /* register labels / placeholders and the editor style; rebuild the drop-down when the list changed */
  E.apply = function (d) {
    var LAB = A.LAB, PH = A.PH, NX = A.NEXT;
    Object.keys(LAB).forEach(function (k) { if (E.isCustom(k)) { delete LAB[k]; delete PH[k]; delete NX[k]; } });
    E.list(d).forEach(function (t) { LAB[t.id] = t.n; PH[t.id] = t.n + '…'; NX[t.id] = t.col === 'r' ? 'char' : 'action'; });
    var st = document.getElementById('cxcss'); if (!st) { st = document.createElement('style'); st.id = 'cxcss'; document.head.appendChild(st); }
    st.textContent = E.css(d, 'ed');
    var s = JSON.stringify(E.list(d).map(function (t) { return [t.id, t.n]; }));
    if (s !== sig) { sig = s; E.fillSel(d); }
  };
  E.fillSel = function (d) {
    var sel = document.getElementById('elsel'); if (!sel) return;
    var v = sel.value; sel.innerHTML = '';
    A.ORDER.concat(['shot', 'note']).concat(E.list(d || A.cur).map(function (t) { return t.id; })).forEach(function (t) { var o = el('option', '', esc(A.LAB[t])); o.value = t; sel.appendChild(o); });
    var o = el('option', '', '＋ Custom element…'); o.value = '__cx'; sel.appendChild(o);
    var cb = A.cb; sel.value = cb ? cb.t : v;
  };
  E.reset = function () { sig = ''; };

  /* ---------------------------------------------------------------- manager dialog */
  function pill(label, on, fn, cls) { var b = el('button', 'btn' + (on ? ' on' : '') + (cls ? ' ' + cls : ''), esc(A.clean(label))); b.type = 'button'; b.onclick = fn; return b; }
  function row(p) { var r = el('div', 'xrow'); p.appendChild(r); return r; }
  function head(p, t, sub) { p.appendChild(el('div', 'xhd', esc(t))); if (sub) p.appendChild(el('div', 'xsub', esc(sub))); }

  E.manage = function (editId) {
    var d = A.cur; if (!d) return; d.ct = d.ct || [];
    var body = el('div', 'cxm'), draft = null, dlgRef = null;
    function sample(t) {
      var s = el('div', 'cxs'), p = el('div', 'cxsp'); s.style.background = d.pageColor || '#fff'; s.style.color = d.textColor || '#111'; p.style.cssText = look(t) + 'padding:6px ' + Math.min(t.ind, 30) + '%;';
      p.textContent = (t.pre || '') + 'Sample text' + (t.suf || ''); s.appendChild(p); return s;
    }
    function list() {
      body.innerHTML = '';
      head(body, 'Your custom elements', d.ct.length ? 'They appear in the Elements drop-down at the top.' : 'None yet. Add one below, or tap a suggestion.');
      d.ct.forEach(function (t) {
        var r = el('div', 'cxr'); r.appendChild(el('b', '', esc(t.n)));
        var e1 = pill('Edit', false, function () { form(JSON.parse(JSON.stringify(t)), false); }), e2 = pill('Delete', false, function () { del(t); }, 'danger'); r.appendChild(e1); r.appendChild(e2); body.appendChild(r);
      });
      head(body, 'Add', 'Tap a suggestion or make your own');
      var r2 = row(body);
      E.PRESETS.forEach(function (p) { if (d.ct.some(function (t) { return t.n.toLowerCase() === p.n.toLowerCase(); })) return; r2.appendChild(pill(p.n, false, function () { form(Object.assign({ id: E.newId(d) }, p), true); })); });
      r2.appendChild(pill('New…', false, function () { form({ id: E.newId(d), n: '', al: 'left', ind: 0, col: 'f' }, true); }, 'pri'));
    }
    function del(t) {
      var n = d.blocks.filter(function (b) { return b.t === t.id; }).length;
      A.confirmD('Delete “' + t.n + '”?', n ? n + ' line' + (n > 1 ? 's' : '') + ' using it will turn into Action.' : 'This element will be removed.', function () {
        A.snap(); d.blocks.forEach(function (b) { if (b.t === t.id) b.t = 'action'; }); d.ct = d.ct.filter(function (x) { return x.id !== t.id; });
        A.renderAll(); E.apply(d); A.snap(); A.dirty(); list();
      }, 'Delete');
    }
    function form(t, isNew) {
      body.innerHTML = ''; draft = t;
      head(body, isNew ? 'New element' : 'Edit element');
      var nm = el('input', 'xin'); nm.placeholder = 'Name, e.g. Flashback'; nm.value = t.n || ''; nm.maxLength = 28; nm.oninput = function () { t.n = nm.value; }; body.appendChild(nm);
      var sm = el('div', ''); body.appendChild(sm);
      function paint() { sm.innerHTML = ''; sm.appendChild(sample(E.clean(Object.assign({}, t, { n: t.n || 'x', id: t.id })) || t)); }
      function seg(label, items, get, set, sub) { head(body, label, sub); var r = row(body); items.forEach(function (it) { var b = pill(it[1], get() === it[0], function () { set(it[0]); [].forEach.call(r.children, function (c) { c.classList.remove('on'); }); b.classList.add('on'); paint(); }); r.appendChild(b); }); }
      seg('Alignment', [['left', 'Left'], ['center', 'Centre'], ['right', 'Right']], function () { return t.al; }, function (v) { t.al = v; });
      seg('Margins', [[0, 'Full width'], [10, 'Wide'], [16, 'Dialogue'], [22, 'Narrow'], [30, 'Very narrow']], function () { return +t.ind || 0; }, function (v) { t.ind = v; }, 'Space left and right of the text');
      head(body, 'Style'); var sr = row(body);
      [['up', 'CAPITALS'], ['b', 'Bold'], ['i', 'Italic'], ['u', 'Underline']].forEach(function (k) { var b = pill(k[1], !!t[k[0]], function () { t[k[0]] = t[k[0]] ? 0 : 1; b.classList.toggle('on', !!t[k[0]]); paint(); }); sr.appendChild(b); });
      head(body, 'Colour', 'Text follows your page colour; Soft is a lighter tone of it'); var cr = el('div', 'cvsw'); body.appendChild(cr);
      E.COLS.forEach(function (c) {
        var s = el('button', 'sw' + (c[0] === '' || c[0] === 'soft' ? ' auto' : '') + ((t.c || '') === c[0] ? ' on' : ''), c[0] === '' || c[0] === 'soft' ? c[1] : ''); if (c[0] && c[0] !== 'soft') s.style.background = c[0]; s.type = 'button';
        s.onclick = function () { t.c = c[0]; [].forEach.call(cr.children, function (x) { x.classList.remove('on'); }); s.classList.add('on'); paint(); }; cr.appendChild(s);
      });
      head(body, 'Text around each line', 'Optional, e.g. ♪ before and after a song, or [ ] around subtitles');
      var pr = el('div', 'xrow2'); body.appendChild(pr);
      var a = el('input', 'xin'); a.placeholder = 'Before'; a.value = t.pre || ''; a.maxLength = 8; a.oninput = function () { t.pre = a.value; paint(); };
      var z = el('input', 'xin'); z.placeholder = 'After'; z.value = t.suf || ''; z.maxLength = 8; z.oninput = function () { t.suf = z.value; paint(); }; pr.appendChild(a); pr.appendChild(z);
      seg('Two-column layout', [['l', 'Left column'], ['r', 'Right column'], ['f', 'Full width']], function () { return t.col || 'f'; }, function (v) { t.col = v; }, 'Where it goes when the script uses two columns');
      head(body, 'Preview'); paint();
      var ac = row(body); ac.classList.add('cxa');
      ac.appendChild(pill('Back', false, function () { list(); }));
      ac.appendChild(pill(isNew ? 'Add element' : 'Save', true, function () {
        var c = E.clean(Object.assign({}, t, { n: (t.n || '').trim() })); if (!c || !c.n) { A.toast('Give the element a name'); return; }
        if (d.ct.some(function (x) { return x.id !== c.id && x.n.toLowerCase() === c.n.toLowerCase(); }) || ['scene heading', 'action', 'character', 'parenthetical', 'dialogue', 'transition', 'shot', 'note'].indexOf(c.n.toLowerCase()) >= 0) { A.toast('That name is already used'); return; }
        A.snap(); var i = -1; d.ct.forEach(function (x, j) { if (x.id === c.id) i = j; }); if (i < 0) d.ct.push(c); else d.ct[i] = c;
        E.apply(d); A.renderAll(); A.snap(); A.dirty();
        var cb = A.cb; if (isNew && cb && A.cur.blocks.indexOf(cb) >= 0) A.setType(cb, c.id); else if (A.cb) E.fillSel(d);
        A.toast(isNew ? '“' + c.n + '” added' : 'Saved'); if (dlgRef) dlgRef.close();
      }, 'pri'));
    }
    dlgRef = A.dlg('Custom elements', body, [{ l: 'Close' }], { nofocus: true });
    var t0 = editId && E.get(d, editId); if (t0) form(JSON.parse(JSON.stringify(t0)), false); else list();
  };

  /* print / export helpers used by export.js and extras.js */
  E.docx = function (d, b) { /* → { jc, ind (twips fraction of width), pre, suf, up, bold, italic, u } */
    var t = E.get(d, b.t); return t ? { jc: t.al === 'center' ? 'center' : t.al === 'right' ? 'right' : 'left', ind: t.ind, pre: t.pre, suf: t.suf, up: t.up, b: t.b, i: t.i, u: t.u } : null;
  };

  var st = document.createElement('style');
  st.textContent = '.cxm{display:flex;flex-direction:column;gap:6px}.cxr{display:flex;align-items:center;gap:8px;padding:6px 4px}.cxr b{flex:1;font-weight:600}.cxr .btn{padding:6px 14px}' +
    '.cxs{border-radius:18px;border:1px solid var(--edge);background:var(--pagec,#fff);color:var(--textc,#111);padding:10px 8px;margin:4px 0;font-family:var(--font,inherit)}.cxsp{white-space:pre-wrap}' +
    '.xrow2{display:flex;gap:8px}.xrow2 .xin{flex:1;min-width:0}.cxa{justify-content:flex-end;margin-top:6px}';
  document.head.appendChild(st);
})();

/* ------------------------------------------------------------------ transition picker */
(function () {
  'use strict';
  var A = THK.app, el = A.el, esc = A.esc, E = THK.el;
  /* Industry style: "… TO:" transitions take a colon; closing ones (fade out, end montage …) take a full stop. */
  E.TRANS = ['CUT TO:', 'MATCH CUT TO:', 'JUMP CUT TO:', 'DISSOLVE TO:', 'SLOW DISSOLVE TO:', 'CROSS DISSOLVE TO:', 'FADE IN:', 'FADE OUT.', 'FADE TO BLACK.', 'FADE TO WHITE.', 'FADE TO:',
    'FLASHBACK TO:', 'END FLASHBACK.', 'MONTAGE:', 'END MONTAGE.', 'LATER:', 'BACK TO:', 'INTERCUT WITH:', 'TIME CUT TO:', 'ZOOM TO:', 'FREEZE FRAME:', 'SPLIT SCREEN TO:',
    'DREAM SEQUENCE:', 'BACK TO REALITY:', 'FLASH FORWARD TO:', 'J-CUT:', 'L-CUT:', 'MUSIC BRIDGE TO:', 'TITLE CARD:'];
  E.transPanel = function (anchor) {
    var cb = A.cb, curT = cb && cb.t === 'trans' ? (cb.x || '').trim() : '';
    A.pop(anchor, function (m, close) {
      m.classList.add('trm'); m.appendChild(el('div', 'hd', 'Transition'));
      var l = el('div', 'trl'); m.appendChild(l);
      E.TRANS.forEach(function (t, i) {
        var b = el('button', 'trb' + (t === curT ? ' sel' : ''), '<span>' + esc(t) + '</span>'); b.type = 'button'; b.style.setProperty('--i', Math.min(i, 9));
        b.onmousedown = function (e) { e.preventDefault(); }; b.onclick = function () { close(); A.applyTrans(t); }; l.appendChild(b);
      });
      var c = el('button', 'trb trc', '<span>Custom…</span>'); c.type = 'button'; c.onmousedown = function (e) { e.preventDefault(); }; c.onclick = function () { close(); A.applyTrans(null); }; m.appendChild(c);
      var s = l.querySelector('.sel'); if (s) setTimeout(function () { l.scrollTop = Math.max(0, s.offsetTop - 80); }, 0);
    }, { cls: 'trm' });
  };
  var st = document.createElement('style');
  st.textContent = '.menu.trm{display:flex;flex-direction:column;overflow:hidden;min-width:248px;padding:8px 8px 8px}' +
    '.trm .trl{overflow-y:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;touch-action:pan-y;max-height:calc(8 * 42px);scrollbar-width:thin;margin:0 -2px;padding:0 2px}' +
    '.trm .trb{display:flex;width:100%;height:42px;flex:0 0 42px;align-items:center;border:0;background:none;color:var(--ink);padding:0 16px;border-radius:999px;font:inherit;font-size:15px;letter-spacing:.02em;cursor:pointer;text-align:left;animation:mit .3s both;animation-delay:calc(var(--i,0) * 22ms + 50ms)}' +
    '.trm .trb:hover{background:rgba(120,140,220,.16)}.trm .trb:active{transform:scale(.97)}' +
    '.trm .trb.sel{background:linear-gradient(100deg,rgba(94,108,242,.26),rgba(242,123,200,.22));color:var(--acc);font-weight:700;box-shadow:inset 0 0 0 1px rgba(94,108,242,.28)}' +
    '.trm .trc{margin-top:6px;justify-content:center;font-weight:700;border:1px solid var(--edge);background:var(--glass)}' +
    '.trm .hd{padding:6px 16px 6px}';
  document.head.appendChild(st);
})();
