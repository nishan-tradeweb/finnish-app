/* finnish – material upgrade for the dynamic themes (everything except Matte White / Matte Black).
   Each theme keeps the sculpted construction (raised cards, pressed wells) but gets its own MATERIAL (real texture drawn with SVG light & noise),
   SHAPE language (radius, stitching, rivets, rims) and TYPE feel. It only edits the generated tokens + adds a little scoped css, so it follows
   every component the same way the base themes do. Loaded after themes.js and before the theme picker reads the list. */
(function () {
  'use strict';
  var TH = window.THK && THK.themes; if (!TH) return;

  /* ---------- texture helpers (SVG filters, tiled, seamless) ---------- */
  function svg(w, h, defs, inner) { return 'url("data:image/svg+xml,' + encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' width='" + w + "' height='" + h + "'>" + (defs ? '<defs>' + defs + '</defs>' : '') + inner + '</svg>') + '")'; }
  /* soft grain: alpha follows noise */
  function grain(f, a, c, o) { o = o || {}; c = c || [0, 0, 0]; var sz = o.size || 200;
    return svg(sz, sz, "<filter id='n' x='0' y='0' width='100%' height='100%'><feTurbulence type='fractalNoise' baseFrequency='" + f + "' numOctaves='" + (o.oct || 2) + "' seed='" + (o.seed || 4) + "' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 " + c[0] + " 0 0 0 0 " + c[1] + " 0 0 0 0 " + c[2] + " " + (o.k || 1.6) + " 0 0 0 " + (o.b || -0.35) + "'/></filter>", "<rect width='100%' height='100%' filter='url(#n)' opacity='" + a + "'/>"); }
  /* a surface lit from the top-left: crevices darken (pebbled leather, concrete, linen …) */
  function bump(f, scale, dark, o) { o = o || {}; var sz = o.size || 200;
    return svg(sz, sz, "<filter id='b' x='0' y='0' width='100%' height='100%'><feTurbulence type='fractalNoise' baseFrequency='" + f + "' numOctaves='" + (o.oct || 3) + "' seed='" + (o.seed || 7) + "' stitchTiles='stitch' result='t'/><feDiffuseLighting in='t' lighting-color='#fff' surfaceScale='" + scale + "' result='l'><feDistantLight azimuth='" + (o.az || 235) + "' elevation='" + (o.el || 52) + "'/></feDiffuseLighting><feColorMatrix in='l' values='0 0 0 0 " + (o.c || '0') + " 0 0 0 0 " + (o.c || '0') + " 0 0 0 0 " + (o.c || '0') + " " + (o.k || -1.5) + " 0 0 0 " + (o.b || 1.1) + "'/></filter>", "<rect width='100%' height='100%' filter='url(#b)' opacity='" + dark + "'/>"); }
  /* streaky (brushed metal, linen threads): x/y frequencies differ */
  function brush(fx, fy, a, c, o) { o = o || {};
    return svg(o.w || 240, o.h || 240, "<filter id='s' x='0' y='0' width='100%' height='100%'><feTurbulence type='fractalNoise' baseFrequency='" + fx + " " + fy + "' numOctaves='2' seed='" + (o.seed || 5) + "' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 " + c[0] + " 0 0 0 0 " + c[1] + " 0 0 0 0 " + c[2] + " " + (o.k || 2) + " 0 0 0 " + (o.b || -0.55) + "'/></filter>", "<rect width='100%' height='100%' filter='url(#s)' opacity='" + a + "'/>"); }
  function dots(col, r, w, h, pts) { return svg(w, h, '', pts.map(function (p) { return "<circle cx='" + p[0] + "' cy='" + p[1] + "' r='" + (p[2] || r) + "' fill='" + col + "' opacity='" + (p[3] || 1) + "'/>"; }).join('')); }
  function stars(col, n, w, seed) { var s = seed || 11, pts = []; function r() { s = (s * 9301 + 49297) % 233280; return s / 233280; } for (var i = 0; i < n; i++) pts.push([Math.round(r() * w), Math.round(r() * w), r() > .85 ? 1.3 : .7, +(0.25 + r() * 0.6).toFixed(2)]); return dots(col, .8, w, w, pts); }
  var LAY = function (t, k, arr) { t.tok[k] = arr.join(',') + ',' + t.tok[k]; };
  var RIM = function (a) { return 'inset 0 0 0 1px ' + a; };
  var U = {}; /* css per family */
  var BIG = ':is(.dlg,.glass,#top,#ribbon,#acc,.panel,.wizcard,#side,.fbtn)', BTN = ':is(.btn,.sv,.pcard)', MENU = ':is(.menu,#toast)', ALLS = ':is(.dlg,.glass,#top,#ribbon,#acc,.panel,.wizcard,#side,.fbtn,.menu,#toast)';
  function css(fam, s) { U[fam] = (U[fam] || '') + s.replace(/\bF\b/g, 'html[data-dyn=' + fam + ']'); }

  var by = {}; TH.list.forEach(function (t) { by[t.family] = t; });
  function T(f, fn) { if (by[f]) fn(by[f]); }

  /* ================= SCULPTED · LIGHT ================= */
  T('porcelain', function (t) {  /* fine china: glaze, speckle, cobalt hairline rim */
    LAY(t, '--L-bg', [grain(.9, .22, [.42, .36, .3], { k: 1.2, b: -.5 }), 'linear-gradient(180deg,rgba(255,255,255,.65),rgba(255,255,255,0) 42%)']);
    LAY(t, '--S-bg', ['linear-gradient(180deg,rgba(255,255,255,.6),rgba(255,255,255,0) 55%)']);
    t.tok['--page-bg'] = grain(.8, .16, [.45, .38, .3], { size: 240 }) + ',radial-gradient(90% 60% at 50% -10%,#fffdf8,transparent 70%),#efe8dc';
    t.tok['--ON-bg'] = 'linear-gradient(180deg,#456aaa,#27427a)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#f7faff'; t.tok['--SEL-solid'] = '#456aaa'; t.tok['--SELS-c'] = '#cbd9f3';
    css('porcelain', 'F ' + BIG + '{outline:1px solid rgba(52,86,150,.34);outline-offset:-7px}F ' + ':is(.btn.on,.btn.pri){text-shadow:0 1px 0 rgba(10,25,60,.4)}F .dlg h3,F .panel h3,F .fbtn h2{font-family:Georgia,"Noto Serif",serif;letter-spacing:.01em}');
    t.prev = 'background:linear-gradient(180deg,rgba(255,255,255,.7),transparent 45%),#efe8dc;box-shadow:inset 0 0 0 1px #fff,inset 0 0 0 5px #efe8dc,inset 0 0 0 6px rgba(52,86,150,.5)';
  });
  T('lavender', function (t) {  /* soft-focus mist: dreamy, round, airy */
    LAY(t, '--L-bg', ['radial-gradient(120% 80% at 15% -10%,rgba(255,255,255,.85),transparent 60%)', 'radial-gradient(90% 60% at 100% 100%,rgba(190,170,240,.35),transparent 70%)']);
    LAY(t, '--S-bg', ['radial-gradient(120% 120% at 20% 0,rgba(255,255,255,.7),transparent 65%)']);
    t.tok['--page-bg'] = 'radial-gradient(60% 45% at 12% 8%,rgba(255,255,255,.9),transparent 70%),radial-gradient(55% 40% at 92% 18%,rgba(255,196,232,.55),transparent 70%),radial-gradient(70% 50% at 70% 100%,rgba(170,190,255,.55),transparent 70%),radial-gradient(50% 40% at 0 90%,rgba(200,170,250,.5),transparent 70%),#e5e1f1';
    t.tok['--ON-bg'] = 'linear-gradient(135deg,#9d87e8,#6c78d8)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#ffffff'; t.tok['--SEL-solid'] = '#8d7fe0'; t.tok['--SELS-c'] = '#e8e2ff';
    t.tok['--ON-sh'] = '0 8px 22px rgba(120,100,215,.45),inset 0 1px 0 rgba(255,255,255,.4)';
    css('lavender', 'F ' + BIG + '{border-radius:40px!important}F ' + MENU + '{border-radius:34px!important}F .btn{font-weight:500;letter-spacing:.015em}F .dlg h3,F .panel h3{font-weight:500;letter-spacing:.02em}');
    t.prev = 'background:radial-gradient(70% 90% at 15% 0,#fff,transparent 70%),radial-gradient(70% 80% at 100% 100%,rgba(190,170,240,.8),transparent 70%),#e5e1f1;box-shadow:inset 4px 4px 8px rgba(154,143,189,.5),inset -4px -4px 8px rgba(255,255,255,.9)';
  });
  T('sage', function (t) {  /* linen + botanical, leaf-cut corners */
    var leaf = svg(180, 180, '', "<g fill='none' stroke='rgb(70,112,76)' stroke-width='1.1' opacity='.16'><path d='M30 150 C34 110 52 78 88 52'/><path d='M44 118 C30 112 22 100 22 88 C36 90 46 100 44 118Z'/><path d='M56 92 C70 86 80 74 80 60 C64 64 54 76 56 92Z'/><path d='M66 74 C54 70 46 60 46 50 C58 52 66 62 66 74Z'/><path d='M120 170 C124 150 134 134 150 122'/><path d='M126 156 C118 154 112 146 112 138 C122 140 128 146 126 156Z'/><path d='M138 138 C146 136 152 130 152 122 C142 124 138 130 138 138Z'/></g>");
    LAY(t, '--L-bg', [brush(.5, .012, .3, [.28, .42, .28], { k: 1.8, b: -.45 }), brush(.012, .5, .3, [.28, .42, .28], { k: 1.8, b: -.45, seed: 9 })]);
    LAY(t, '--S-bg', [brush(.5, .012, .22, [.28, .42, .28], { k: 1.8, b: -.45 })]);
    t.tok['--page-bg'] = leaf + ',' + brush(.5, .012, .3, [.28, .42, .28], { k: 1.8, b: -.45 }) + ',radial-gradient(80% 50% at 20% 0,rgba(255,255,255,.55),transparent 70%),#dfe6dc';
    t.tok['--ON-bg'] = 'linear-gradient(160deg,#4d7456,#2b4632)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#f1faee';
    css('sage', 'F ' + BIG + '{border-radius:38px 12px 38px 12px!important}F ' + BTN + '{border-radius:24px 7px 24px 7px!important}F ' + MENU + '{border-radius:30px 10px 30px 10px!important}F .ddp{border-radius:24px 7px 24px 7px!important}');
    t.prev = 'background:repeating-linear-gradient(0deg,rgba(60,100,60,.12) 0 1px,transparent 1px 3px),repeating-linear-gradient(90deg,rgba(60,100,60,.12) 0 1px,transparent 1px 3px),#dfe6dc;border-radius:16px 4px 16px 4px;box-shadow:inset 4px 4px 8px rgba(138,159,138,.55),inset -4px -4px 8px rgba(255,255,255,.9)';
  });
  T('champagne', function (t) {  /* gold foil + rising bubbles */
    var bub = dots('none', 0, 200, 200, []).replace('%3C%2Fsvg%3E', '') && svg(200, 200, '', "<g fill='rgba(255,255,255,.35)' stroke='rgba(184,140,60,.28)' stroke-width='1'><circle cx='24' cy='170' r='5'/><circle cx='70' cy='120' r='3'/><circle cx='52' cy='60' r='7'/><circle cx='120' cy='150' r='4'/><circle cx='150' cy='80' r='6'/><circle cx='176' cy='30' r='3'/><circle cx='104' cy='34' r='4'/><circle cx='186' cy='160' r='3'/><circle cx='12' cy='96' r='3'/></g>");
    LAY(t, '--L-bg', ['linear-gradient(112deg,transparent 28%,rgba(255,238,190,.5) 46%,transparent 62%)', grain(.85, .14, [.55, .42, .2], { k: 1.2, b: -.45 })]);
    LAY(t, '--S-bg', ['linear-gradient(112deg,transparent 30%,rgba(255,240,200,.55) 48%,transparent 64%)']);
    t.tok['--page-bg'] = bub + ',radial-gradient(90% 50% at 50% 0,rgba(255,244,214,.9),transparent 70%),#ece0cc';
    t.tok['--ON-bg'] = 'linear-gradient(135deg,#f5df9f,#c99a45 48%,#f1d78e 62%,#b98a38)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#2d2210'; t.tok['--SEL-solid'] = '#d6ae5c'; t.tok['--SELS-c'] = '#5b4a2c';
    t.tok['--ON-bd'] = '1px solid rgba(150,110,40,.55)'; t.tok['--ON-sh'] = '0 4px 12px rgba(150,110,40,.4),inset 0 1px 0 rgba(255,255,255,.7)';
    css('champagne', 'F ' + BIG + '{outline:1px solid rgba(176,132,52,.45);outline-offset:-5px}F :is(.btn.on,.btn.pri){text-shadow:0 1px 0 rgba(255,246,214,.7)}F .dlg h3,F .panel h3{font-family:Georgia,"Noto Serif",serif;font-weight:600}');
    t.prev = 'background:linear-gradient(112deg,transparent 28%,rgba(255,238,190,.8) 46%,transparent 62%),#ece0cc;box-shadow:inset 0 0 0 1px rgba(176,132,52,.6),inset 4px 4px 8px rgba(168,146,111,.5),inset -4px -4px 8px #fff8ea';
  });

  /* ================= SCULPTED · DARK ================= */
  T('midnightblue', function (t) {  /* starlit sapphire */
    LAY(t, '--L-bg', [stars('#bcd2ff', 26, 160, 3)]);
    t.tok['--page-bg'] = stars('#cfe0ff', 34, 220, 21) + ',' + stars('#9fb9ff', 20, 300, 5) + ',radial-gradient(60% 40% at 80% 0,rgba(110,150,255,.2),transparent 70%),radial-gradient(70% 40% at 10% 100%,rgba(70,100,200,.18),transparent 70%),#131b2f';
    t.tok['--L-sh'] = t.tok['--L-sh'] + ',inset 0 0 26px rgba(90,130,230,.1)';
    t.tok['--ON-bg'] = 'linear-gradient(180deg,#86adff,#4c74e2)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#06102a'; t.tok['--SEL-solid'] = '#86adff'; t.tok['--SELS-c'] = '#1d3370';
    t.tok['--ON-sh'] = '0 0 20px rgba(110,155,255,.5),0 4px 12px rgba(0,0,0,.5),inset 0 1px 0 rgba(255,255,255,.45)';
    css('midnightblue', 'F ' + BIG + '{box-shadow:var(--L-sh),0 0 0 1px rgba(120,160,255,.16)!important}F .dlg h3,F .panel h3{text-shadow:0 0 14px rgba(120,160,255,.5)}');
    t.prev = stars('#cfe0ff', 22, 90, 3) + ',radial-gradient(70% 50% at 80% 0,rgba(110,150,255,.4),transparent 70%),#131b2f;box-shadow:inset 4px 4px 8px #02060f,inset -3px -3px 7px rgba(127,166,255,.12)';
  });
  T('water', function (t) {  /* sculpted deep water: soft caustic light, glassy meniscus */
    t.tok['--page-bg'] = 'radial-gradient(60% 38% at 22% 6%,rgba(116,214,255,.16),transparent 70%),radial-gradient(55% 40% at 88% 28%,rgba(70,170,215,.12),transparent 72%),radial-gradient(80% 50% at 40% 100%,rgba(20,80,110,.35),transparent 70%),linear-gradient(180deg,#0f2733,#0a1820 60%,#071118)';
    LAY(t, '--L-bg', ['linear-gradient(172deg,rgba(150,225,255,.10) 0,rgba(150,225,255,.03) 30%,rgba(150,225,255,0) 31%)']);
    t.tok['--L-sh'] = t.tok['--L-sh'] + ',inset 0 0 30px rgba(80,180,230,.08)';
    t.tok['--ON-bg'] = 'linear-gradient(180deg,#bfeaff,#6fb9dc)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#04141b'; t.tok['--SEL-solid'] = '#bfeaff'; t.tok['--SELS-c'] = '#12485e';
    t.tok['--ON-sh'] = '0 0 18px rgba(116,214,255,.35),0 4px 12px rgba(0,0,0,.5),inset 0 1px 0 rgba(255,255,255,.5)';
    css('water', 'F ' + BIG + '{box-shadow:var(--L-sh),0 0 0 1px rgba(130,215,255,.13)!important}F .dlg h3,F .panel h3{text-shadow:0 0 14px rgba(116,214,255,.4)}');
    t.prev = 'background:radial-gradient(60% 50% at 30% 20%,rgba(116,214,255,.35),transparent 70%),linear-gradient(180deg,#0f2733,#071118);box-shadow:inset 4px 4px 8px #01080c,inset -3px -3px 7px rgba(116,214,255,.14)';
  });
  T('burgundy', function (t) {  /* deep lacquer with a hard reflection and gold piping */
    LAY(t, '--L-bg', ['linear-gradient(168deg,rgba(255,255,255,.13) 0,rgba(255,255,255,.04) 34%,rgba(255,255,255,0) 34.5%)', grain(.9, .1, [1, .8, .8], { k: 1.1, b: -.4 })]);
    LAY(t, '--S-bg', ['linear-gradient(170deg,rgba(255,255,255,.14) 0,rgba(255,255,255,.04) 48%,rgba(255,255,255,0) 49%)']);
    t.tok['--page-bg'] = 'linear-gradient(168deg,rgba(255,120,140,.1) 0,rgba(255,120,140,.03) 38%,transparent 38.4%),radial-gradient(90% 50% at 20% 0,rgba(255,122,136,.12),transparent 70%),#2a1219';
    t.tok['--ON-bg'] = 'linear-gradient(145deg,#f6dfae,#c89c58 55%,#e9c985)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#3a0f19'; t.tok['--SEL-solid'] = '#e4c58a'; t.tok['--SELS-c'] = '#6d2433';
    css('burgundy', 'F ' + BIG + '{outline:1px solid rgba(232,194,126,.34);outline-offset:-6px}F :is(.btn.on,.btn.pri){text-shadow:0 1px 0 rgba(255,240,200,.5)}');
    t.prev = 'background:linear-gradient(168deg,rgba(255,255,255,.16) 0,rgba(255,255,255,.05) 40%,transparent 41%),#2a1219;box-shadow:inset 0 0 0 1px rgba(232,194,126,.4),inset 4px 4px 8px #0e0205';
  });
  T('amethyst', function (t) {  /* geode: cut facets, glints */
    var fac = 'conic-gradient(from 30deg at 28% 18%,rgba(200,160,255,.2),transparent 18%,rgba(255,255,255,.08) 30%,transparent 46%,rgba(150,100,235,.2) 64%,transparent 80%,rgba(255,255,255,.07) 92%)';
    LAY(t, '--L-bg', [fac, stars('#e5d3ff', 16, 150, 8)]);
    LAY(t, '--S-bg', ['conic-gradient(from 30deg at 25% 15%,rgba(210,170,255,.22),transparent 25%,rgba(255,255,255,.08) 40%,transparent 60%,rgba(150,100,235,.18) 80%,transparent)']);
    t.tok['--page-bg'] = 'conic-gradient(from 200deg at 85% 0,rgba(185,140,255,.2),transparent 22%,rgba(255,255,255,.04) 36%,transparent 52%),conic-gradient(from 20deg at 5% 100%,rgba(130,80,220,.25),transparent 25%,rgba(220,190,255,.06) 40%,transparent 60%),' + stars('#e5d3ff', 20, 240, 13) + ',#241731';
    t.tok['--ON-bg'] = 'linear-gradient(145deg,#d9bcff,#9d6df0)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#1d0a35'; t.tok['--SEL-solid'] = '#d9bcff'; t.tok['--SELS-c'] = '#4a2a80';
    t.tok['--ON-sh'] = '0 0 18px rgba(185,140,255,.5),0 4px 12px rgba(0,0,0,.5),inset 0 1px 0 rgba(255,255,255,.5)';
    css('amethyst', 'F ' + BIG + '{box-shadow:var(--L-sh),0 0 0 1px rgba(190,150,255,.24)!important}F ' + BTN + '{box-shadow:var(--S-sh),0 0 0 1px rgba(190,150,255,.14)}');
    t.prev = 'background:conic-gradient(from 30deg at 28% 18%,rgba(200,160,255,.5),transparent 20%,rgba(255,255,255,.14) 32%,transparent 46%,rgba(150,100,235,.5) 66%,transparent 82%),#241731;box-shadow:inset 0 0 0 1px rgba(190,150,255,.4),inset 4px 4px 8px #0b0314';
  });
  T('graphite', function (t) {  /* carbon twill, machined edges, technical type */
    var tw = 'repeating-linear-gradient(45deg,rgba(255,255,255,.035) 0 2px,transparent 2px 4px),repeating-linear-gradient(-45deg,rgba(0,0,0,.2) 0 2px,transparent 2px 4px)';
    LAY(t, '--L-bg', [tw]); LAY(t, '--S-bg', [tw]);
    t.tok['--page-bg'] = tw + ',radial-gradient(90% 50% at 20% 0,rgba(255,255,255,.07),transparent 70%),#27292c';
    t.tok['--L-sh'] = t.tok['--L-sh'] + ',inset 0 0 0 1px rgba(255,255,255,.06)';
    t.tok['--ON-bg'] = 'linear-gradient(180deg,#f3f4f6,#c3c6cc)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#0e0f10';
    css('graphite', 'F ' + BIG + '{border-radius:16px!important}F ' + BTN + '{border-radius:11px!important}F .ddp{border-radius:11px!important}F ' + MENU + '{border-radius:14px!important}F .btn,F .hd,F .dlg h3,F .panel h3{font-family:ui-monospace,"SF Mono","Roboto Mono",Menlo,monospace;letter-spacing:.02em}F .btn{font-size:.92em}F .dlg h3,F .panel h3{text-transform:uppercase;font-size:1em;letter-spacing:.12em}');
    t.prev = 'background:repeating-linear-gradient(45deg,rgba(255,255,255,.08) 0 2px,transparent 2px 4px),repeating-linear-gradient(-45deg,rgba(0,0,0,.35) 0 2px,transparent 2px 4px),#27292c;border-radius:10px;box-shadow:inset 0 1px 0 rgba(255,255,255,.25),inset 0 0 0 1px rgba(255,255,255,.07)';
  });

  /* ================= MATERIAL ================= */
  T('crystal', function (t) {  /* faceted ice: thick polished rim, caustic streak, prism light */
    LAY(t, '--L-bg', ['linear-gradient(118deg,rgba(255,255,255,.8) 0,rgba(255,255,255,.12) 22%,transparent 23%,transparent 58%,rgba(255,255,255,.22) 59%,transparent 74%)', 'conic-gradient(from 210deg at 100% 0,rgba(120,200,255,.18),transparent 14%,rgba(255,170,230,.12) 28%,transparent 40%)']);
    LAY(t, '--S-bg', ['linear-gradient(118deg,rgba(255,255,255,.85) 0,rgba(255,255,255,.1) 30%,transparent 31%)']);
    t.tok['--L-sh'] = '0 18px 40px rgba(60,110,170,.25),inset 0 0 0 1.5px rgba(255,255,255,.95),inset 0 14px 22px rgba(255,255,255,.55),inset 0 -12px 22px rgba(120,175,230,.3)';
    t.tok['--S-sh'] = 'inset 0 0 0 1px rgba(255,255,255,.9),inset 0 8px 12px rgba(255,255,255,.6),inset 0 -6px 10px rgba(120,175,230,.28),0 4px 10px rgba(60,110,170,.2)';
    t.tok['--page-bg'] = 'conic-gradient(from 200deg at 105% -5%,rgba(110,200,255,.35),transparent 12%,rgba(255,160,230,.2) 22%,transparent 34%),radial-gradient(70% 50% at 15% 0,rgba(255,255,255,.95),transparent 70%),radial-gradient(60% 50% at 90% 100%,rgba(170,200,235,.6),transparent 70%),#dce8f3';
    css('crystal', 'F ' + BIG + '{border-radius:36px!important}F ' + MENU + '{border-radius:30px!important}F .btn.on,F .btn.pri{box-shadow:0 6px 16px rgba(20,50,90,.4),inset 0 1px 0 rgba(255,255,255,.5)}');
    t.prev = 'background:linear-gradient(118deg,rgba(255,255,255,.95) 0,rgba(255,255,255,.2) 28%,transparent 29%),conic-gradient(from 210deg at 100% 0,rgba(120,200,255,.5),transparent 18%,rgba(255,170,230,.3) 34%,transparent 46%),#cfe2f3;box-shadow:inset 0 0 0 1.5px #fff,inset 0 -8px 14px rgba(120,175,230,.45)';
  });
  T('titanium', function (t) {  /* brushed, bead-blasted metal with machined chamfers and rivets */
    var br = brush(.0025, .85, .5, [0, 0, 0], { k: 1.6, b: -.5, w: 260, h: 260 }), brw = brush(.0025, .85, .5, [1, 1, 1], { k: 1.6, b: -.45, seed: 9, w: 260, h: 260 });
    var sheen = 'linear-gradient(100deg,rgba(255,255,255,0) 14%,rgba(255,255,255,.4) 32%,rgba(255,255,255,0) 48%,rgba(0,0,0,.07) 66%,rgba(255,255,255,.22) 82%,rgba(255,255,255,0) 96%)';
    var rivL = 'radial-gradient(circle at 50% 38%,#f1f3f6 0 1px,#9ba1aa 2px,#6a7078 3.4px,transparent 4px) left 12px center/10px 10px no-repeat', rivR = 'radial-gradient(circle at 50% 38%,#f1f3f6 0 1px,#9ba1aa 2px,#6a7078 3.4px,transparent 4px) right 12px center/10px 10px no-repeat';
    LAY(t, '--L-bg', [rivL, rivR, brw, br, sheen]); LAY(t, '--S-bg', [br, sheen]);
    t.tok['--page-bg'] = brw + ',' + br + ',linear-gradient(100deg,#c9ccd1 0,#dde0e4 30%,#c0c4ca 55%,#d6d9de 80%,#c4c8ce 100%)';
    t.tok['--L-sh'] = '0 14px 30px rgba(40,46,56,.4),inset 0 1px 0 #fff,inset 1px 0 0 rgba(255,255,255,.55),inset 0 -1px 0 rgba(0,0,0,.35),inset -1px 0 0 rgba(0,0,0,.2)';
    t.tok['--S-sh'] = '0 3px 7px rgba(40,46,56,.4),inset 0 1px 0 #fff,inset 0 -1px 0 rgba(0,0,0,.3),inset 0 0 0 1px rgba(255,255,255,.25)';
    t.tok['--ON-bg'] = brw + ',linear-gradient(180deg,#4a5059,#23272d)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg'];
    t.tok['--ON-sh'] = '0 4px 10px rgba(20,24,30,.5),inset 0 1px 0 rgba(255,255,255,.35),0 0 0 1px rgba(20,24,30,.6)';
    css('titanium', 'F :is(.dlg,.glass,#top){background:var(--L-bg)!important}F ' + ALLS + '{text-shadow:0 1px 0 rgba(255,255,255,.55)}F :is(.btn.on,.btn.pri){text-shadow:0 -1px 0 rgba(0,0,0,.6)}F ' + BIG + '{border-radius:22px!important}');
    t.prev = 'background:' + brush(.0025, .85, .5, [0, 0, 0], { w: 120, h: 120 }) + ',linear-gradient(100deg,rgba(255,255,255,0) 14%,rgba(255,255,255,.55) 34%,rgba(255,255,255,0) 50%,rgba(0,0,0,.1) 68%,rgba(255,255,255,.3) 84%),#c1c5cb;box-shadow:inset 0 1px 0 #fff,inset 0 -2px 3px rgba(0,0,0,.3),inset 0 0 0 1px rgba(255,255,255,.3)';
  });
  T('leather', function (t) {  /* full-grain pebbled leather, saddle stitching, blind-debossed wells, gold foil */
    var peb = bump(.62, 2.1, .9, { size: 220, oct: 3, k: -1.7, b: 1.18, seed: 12 }), pebS = bump(.62, 1.8, .7, { size: 220, oct: 3, k: -1.7, b: 1.18, seed: 12 });
    LAY(t, '--L-bg', [peb, 'radial-gradient(130% 100% at 50% 0,rgba(255,196,140,.1),transparent 60%)']);
    LAY(t, '--S-bg', [pebS]);
    t.tok['--P-bg'] = peb + ',#1e130e';
    t.tok['--page-bg'] = bump(.62, 2.2, 1, { size: 240, oct: 3, k: -1.7, b: 1.18, seed: 12 }) + ',radial-gradient(130% 90% at 50% 38%,transparent 45%,rgba(0,0,0,.5) 100%),radial-gradient(80% 45% at 50% 0,rgba(255,190,130,.14),transparent 70%),#3a281d';
    t.tok['--L-sh'] = '0 12px 24px rgba(0,0,0,.6),inset 0 1px 0 rgba(255,214,160,.25),inset 0 -3px 6px rgba(0,0,0,.45),inset 0 0 0 1px rgba(0,0,0,.35)';
    t.tok['--S-sh'] = '0 4px 8px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,214,160,.22),inset 0 -2px 4px rgba(0,0,0,.4)';
    t.tok['--P-sh'] = 'inset 0 3px 6px rgba(0,0,0,.7),inset 0 -1px 0 rgba(255,214,160,.14)';
    t.tok['--ON-bg'] = 'linear-gradient(135deg,#f2d79e,#b98a46 48%,#e9c583 66%,#a97b3b)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#2a1a0b'; t.tok['--SEL-solid'] = '#e3bf86'; t.tok['--SELS-c'] = '#5a3d1c';
    t.tok['--ON-sh'] = '0 3px 8px rgba(0,0,0,.6),inset 0 1px 0 rgba(255,244,214,.65),inset 0 -1px 2px rgba(110,70,20,.5)';
    css('leather', 'F ' + BIG + '{outline:1.6px dashed rgba(238,202,150,.62);outline-offset:-9px}F ' + BTN + '{outline:1px dashed rgba(238,202,150,.42);outline-offset:-4px}F :is(.btn.on,.btn.pri){outline-color:rgba(70,40,10,.5);text-shadow:0 1px 0 rgba(255,236,190,.55)}F ' + MENU + '{outline:1.2px dashed rgba(238,202,150,.5);outline-offset:-7px}F .dlg h3,F .panel h3,F .fbtn h2{font-family:Georgia,"Noto Serif",serif;letter-spacing:.03em;text-shadow:0 1px 0 rgba(0,0,0,.6),0 -1px 0 rgba(255,214,160,.2)}F :is(.btn,.hd):not(.on):not(.pri){text-shadow:0 1px 0 rgba(0,0,0,.55)}');
    t.prev = peb + ',linear-gradient(160deg,#53392a,#33231a);outline:1.5px dashed rgba(238,202,150,.7);outline-offset:-5px;box-shadow:inset 0 -3px 5px rgba(0,0,0,.5),inset 0 1px 0 rgba(255,214,160,.3)';
  });
  T('ceramic', function (t) {  /* glossy glazed black: clear-coat highlights, kiln flecks */
    LAY(t, '--L-bg', ['radial-gradient(120% 55% at 28% -8%,rgba(255,255,255,.2),rgba(255,255,255,.05) 55%,transparent 56%)', grain(1.4, .3, [1, 1, 1], { size: 160, k: 3, b: -1.5 })]);
    LAY(t, '--S-bg', ['radial-gradient(120% 70% at 30% -10%,rgba(255,255,255,.22),transparent 60%)']);
    t.tok['--page-bg'] = 'radial-gradient(70% 40% at 30% 0,rgba(180,200,240,.12),transparent 70%),' + grain(1.4, .25, [1, 1, 1], { size: 200, k: 3, b: -1.55 }) + ',#0f1013';
    t.tok['--L-sh'] = '0 18px 38px rgba(0,0,0,.7),inset 0 1.5px 0 rgba(235,242,255,.4),inset 0 0 0 1px rgba(210,222,250,.1),inset 0 -12px 20px rgba(0,0,0,.4)';
    t.tok['--S-sh'] = '0 5px 12px rgba(0,0,0,.6),inset 0 1.5px 0 rgba(235,242,255,.4),inset 0 -6px 10px rgba(0,0,0,.35)';
    css('ceramic', 'F ' + BIG + '{border-radius:38px!important}F ' + MENU + '{border-radius:32px!important}F :is(.btn.on,.btn.pri){box-shadow:0 6px 18px rgba(0,0,0,.6),inset 0 2px 0 rgba(255,255,255,.9),inset 0 -6px 10px rgba(140,150,175,.45)}');
    t.prev = 'background:radial-gradient(120% 55% at 28% -8%,rgba(255,255,255,.35),rgba(255,255,255,.06) 55%,transparent 56%),linear-gradient(160deg,#262a32,#0b0c0f);box-shadow:inset 0 1.5px 0 rgba(235,242,255,.5),inset 0 -8px 12px rgba(0,0,0,.5)';
  });
  T('chrome', function (t) {  /* mirror chrome: horizon reflection, hard specular streaks */
    var hz = 'linear-gradient(180deg,#fbfcfd 0,#dfe3e8 24%,#a8afb9 47%,#4b525d 49.5%,#7d8591 52%,#c3c9d1 74%,#f1f3f6 100%)';
    var streak = 'linear-gradient(112deg,transparent 0 8%,rgba(255,255,255,.95) 8% 12%,transparent 12% 17%,rgba(255,255,255,.55) 17% 19%,transparent 19% 100%)';
    LAY(t, '--L-bg', [streak, 'linear-gradient(180deg,rgba(255,255,255,.55) 0,rgba(255,255,255,0) 46%,rgba(70,78,92,.22) 50%,rgba(255,255,255,.28) 100%)']);
    LAY(t, '--S-bg', [hz.replace('#fbfcfd', 'rgba(255,255,255,.85)'), streak]);
    t.tok['--S-bg'] = hz + ',' + t.tok['--S-bg'].split(',').slice(0, 0).join(',') + '#cdd2d9'; t.tok['--S-bg'] = streak + ',' + hz;
    t.tok['--page-bg'] = 'radial-gradient(45% 35% at 15% 12%,rgba(255,255,255,.95),transparent 70%),radial-gradient(40% 30% at 85% 30%,rgba(120,130,150,.35),transparent 70%),radial-gradient(60% 40% at 50% 100%,rgba(255,255,255,.7),transparent 70%),linear-gradient(115deg,#eef0f3 0%,#9aa1ab 28%,#f5f6f8 44%,#868e99 60%,#e8ebef 78%,#aeb4be 100%)';
    t.tok['--S-sh'] = '0 4px 10px rgba(30,36,46,.45),inset 0 1px 0 #fff,inset 0 -1px 0 rgba(0,0,0,.35),inset 0 0 0 1px rgba(255,255,255,.4)';
    t.tok['--L-sh'] = '0 16px 34px rgba(30,36,46,.4),inset 0 2px 0 #fff,inset 0 -2px 0 rgba(60,68,80,.35),inset 0 0 0 1px rgba(255,255,255,.5)';
    t.tok['--ON-bg'] = 'linear-gradient(112deg,transparent 0 10%,rgba(255,255,255,.28) 10% 14%,transparent 14%),linear-gradient(180deg,#5b626d 0,#2a2f37 48%,#0c0e12 50%,#2a2f38 70%,#4a515c 100%)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg'];
    t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#f6f8fb'; t.tok['--ON-sh'] = '0 4px 10px rgba(10,14,20,.6),inset 0 1px 0 rgba(255,255,255,.55),0 0 0 1px rgba(10,14,20,.7)';
    css('chrome', 'F ' + ALLS + '{text-shadow:0 1px 0 rgba(255,255,255,.75)}F :is(.btn.on,.btn.pri){text-shadow:0 -1px 0 rgba(0,0,0,.65)}F ' + BIG + '{border-radius:34px!important}F .dlg h3,F .panel h3,F .fbtn h2{font-weight:800;letter-spacing:.01em}');
    t.prev = 'background:linear-gradient(112deg,transparent 0 8%,rgba(255,255,255,.95) 8% 12%,transparent 12% 17%,rgba(255,255,255,.55) 17% 19%,transparent 19%),linear-gradient(180deg,#fbfcfd 0,#dfe3e8 24%,#a8afb9 47%,#4b525d 49.5%,#7d8591 52%,#c3c9d1 74%,#f1f3f6 100%);box-shadow:inset 0 1px 0 #fff,inset 0 -1px 0 rgba(0,0,0,.4)';
  });
  T('paper', function (t) {  /* heavy cotton paper: fibre, letterpress, stacked sheets */
    var fib = grain(.55, .35, [.42, .34, .2], { k: 1.3, b: -.45, size: 220 }), fib2 = brush(.9, .05, .2, [.5, .42, .28], { k: 1.5, b: -.4, seed: 8 });
    LAY(t, '--L-bg', [fib, fib2]); LAY(t, '--S-bg', [fib]);
    t.tok['--page-bg'] = fib + ',' + fib2 + ',radial-gradient(90% 60% at 50% -5%,rgba(255,255,255,.55),transparent 70%),#ece5d6';
    t.tok['--L-sh'] = '0 1px 0 rgba(120,100,70,.35),0 4px 0 -1px #f3eddf,0 5px 0 -1px rgba(120,100,70,.28),0 8px 0 -2px #eee7d8,0 9px 0 -2px rgba(120,100,70,.22),0 20px 30px rgba(110,90,60,.22),inset 0 1px 0 rgba(255,255,255,.9)';
    t.tok['--ON-bg'] = 'linear-gradient(180deg,#5a4a32,#3b2f1e)';
    css('paper', 'F ' + BIG + '{border-radius:12px!important}F ' + BTN + '{border-radius:10px!important}F .ddp{border-radius:10px!important}F ' + MENU + '{border-radius:12px!important}F ' + ALLS + '{text-shadow:0 1px 0 rgba(255,255,255,.85)}F :is(.btn.on,.btn.pri){text-shadow:0 -1px 0 rgba(0,0,0,.4)}F .dlg h3,F .panel h3,F .fbtn h2,F .hero p{font-family:Georgia,"Noto Serif",serif}F input.t,F textarea.t{border-radius:8px!important}');
    t.prev = fib + ',#f1ebde;border-radius:8px;box-shadow:0 1px 0 rgba(120,100,70,.4),0 4px 0 -1px #f3eddf,0 5px 0 -1px rgba(120,100,70,.3),inset 0 1px 0 #fff';
  });

  /* ================= ATMOSPHERE ================= */
  T('velvet', function (t) {  /* theatre: pile fabric, curtain folds, gold piping, spotlight */
    var fold = 'repeating-linear-gradient(90deg,rgba(0,0,0,.34) 0,rgba(255,110,100,.05) 26px,rgba(0,0,0,.34) 58px,rgba(0,0,0,.34) 62px)';
    LAY(t, '--L-bg', [grain(1.2, .25, [1, .7, .6], { k: 1.4, b: -.55, size: 140 }), 'radial-gradient(100% 70% at 50% 0,rgba(255,190,120,.12),transparent 70%)']);
    LAY(t, '--S-bg', [grain(1.2, .22, [1, .7, .6], { k: 1.4, b: -.55, size: 140 })]);
    t.tok['--page-bg'] = 'radial-gradient(70% 38% at 50% -4%,rgba(255,200,130,.3),transparent 72%),' + fold + ',#1b070c';
    t.tok['--ON-bg'] = 'linear-gradient(135deg,#f6dfa8,#cfa557 50%,#f0d189)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#2a1206';
    t.tok['--L-sh'] = '0 14px 34px rgba(0,0,0,.65),inset 0 1px 0 rgba(255,200,150,.14),inset 0 -14px 26px rgba(0,0,0,.35)';
    css('velvet', 'F ' + BIG + '{outline:1.5px solid rgba(232,190,110,.55);outline-offset:-5px}F ' + BIG + '::after{pointer-events:none}F .dlg h3,F .panel h3,F .fbtn h2{font-family:Georgia,"Noto Serif",serif;letter-spacing:.06em;color:#f3d79a!important;text-shadow:0 0 14px rgba(255,190,100,.35)}F :is(.btn.on,.btn.pri){text-shadow:0 1px 0 rgba(255,244,210,.55)}');
    t.prev = 'background:radial-gradient(70% 60% at 50% 0,rgba(255,200,130,.5),transparent 72%),repeating-linear-gradient(90deg,rgba(0,0,0,.4) 0,rgba(255,110,100,.08) 8px,rgba(0,0,0,.4) 17px),#2a0a12;box-shadow:inset 0 0 0 1.5px rgba(232,190,110,.6)';
  });
  T('noir', function (t) {  /* black & white film: grain, venetian-blind light, hard edges */
    var blind = 'repeating-linear-gradient(112deg,rgba(255,255,255,.075) 0 26px,transparent 26px 74px)';
    LAY(t, '--L-bg', [grain(.9, .3, [1, 1, 1], { k: 1.5, b: -.7, size: 160 })]);
    t.tok['--page-bg'] = grain(.9, .32, [1, 1, 1], { k: 1.5, b: -.7, size: 180 }) + ',radial-gradient(80% 60% at 80% 10%,rgba(255,255,255,.1),transparent 70%),' + blind + ',radial-gradient(120% 100% at 50% 40%,transparent 40%,rgba(0,0,0,.65) 100%),#0c0c0d';
    t.tok['--ON-bg'] = 'linear-gradient(180deg,#f4f4f4,#c7c7c9)';
    css('noir', 'F ' + BIG + '{border-radius:6px!important;border:1px solid rgba(255,255,255,.2)!important}F ' + BTN + '{border-radius:5px!important}F .ddp{border-radius:5px!important}F ' + MENU + '{border-radius:6px!important}F .btn{text-transform:uppercase;letter-spacing:.09em;font-size:.82em}F .dlg h3,F .panel h3,F .fbtn h2,F .hero p{font-family:"Courier New",Courier,monospace;letter-spacing:.08em;text-transform:uppercase}F input.t,F textarea.t{border-radius:5px!important}');
    t.prev = 'background:repeating-linear-gradient(112deg,rgba(255,255,255,.14) 0 8px,transparent 8px 22px),radial-gradient(120% 100% at 50% 40%,transparent 35%,rgba(0,0,0,.8)),#0c0c0d;border-radius:4px;box-shadow:inset 0 0 0 1px rgba(255,255,255,.3)';
  });
  T('tungsten', function (t) {  /* incandescent: a hot filament glow that falls off */
    LAY(t, '--L-bg', ['radial-gradient(110% 80% at 50% -10%,rgba(255,176,70,.2),transparent 65%)']);
    LAY(t, '--S-bg', ['radial-gradient(120% 90% at 50% -20%,rgba(255,176,70,.22),transparent 65%)']);
    t.tok['--page-bg'] = 'radial-gradient(60% 34% at 50% -2%,rgba(255,205,110,.6),rgba(255,160,50,.22) 45%,transparent 75%),radial-gradient(120% 70% at 50% 120%,rgba(0,0,0,.5),transparent 70%),#231508';
    t.tok['--L-sh'] = '0 14px 34px rgba(0,0,0,.6),0 0 28px rgba(255,160,50,.1),inset 0 1px 0 rgba(255,205,130,.2)';
    t.tok['--ON-bg'] = 'radial-gradient(120% 140% at 50% 0,#ffe08c,#ffb347 55%,#e8841c)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg'];
    t.tok['--ON-sh'] = '0 0 22px rgba(255,170,60,.65),0 4px 12px rgba(0,0,0,.5),inset 0 1px 0 rgba(255,255,255,.55)';
    css('tungsten', 'F .dlg h3,F .panel h3,F .fbtn h2{text-shadow:0 0 16px rgba(255,170,60,.55)}F ' + BTN + ':not(.on):not(.pri){box-shadow:var(--S-sh),0 0 12px rgba(255,160,50,.07)}');
    t.prev = 'background:radial-gradient(70% 60% at 50% 0,#ffd27a,rgba(255,160,50,.5) 50%,transparent 76%),#2a1a0b;box-shadow:0 0 14px rgba(255,170,60,.4),inset 0 1px 0 rgba(255,220,150,.5)';
  });
  T('dusk', function (t) {  /* twilight sky: stars above, glowing horizon, glass layers */
    LAY(t, '--L-bg', [stars('#f1dcff', 14, 140, 17)]);
    t.tok['--page-bg'] = stars('#f6e6ff', 26, 200, 6) + ',radial-gradient(90% 32% at 50% 102%,rgba(255,150,120,.45),rgba(230,110,150,.2) 50%,transparent 80%),linear-gradient(180deg,#1f1a3b 0%,#35294b 55%,#5a3a55 100%)';
    t.tok['--ON-bg'] = 'linear-gradient(180deg,#ffd9c2,#f09aa8)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#3a1a3a';
    css('dusk', 'F ' + BIG + '{-webkit-backdrop-filter:blur(12px)!important;backdrop-filter:blur(12px)!important;border-radius:34px!important}F ' + MENU + '{-webkit-backdrop-filter:blur(14px)!important;backdrop-filter:blur(14px)!important}');
    t.prev = stars('#f6e6ff', 14, 80, 6) + ',radial-gradient(100% 40% at 50% 105%,rgba(255,150,120,.7),transparent 80%),linear-gradient(180deg,#1f1a3b,#4a3350 70%,#6a4558)';
  });
  T('midnight', function (t) {  /* deep night: crisp stars and a pale moon glow */
    LAY(t, '--L-bg', [stars('#dfe9ff', 18, 150, 31)]);
    t.tok['--page-bg'] = 'radial-gradient(circle at 82% 9%,rgba(235,242,255,.9) 0 6px,rgba(190,210,255,.28) 7px,rgba(120,160,240,.1) 40px,transparent 130px),' + stars('#e6efff', 30, 210, 2) + ',' + stars('#9ab4ee', 24, 310, 8) + ',#060a14';
    t.tok['--ON-bg'] = 'linear-gradient(180deg,#eaf1ff,#b4cbf3)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg'];
    t.tok['--ON-sh'] = '0 0 18px rgba(170,200,255,.45),0 4px 12px rgba(0,0,0,.55),inset 0 1px 0 #fff';
    css('midnight', 'F ' + BIG + '{box-shadow:var(--L-sh),0 0 0 1px rgba(140,170,240,.14)!important}');
    t.prev = 'background:radial-gradient(circle at 80% 18%,#f0f5ff 0 4px,rgba(190,210,255,.3) 6px,transparent 34px),' + stars('#e6efff', 22, 90, 2) + ',#060a14';
  });
  T('forest', function (t) {  /* pine ridgeline, mist, moss */
    var pines = svg(260, 90, '', "<path fill='rgb(5,14,9)' opacity='.85' d='M0 90V70l10-24 6 12 8-30 8 26 6-10 10 30 8-18 7 14 9-34 9 30 7-12 9 22 10-26 8 20 7-12 10 28 9-16 8 20 10-30 8 26 8-14 9 24 8-18 9 22 7-10 8 20V90Z'/>");
    LAY(t, '--L-bg', [grain(.7, .18, [.6, .8, .6], { k: 1.3, b: -.5, size: 180 })]);
    t.tok['--page-bg'] = pines + ' repeat-x bottom/260px 90px,radial-gradient(90% 26% at 50% 100%,rgba(150,200,160,.28),transparent 75%),radial-gradient(70% 40% at 20% -5%,rgba(150,190,150,.1),transparent 70%),linear-gradient(180deg,#0a1a11,#0d2016 70%,#0b1a12)';
    t.tok['--ON-bg'] = 'linear-gradient(180deg,#d9efc9,#9cc88f)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg'];
    css('forest', 'F ' + BIG + '{border-radius:30px 30px 22px 22px!important}');
    t.prev = pines + ' repeat-x bottom/120px 42px,radial-gradient(90% 40% at 50% 100%,rgba(150,200,160,.4),transparent 75%),linear-gradient(180deg,#14281c,#08130c)';
  });
  T('redroom', function (t) {  /* chevron floor, red drapes, neon edge */
    var zig = svg(80, 40, '', "<path d='M0 20 L20 0 L40 20 L60 0 L80 20 L80 40 L60 20 L40 40 L20 20 L0 40Z' fill='rgb(240,240,240)' opacity='.1'/>");
    var drape = 'repeating-linear-gradient(90deg,rgba(0,0,0,.4) 0,rgba(230,30,50,.08) 22px,rgba(0,0,0,.4) 50px)';
    LAY(t, '--L-bg', [drape]);
    t.tok['--page-bg'] = zig + ' repeat-x bottom/80px 40px,' + drape + ',radial-gradient(80% 36% at 50% 108%,rgba(230,30,50,.3),transparent 70%),#090405';
    t.tok['--ON-bg'] = 'linear-gradient(180deg,#ff6b78,#c3162c)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#fff4f4';
    t.tok['--ON-sh'] = '0 0 22px rgba(255,40,60,.6),0 4px 12px rgba(0,0,0,.6),inset 0 1px 0 rgba(255,200,200,.5)';
    css('redroom', 'F ' + BIG + '{box-shadow:var(--L-sh),0 0 0 1px rgba(255,70,80,.4),0 0 22px rgba(255,40,60,.16)!important}F ' + BTN + ':not(.on):not(.pri){box-shadow:var(--S-sh),0 0 0 1px rgba(255,70,80,.22)}F .dlg h3,F .panel h3,F .fbtn h2{text-shadow:0 0 14px rgba(255,50,70,.6);letter-spacing:.05em}');
    t.prev = zig + ' repeat-x bottom/50px 25px,radial-gradient(60% 60% at 50% 100%,rgba(230,40,60,.7),transparent 72%),repeating-linear-gradient(90deg,rgba(0,0,0,.5) 0,rgba(230,30,50,.12) 8px,rgba(0,0,0,.5) 18px),#14060a;box-shadow:0 0 12px rgba(255,50,70,.4),inset 0 0 0 1px rgba(255,70,80,.6)';
  });

  /* ================= EXPERIMENTAL ================= */
  T('brutalist', function (t) {  /* board-marked concrete, tie holes, hazard yellow, monospaced labels */
    var conc = bump(.045, 3, .55, { size: 260, oct: 4, c: '0', k: -1.2, b: 1.0, seed: 19, el: 60 }), pits = grain(.9, .5, [.2, .2, .2], { k: 3, b: -1.6, size: 180 });
    var board = 'repeating-linear-gradient(0deg,rgba(0,0,0,.2) 0 1px,transparent 1px 118px)', tie = svg(240, 236, '', "<circle cx='60' cy='59' r='6.5' fill='rgb(35,35,33)' opacity='.8'/><circle cx='60' cy='59' r='9' fill='none' stroke='rgb(35,35,33)' stroke-width='1.2' opacity='.35'/><circle cx='180' cy='177' r='6.5' fill='rgb(35,35,33)' opacity='.8'/><circle cx='180' cy='177' r='9' fill='none' stroke='rgb(35,35,33)' stroke-width='1.2' opacity='.35'/>");
    LAY(t, '--L-bg', [pits, conc]); LAY(t, '--S-bg', [pits]);
    t.tok['--page-bg'] = tie + ',' + board + ',' + pits + ',' + conc + ',#b9b8b3';
    t.tok['--ON-bg'] = 'linear-gradient(#111,#111)'; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#ffd400'; t.tok['--SELS-c'] = '#ffd400';
    css('brutalist', 'F :is(.btn.on,.btn.pri){color:#ffd400!important}F .btn,F .hd,F .dlg h3,F .panel h3,F .fbtn h2,F .hero p{font-family:ui-monospace,"SF Mono",Menlo,"Courier New",monospace}F .dlg h3,F .panel h3,F .fbtn h2{text-transform:uppercase;letter-spacing:.06em;font-weight:900}F .menu>button{font-family:ui-monospace,Menlo,monospace;text-transform:uppercase;letter-spacing:.03em;font-weight:700}F .menu>button.sel{background:#111!important;color:#ffd400!important;box-shadow:none!important}F ' + BIG + '{position:relative}');
    t.prev = tie.replace(/240/, '120') && ('background:' + conc + ',linear-gradient(#bdbcb7,#bdbcb7);box-shadow:inset 0 0 0 3px #111,5px 5px 0 #111');
  });
  T('eink', function (t) {  /* e-paper: dithered shadows, microcapsule dots, serif type, no motion */
    var cap = svg(4, 4, '', "<circle cx='2' cy='2' r='.9' fill='rgb(60,60,55)' opacity='.12'/>"), dith = 'repeating-conic-gradient(#000 0 25%,transparent 0 50%) 0 0/3px 3px';
    t.tok['--page-c'] = '#dcdcd4'; t.tok['--page-bg'] = cap + ',' + grain(.8, .22, [.3, .3, .26], { k: 1.1, b: -.45, size: 160 }) + ',#dcdcd4';
    LAY(t, '--L-bg', [cap]); LAY(t, '--S-bg', [cap]);
    t.tok['--L-bg'] = cap + ',#e4e4dc'; t.tok['--S-bg'] = cap + ',#e4e4dc'; t.tok['--S-bg-flat'] = '#e4e4dc'; t.tok['--L-bg-flat'] = '#e4e4dc';
    css('eink', 'F :is(.btn,.glass,.dlg,.menu,.sv,.pcard,.fbtn,.panel,.wizcard,#side,#top,#ribbon,#toast){text-shadow:0 0 .6px rgba(0,0,0,.45)}F :is(.dlg,.menu,.panel,.wizcard,.fbtn,#toast,#side){border-width:1.5px 3px 3px 1.5px!important}F :is(.btn,.sv,.pcard){border-radius:14px!important}F .btn.on,F .btn.pri{background:#111!important;color:#f0f0ea!important}F .btn:active{background:#111!important;color:#f0f0ea!important}F body,F .btn,F .menu,F .dlg,F .hero p,F .fbtn small{font-family:"Noto Serif",Georgia,"Times New Roman",serif}F .dlg h3,F .panel h3,F .fbtn h2{font-family:"Noto Serif",Georgia,serif;font-weight:700}F input.t,F textarea.t{border:1.5px solid #1a1a1a!important;background:#d3d3ca!important}');
    t.prev = 'background:' + cap + ',#e4e4dc;box-shadow:inset 0 0 0 1.5px #1a1a1a,3px 3px 0 #1a1a1a;border-radius:10px';
  });
  T('holo', function (t) {  /* iridescent foil: a spectral sheen that travels across every surface */
    var sp = 'linear-gradient(115deg,rgba(120,230,250,.28) 0,rgba(180,150,255,.26) 25%,rgba(255,170,220,.26) 50%,rgba(255,235,150,.24) 75%,rgba(120,230,250,.28) 100%)';
    LAY(t, '--L-bg', [grain(1.1, .1, [.5, .4, .9], { k: 1.2, b: -.4, size: 140 }), sp, 'linear-gradient(105deg,transparent 30%,rgba(255,255,255,.55) 45%,transparent 58%)']);
    LAY(t, '--S-bg', [sp, 'linear-gradient(105deg,transparent 30%,rgba(255,255,255,.6) 46%,transparent 60%)']);
    t.tok['--page-bg'] = 'conic-gradient(from 120deg at 20% 15%,rgba(120,230,250,.35),rgba(180,150,255,.35),rgba(255,170,220,.35),rgba(255,235,150,.3),rgba(120,230,250,.35)),radial-gradient(60% 45% at 10% 0,rgba(255,255,255,.7),transparent 70%),#e8e6f4';
    css('holo', 'F ' + BIG + '{border-radius:34px!important;border:1px solid rgba(255,255,255,.9)!important;box-shadow:var(--L-sh),0 0 0 1px rgba(150,130,230,.22)!important}F ' + BTN + ':not(.on):not(.pri){border:1px solid rgba(255,255,255,.9)!important}');
    t.prev = 'background:linear-gradient(105deg,transparent 30%,rgba(255,255,255,.7) 46%,transparent 60%),linear-gradient(120deg,rgba(110,231,249,.8),rgba(167,139,250,.8) 40%,rgba(249,168,212,.8) 70%,rgba(253,230,138,.8)),#eee;box-shadow:inset 0 0 0 1px rgba(255,255,255,.9)';
  });
  T('sumi', function (t) {  /* ink wash on washi: bleeding ink, vermilion seal, brush underline */
    var wash = 'radial-gradient(38% 28% at 14% 10%,rgba(30,28,24,.28),rgba(30,28,24,.1) 55%,transparent 75%),radial-gradient(30% 22% at 88% 92%,rgba(30,28,24,.22),transparent 72%),radial-gradient(22% 14% at 70% 6%,rgba(30,28,24,.12),transparent 70%)';
    var fibre = brush(.7, .02, .22, [.35, .3, .22], { k: 1.5, b: -.45, seed: 3 }) + ',' + grain(.6, .2, [.4, .35, .25], { k: 1.2, b: -.45, size: 220 });
    LAY(t, '--L-bg', [grain(.6, .22, [.4, .35, .25], { k: 1.2, b: -.45, size: 220 })]); LAY(t, '--S-bg', [grain(.6, .18, [.4, .35, .25], { k: 1.2, b: -.45, size: 220 })]);
    t.tok['--page-bg'] = wash + ',' + fibre + ',#ebe5d6';
    t.tok['--ON-bg'] = 'linear-gradient(180deg,#c8341f,#9c2414)'; t.tok['--PRI-bg'] = t.tok['--ON-bg']; t.tok['--SEL-bg'] = t.tok['--ON-bg']; t.tok['--ON-c'] = t.tok['--PRI-c'] = t.tok['--SEL-c'] = '#fbeee0'; t.tok['--SEL-solid'] = '#c8341f'; t.tok['--SELS-c'] = '#f6cfc0';
    t.tok['--ON-sh'] = '0 2px 6px rgba(120,25,12,.4),inset 0 0 0 1px rgba(255,200,180,.25)';
    css('sumi', 'F ' + BIG + '{border-radius:26px 10px 26px 10px!important}F ' + BTN + '{border-radius:20px 8px 20px 8px!important}F .ddp{border-radius:20px 8px 20px 8px!important}F .dlg h3,F .panel h3,F .fbtn h2,F .hero p{font-family:"Noto Serif",Georgia,serif;font-weight:600;letter-spacing:.04em}F :is(.dlg,.panel,.wizcard) h3::after{content:"";display:block;height:3px;width:46px;margin-top:6px;border-radius:2px;background:linear-gradient(90deg,#15130f,rgba(21,19,15,.15))}F :is(.btn.on,.btn.pri){border-radius:10px 20px 10px 20px!important}');
    t.prev = 'background:radial-gradient(60% 70% at 25% 30%,rgba(30,28,24,.55),transparent 70%),radial-gradient(40% 50% at 82% 82%,rgba(30,28,24,.3),transparent 70%),#efe9db;border-radius:12px 4px 12px 4px';
  });

  /* regenerate the token blocks (themes.js already wrote its own; this one comes later in the cascade and replaces the changed properties) */
  TH.list.forEach(function (t) { if (t.prev && !/^\s*background/i.test(t.prev)) t.prev = 'background:' + t.prev; });
  var out = '';
  TH.list.forEach(function (t) { if (!U[t.family]) return; out += 'html[data-dyn=' + t.family + ']{' + Object.keys(t.tok).map(function (n) { return n + ':' + t.tok[n]; }).join(';') + '}\n' + U[t.family] + '\n'; });
  var st = document.createElement('style'); st.id = 'dyn-plus'; st.textContent = out; document.head.appendChild(st);
})();
