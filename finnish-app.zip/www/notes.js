/* Notes – a separate full-screen rich-text canvas (own storage, same look, theme, language and speech as the script editor). */
(function () {
  'use strict';
  var A = THK.app, el = A.el, esc = A.esc, $ = A.$, S = A.S, N = THK.notes = {};
  var lastHtml = null, lastTitle = null, note = null, ed = null, saved = null, active = false, tmr = 0, status = 'saved', dirtyFlag = false, fmtOpen = false, fmtPanel = null, tl = { buf: '', len: 0, node: null, off: -1 };
  var SIZES = [12, 14, 16, 18, 20, 24, 28, 32, 40, 48];
  var INKS = ['#111111', '#d32f2f', '#e8590c', '#e0a800', '#2f9e44', '#1c7ed6', '#6741d9', '#c2255c', '#7a7a7a', '#ffffff'];
  var HILITES = ['#fff3a3', '#ffd8a8', '#ffc9c9', '#d3f9d8', '#c5f6fa', '#d0ebff', '#e5dbff', '#eaeaea'];
  var PAPERS = [['#ffffff', 'White'], ['#fbf6e9', 'Cream'], ['#eef2f7', 'Mist'], ['#e9f3ec', 'Sage'], ['#25272e', 'Slate'], ['#000000', 'Black']];

  /* ---------------------------------------------------------------- storage (own database – never mixed with scripts) */
  var DB = {
    db: null,
    init: function () {
      return new Promise(function (res) {
        if (DB.db) return res();
        try { var r = indexedDB.open('finnish-notes', 1); r.onupgradeneeded = function () { r.result.createObjectStore('notes', { keyPath: 'id' }); }; r.onsuccess = function () { DB.db = r.result; res(); }; r.onerror = r.onblocked = function () { res(); }; } catch (e) { res(); }
      });
    },
    all: function () {
      return DB.init().then(function () {
        var ls = []; try { for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k.indexOf('finnish.note.') === 0) ls.push(JSON.parse(localStorage.getItem(k))); } } catch (e) { }
        if (!DB.db) return ls;
        return new Promise(function (res) { var q = DB.db.transaction('notes').objectStore('notes').getAll(); q.onsuccess = function () { var m = {}; q.result.concat(ls).forEach(function (n) { if (!m[n.id] || m[n.id].updated < n.updated) m[n.id] = n; }); res(Object.keys(m).map(function (k) { return m[k]; })); }; q.onerror = function () { res(ls); }; });
      });
    },
    get: function (id) {
      return DB.init().then(function () {
        var l = null; try { var r = localStorage.getItem('finnish.note.' + id); if (r) l = JSON.parse(r); } catch (e) { }
        if (!DB.db) return l;
        return new Promise(function (res) { var q = DB.db.transaction('notes').objectStore('notes').get(id); q.onsuccess = function () { var v = q.result; res(v && l ? (l.updated > v.updated ? l : v) : v || l); }; q.onerror = function () { res(l); }; });
      });
    },
    /* light list for the vault window: one record at a time through a cursor, only the fields the list needs (never holds every picture / recording in memory) */
    list: function () {
      function meta(n) {
        var h = n.html || '', pics = (h.match(/class="ntimg/g) || []).length, auds = (h.match(/class="ntaud/g) || []).length;
        var sn = h.replace(/<(img|audio)\b[^>]*>/gi, ' ').replace(/<\/(p|div|li|h\d)>/gi, ' ').replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim().slice(0, 90);
        return { id: n.id, title: n.title || '', updated: n.updated || 0, sn: sn, pics: pics, auds: auds };
      }
      return DB.init().then(function () {
        var m = {}; function add(x) { if (!m[x.id] || m[x.id].updated < x.updated) m[x.id] = x; }
        try { for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k.indexOf('finnish.note.') === 0) add(meta(JSON.parse(localStorage.getItem(k)))); } } catch (e) { }
        var fin = function () { return Object.keys(m).map(function (k) { return m[k]; }).sort(function (a, b) { return b.updated - a.updated; }); };
        if (!DB.db) return fin();
        return new Promise(function (res) { var c = DB.db.transaction('notes').objectStore('notes').openCursor(); c.onsuccess = function () { var cu = c.result; if (cu) { add(meta(cu.value)); cu.continue(); } else res(fin()); }; c.onerror = function () { res(fin()); }; });
      });
    },
    put: function (n) {
      return DB.init().then(function () {
        if (!DB.db) { try { localStorage.setItem('finnish.note.' + n.id, JSON.stringify(n)); } catch (e) { } return; }
        return new Promise(function (res) { try { var tx = DB.db.transaction('notes', 'readwrite'); tx.objectStore('notes').put(n); tx.oncomplete = function () { res(); }; tx.onerror = tx.onabort = function () { try { localStorage.setItem('finnish.note.' + n.id, JSON.stringify(n)); } catch (e) { } res(); }; } catch (e) { res(); } });
      });
    },
    del: function (id) {
      try { localStorage.removeItem('finnish.note.' + id); } catch (e) { }
      return DB.init().then(function () { if (!DB.db) return; return new Promise(function (res) { var tx = DB.db.transaction('notes', 'readwrite'); tx.objectStore('notes').delete(id); tx.oncomplete = tx.onerror = function () { res(); }; }); });
    }
  };
  N.DB = DB;

  function blank() {
    var L = THK.lang(S.lang), fo = L.id === 'en' && THK.FONTS.some(function (f) { return f.id === 'Inter'; }) ? 'Inter' : L.def;
    return { id: A.uid(), title: '', html: '', lang: L.id, font: fo, size: 18, lh: 1.6, paper: '#ffffff', created: Date.now(), updated: Date.now() };
  }
  function isEmpty(n) { return !n.title && !/\S/.test((n.html || '').replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ')) && !/<img|<li/i.test(n.html || ''); }
  function lum(hex) { var m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return 1; var v = parseInt(m[1], 16); return (0.299 * (v >> 16) + 0.587 * ((v >> 8) & 255) + 0.114 * (v & 255)) / 255; }

  /* keep the whole vault screen (and so its bottom toolbar) inside the visible area: the toolbar rides on top of the keyboard, as in the script editor */
  (function () {
    var vv = window.visualViewport, nt = null;
    function fit() {
      nt = nt || document.getElementById('nt'); if (!nt || nt.hidden || !vv) return;
      nt.style.bottom = 'auto'; nt.style.height = vv.height + 'px'; nt.style.top = (vv.offsetTop || 0) + 'px';
      if (document.activeElement === ed && ed) { var a = getSelection(); if (a.rangeCount) { var r = a.getRangeAt(0).getBoundingClientRect(); var w = document.getElementById('nScroll'); if (w && r && r.height) { var wb = w.getBoundingClientRect(); if (r.bottom > wb.bottom - 8) w.scrollTop += r.bottom - wb.bottom + 24; } } }
    }
    if (vv) { vv.addEventListener('resize', fit); vv.addEventListener('scroll', fit); }
    window.addEventListener('scroll', function () { if (nt && !nt.hidden) window.scrollTo(0, 0); });
    document.addEventListener('focusin', function () { setTimeout(fit, 0); setTimeout(fit, 250); });
  })();

  /* ---------------------------------------------------------------- screen */
  function build() {
    var T = $('#nTop'), P = $('#nPage'), AC = $('#nAcc'); if (T.dataset.ok) return; T.dataset.ok = 1; ed = P;
    ed.addEventListener('pointerdown', function () { ed.dataset.tapped = 1; setTimeout(function () { delete ed.dataset.tapped; }, 600); }); ed.contentEditable = 'true'; ed.spellcheck = false; ed.className = 'nted'; ed.setAttribute('data-ph', 'Got an idea? Write a beat, a scene, a line of dialogue…'); ed.setAttribute('role', 'textbox'); ed.setAttribute('aria-multiline', 'true');
    var home = el('button', 'btn', 'Home'); home.onclick = N.close;
    var tt = el('div', 'ttl'); var ti = el('input', 'ntti'); ti.id = 'ntTitle'; ti.placeholder = 'Untitled idea'; ti.maxLength = 80; ti.setAttribute('aria-label', 'Note title');
    ti.oninput = function () { note.title = ti.value; touch(); }; ti.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); ti.blur(); ed.focus(); } };
    var sv = el('small', ''); sv.id = 'ntsv'; tt.appendChild(ti); tt.appendChild(sv);
    var more = el('button', 'btn', 'More'); more.onclick = function (e) { moreMenu(e.currentTarget); };
    T.appendChild(home); T.appendChild(tt); T.appendChild(more);
    var pc = el('button', 'btn', 'Picture'); pc.id = 'ntPic'; pc.onmousedown = function (e) { e.preventDefault(); }; pc.onclick = addPicture;
    var rc = el('button', 'btn', 'Record'); rc.id = 'ntRec'; rc.onmousedown = function (e) { e.preventDefault(); }; rc.onclick = recToggle;
    var vb = el('button', 'btn', 'Vault'); vb.id = 'ntVault'; vb.onclick = savedDlg;
    var sp = el('button', 'btn', 'Speak'); sp.id = 'ntSpeak'; sp.title = 'Speak to type – writes in the language chosen on the right'; sp.onmousedown = function (e) { e.preventDefault(); }; sp.onclick = dictate;
    var fm = el('button', 'btn', 'Format'); fm.id = 'ntFmtBtn'; fm.onmousedown = function (e) { e.preventDefault(); }; fm.onclick = toggleFmt;
    var lg = el('button', 'btn', ''); lg.id = 'ntLang'; lg.title = 'Writing language'; lg.onmousedown = function (e) { e.preventDefault(); }; lg.onclick = function (e) { A.langMenu(e.currentTarget); };
    AC.appendChild(vb); AC.appendChild(sp); AC.appendChild(pc); AC.appendChild(rc); AC.appendChild(fm); AC.appendChild(lg);
    wire();
  }
  function setStatus(s) { status = s; var e = $('#ntsv'); if (e) { e.textContent = s === 'saved' ? '● Saved' : '○ Saving…'; e.style.color = s === 'saved' ? '#30d158' : '#ff9f0a'; } }
  function touch() { dirtyFlag = true; setStatus('saving'); clearTimeout(tmr); tmr = setTimeout(persist, (lastHtml && lastHtml.length > 400000) ? 1600 : 650); }
  function persist() {
    clearTimeout(tmr); if (!note) return Promise.resolve();
    var h = ed.innerHTML; if (h === lastHtml && note.title === lastTitle && !dirtyFlag) return Promise.resolve();
    note.html = h; note.updated = Date.now(); lastHtml = h; lastTitle = note.title;
    if (isEmpty(note)) { dirtyFlag = false; setStatus('saved'); return DB.del(note.id); }
    return DB.put(note).then(function () { dirtyFlag = false; setStatus('saved'); try { S.lastNote = note.id; A.saveS(); } catch (e) { } });
  }
  function look() {
    if (!note) return; var L = THK.lang(note.lang || S.lang), s = $('#nt').style, dark = lum(note.paper) < 0.45;
    THK.loadFont(note.font);
    s.setProperty('--pagec', note.paper || '#fff'); s.setProperty('--textc', dark ? '#f2f2f2' : '#101010'); s.setProperty('--ntf', THK.fontStack(note.font)); s.setProperty('--ntfs', (note.size || 18) + 'px'); s.setProperty('--ntlh', note.lh || 1.6);
    ed.dir = L.rtl ? 'rtl' : 'ltr'; ed.lang = L.bcp || 'en';
    var l = $('#ntLang'); if (l) { l.textContent = THK.lang(S.lang).native; l.classList.toggle('on', !!S.ml); }
  }
  function load(n) {
    note = n; saved = null; ed.innerHTML = n.html || ''; [].forEach.call(ed.querySelectorAll('audio'), function (a) { a.preload = 'none'; }); $('#ntTitle').value = n.title || ''; look(); setStatus('saved'); dirtyFlag = false; lastHtml = n.html || ''; lastTitle = n.title; tl.buf = ''; $('#nScroll').scrollTop = 0; if (fmtOpen) drawFmt();
  }
  N.open = function (id) {
    build(); active = true; A.show('nt');
    var go = function (n) { load(n); };
    DB.all().then(function (all) {
      all.sort(function (a, b) { return b.updated - a.updated; });
      var n = (id && all.filter(function (x) { return x.id === id; })[0]) || blank();
      go(n);
    });
  };
  N.back = function () {
    if (diceEl) { diceClose(true); return true; }
    if (rec) { recStop(true); return true; }
    if (fmtOpen) { closeFmt(); return true; }
    N.close(); return true;
  };
  N.close = function () {
    if (rec) recStop(true);
    var fin = function () { active = false; closeFmt(); A.renderHome(); }; if (!note) return fin();
    persist().then(fin);
  };
  N.onLang = function () {
    if (!active || !note) return; var L = THK.lang(S.lang); note.lang = L.id;
    if (!THK.fontsFor(L.id, false).some(function (f) { return f.id === note.font; })) note.font = L.def;
    look(); if (fmtOpen) drawFmt(); touch();
  };
  THK.phon = { type: function (c) { phon(c); }, back: function () { phonBack(); }, st: tl };
  N.refresh = function () { if (active && note) look(); };
  N.newNote = function () { persist().then(function () { load(blank()); }); };

  /* ---------------------------------------------------------------- editing */
  function wire() {
    document.addEventListener('selectionchange', function () {
      if (!active) return; var s = getSelection(); if (!s.rangeCount) return; var r = s.getRangeAt(0); if (ed.contains(r.commonAncestorContainer)) { saved = r.cloneRange(); if (fmtOpen) refreshState(); }
    });
    ed.addEventListener('input', function () { touch(); caretIntoView(); if (fmtOpen) refreshState(); });
    ed.addEventListener('paste', function (e) { e.preventDefault(); var t = (e.clipboardData || window.clipboardData).getData('text/plain'); if (t) document.execCommand('insertText', false, t); });
    ed.addEventListener('keydown', onKey);
    ed.addEventListener('beforeinput', function (e) { if (e.inputType === 'insertFromDrop') e.preventDefault(); });
    ed.addEventListener('click', function (e) {
      var li = e.target.closest && e.target.closest('ul.ckl > li'); if (!li || !ed.contains(li)) return;
      var r = li.getBoundingClientRect(), x = (document.documentElement.dir === 'rtl' || ed.dir === 'rtl') ? r.right - e.clientX : e.clientX - r.left;
      if (x < 30) { li.classList.toggle('done'); touch(); }
    });
    ed.addEventListener('click', function (e) {
      var m = e.target.closest && e.target.closest('.ntimg,.ntaud'); if (!m || !ed.contains(m)) return;
      var r = m.getBoundingClientRect(); if (e.clientX < r.right - 46 || e.clientX > r.right + 2 || e.clientY > r.top + 46 || e.clientY < r.top - 2) return;
      e.preventDefault(); e.stopPropagation(); mediaMenu(m, { getBoundingClientRect: function () { return { left: r.right - 36, right: r.right - 6, top: r.top + 6, bottom: r.top + 36, width: 30, height: 30 }; } });
    }, true);
    ed.addEventListener('blur', function () { if (dirtyFlag) persist(); });
    document.addEventListener('visibilitychange', function () { if (active && document.hidden && dirtyFlag) persist(); });
    window.addEventListener('pagehide', function () { if (active && dirtyFlag) persist(); });
  }
  function caretIntoView() {
    var s = getSelection(); if (!s.rangeCount) return; var r = s.getRangeAt(0).cloneRange(); r.collapse(false); var b = r.getClientRects()[0] || (r.startContainer.nodeType === 1 && r.startContainer.getBoundingClientRect()); if (!b) return;
    var sc = $('#nScroll'), sr = sc.getBoundingClientRect(), pad = fmtOpen ? 20 : 70;
    if (b.bottom > sr.bottom - pad) sc.scrollTop += b.bottom - sr.bottom + pad; else if (b.top < sr.top + 10) sc.scrollTop -= sr.top - b.top + 20;
  }
  function onKey(e) {
    var mod = e.ctrlKey || e.metaKey, k = e.key;
    if (mod) {
      var l = k.toLowerCase();
      if (l === 's') { e.preventDefault(); return e.shiftKey ? saveAs() : save(); }
      if (l === 'b' || l === 'i' || l === 'u') { e.preventDefault(); return cmd({ b: 'bold', i: 'italic', u: 'underline' }[l]); }
      if (k === ' ') { e.preventDefault(); return A.langMenu($('#ntLang')); }
      return;
    }
    if (k.length === 1 && S.ml && /[A-Za-z]/.test(k) && !e.altKey) { e.preventDefault(); return phon(k); }
    if (k === 'Backspace' && tl.buf) { var s = getSelection(); if (s.rangeCount && s.anchorNode === tl.node && s.anchorOffset === tl.off && s.isCollapsed) { e.preventDefault(); return phonBack(); } }
    tl.buf = '';
  }
  /* phonetic typing (English letters → the chosen language), same engine as inside the script editor */
  function phon(ch) {
    var s = getSelection(); if (!s.rangeCount) return; var r = s.getRangeAt(0);
    if (!r.collapsed) { document.execCommand('delete'); tl.buf = ''; tl.len = 0; s = getSelection(); r = s.getRangeAt(0); }
    var n = r.startContainer, o = r.startOffset;
    if (tl.node !== n || tl.off !== o || !tl.buf) { tl.buf = ''; tl.len = 0; }
    tl.buf += ch; var out = A.trFn()(tl.buf);
    if (tl.len && n.nodeType === 3 && o >= tl.len) { r.setStart(n, o - tl.len); s.removeAllRanges(); s.addRange(r); }
    document.execCommand('insertText', false, out); tl.len = out.length; s = getSelection(); tl.node = s.anchorNode; tl.off = s.anchorOffset;
  }
  function phonBack() {
    var s = getSelection(), r = s.getRangeAt(0), n = r.startContainer, o = r.startOffset; tl.buf = tl.buf.slice(0, -1); var out = tl.buf ? A.trFn()(tl.buf) : '';
    if (n.nodeType === 3 && o >= tl.len) { r.setStart(n, o - tl.len); s.removeAllRanges(); s.addRange(r); }
    if (out) document.execCommand('insertText', false, out); else document.execCommand('delete');
    tl.len = out.length; s = getSelection(); tl.node = s.anchorNode; tl.off = s.anchorOffset; if (!tl.buf) tl.node = null;
  }
  /* the keyboard opens only when the writer taps the page: a button that needs the editor focused for a moment does it silently (inputmode none) and lets go again */
  function focusEd() {
    if (document.activeElement !== ed) {
      ed.setAttribute('inputmode', 'none'); ed.focus({ preventScroll: true });
      setTimeout(function () { if (document.activeElement === ed && !ed.dataset.tapped) ed.blur(); ed.removeAttribute('inputmode'); }, 0);
    }
    if (saved) { var s = getSelection(); s.removeAllRanges(); try { s.addRange(saved); } catch (e) { } }
  }
  function cmd(c, v) { if (!note) return; focusEd(); try { document.execCommand('styleWithCSS', false, c !== 'fontSize'); } catch (e) { } document.execCommand(c, false, v == null ? null : v); touch(); if (fmtOpen) refreshState(); }
  function hasSel() { var s = getSelection(); return s.rangeCount && !s.isCollapsed && ed.contains(s.getRangeAt(0).commonAncestorContainer); }
  function setSize(px) {
    px = Math.max(8, Math.min(120, Math.round(px)));
    focusEd();
    if (hasSel()) {
      document.execCommand('styleWithCSS', false, false); document.execCommand('fontSize', false, '7');
      var made = [];
      [].forEach.call(ed.querySelectorAll('font[size="7"]'), function (f) { var sp = document.createElement('span'); sp.style.fontSize = px + 'px'; while (f.firstChild) sp.appendChild(f.firstChild); f.parentNode.replaceChild(sp, f); made.push(sp); });
      [].forEach.call(ed.querySelectorAll('span[style*="font-size"] span[style*="font-size"]'), function (s2) { s2.style.fontSize = ''; });
      if (made.length) { var rg = document.createRange(); rg.setStartBefore(made[0]); rg.setEndAfter(made[made.length - 1]); var sl = getSelection(); sl.removeAllRanges(); sl.addRange(rg); saved = rg.cloneRange(); }
      touch();
    } else { note.size = px; look(); touch(); }
    if (fmtOpen) refreshState();
  }
  function setFont(f) {
    THK.loadFont(f.id); focusEd();
    if (hasSel()) { document.execCommand('styleWithCSS', false, true); document.execCommand('fontName', false, THK.fontStack(f.id)); touch(); }
    else { note.font = f.id; look(); touch(); }
    if (fmtOpen) refreshState();
  }
  function list(kind) {
    focusEd(); document.execCommand('styleWithCSS', false, false);
    if (kind === 'check') {
      var ul = closest('ul'); if (ul && ul.classList.contains('ckl')) { document.execCommand('insertUnorderedList'); touch(); return; }
      if (!ul) document.execCommand('insertUnorderedList'); ul = closest('ul'); if (ul) ul.classList.add('ckl');
    } else {
      document.execCommand(kind === 'ol' ? 'insertOrderedList' : 'insertUnorderedList');
      var u = closest('ul'); if (u) u.classList.remove('ckl');
    }
    touch(); if (fmtOpen) refreshState();
  }
  function closest(tag) { var s = getSelection(); if (!s.rangeCount) return null; var n = s.anchorNode; while (n && n !== ed) { if (n.nodeType === 1 && n.nodeName.toLowerCase() === tag) return n; n = n.parentNode; } return null; }
  function block(tag) { focusEd(); document.execCommand('formatBlock', false, tag); touch(); if (fmtOpen) refreshState(); }

  /* ---------------------------------------------------------------- speak */
  function dictate() {
    if (!note) return; var L = THK.lang(S.lang), lang = (THK.LOC || {})[S.lang] || 'en-IN', FP = THK.fp(), f = FP && FP.dictate ? FP : null, b = $('#ntSpeak');
    var st = function (on) { b.classList.toggle('on', on); b.textContent = on ? 'Listening…' : 'Speak'; };
    if (b.classList.contains('on')) return;
    var put = function (t) { if (!t) return A.toast('Nothing was heard'); var tb = textBefore(); putText((/\s$/.test(tb) || !tb ? '' : ' ') + t); };
    if (f) { st(true); return f.dictate({ lang: lang, prompt: 'Speak in ' + L.name }).then(function (r) { st(false); put(r && r.text); }).catch(function (e) { st(false); if (!e || !/cancel/i.test(String(e.message || e))) A.toast('Speech recognition for ' + L.name + ' is not available on this device – install its voice in Google speech settings'); }); }
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR) return A.toast('Speaking to type needs the Android app or a browser with speech recognition');
    var rec = new SR(); rec.lang = lang; rec.interimResults = false; rec.maxAlternatives = 1; st(true);
    rec.onresult = function (e) { put(e.results[0][0].transcript); }; rec.onerror = function () { st(false); A.toast('Could not hear anything'); }; rec.onend = function () { st(false); };
    try { rec.start(); } catch (er) { st(false); A.toast('Speaking could not start'); }
  }
  function textBefore() { var n, o, s = getSelection(); if (document.activeElement === ed && s.rangeCount && ed.contains(s.anchorNode)) { n = s.anchorNode; o = s.anchorOffset; } else if (saved && ed.contains(saved.startContainer)) { n = saved.startContainer; o = saved.startOffset; } else return ''; return n.nodeType === 3 ? n.textContent.slice(0, o) : ''; }

  /* ---------------------------------------------------------------- format panel */
  function toggleFmt() { fmtOpen ? closeFmt() : openFmt(); }
  function openFmt() { fmtOpen = true; var p = $('#nFmt'); p.hidden = false; drawFmt(); $('#ntFmtBtn').classList.add('on'); }
  function closeFmt() { fmtOpen = false; var p = $('#nFmt'); if (p) p.hidden = true; var b = $('#ntFmtBtn'); if (b) b.classList.remove('on'); }
  function pill(t, fn, cls, title) { var b = el('button', 'btn sm ' + (cls || ''), esc(t)); b.type = 'button'; b.onmousedown = function (e) { e.preventDefault(); }; b.onclick = fn; if (title) b.title = title; return b; }
  function sec(p, t, sub) { p.appendChild(el('div', 'nfh', esc(t) + (sub ? ' <small>' + esc(sub) + '</small>' : ''))); var r = el('div', 'nfr'); p.appendChild(r); return r; }
  function sw(c, fn) { var b = el('button', 'sw'); b.type = 'button'; b.style.background = c; b.title = c; b.onmousedown = function (e) { e.preventDefault(); }; b.onclick = fn; return b; }
  function drawFmt() {
    var p = $('#nFmt'); p.innerHTML = ''; var L = THK.lang(S.lang);
    var top = el('div', 'nft', '<b>Format</b><span>Select text to style only that part. With nothing selected, font and size change the whole note.</span>'); var x = pill('Close', closeFmt, 'pri'); top.appendChild(x); p.appendChild(top);
    var body = el('div', 'nfb'); p.appendChild(body); fmtPanel = body;
    var add = function (t, sub) { return sec(body, t, sub); };
    /* font – only fonts that suit the chosen language, then Latin ones for mixed writing */
    var r = add('Font', L.name); r.classList.add('nff');
    var mine = THK.fontsFor(S.lang, false); if (S.lang !== 'en') mine = mine.concat(THK.fontsFor('en', false).filter(function (f) { return !mine.some(function (m) { return m.id === f.id; }); }).slice(0, 8));
    mine.forEach(function (f) { var b = pill(f.label, function () { setFont(f); }, 'nfont', f.label); b.dataset.f = f.id; b.style.fontFamily = f.stack; THK.loadFont(f.id); r.appendChild(b); });
    r = add('Size'); r.classList.add('nsz');
    var cur = el('span', 'nsv', '18'); cur.id = 'ntSz';
    r.appendChild(pill('A−', function () { setSize(curSize() - 2); }, 'nstep')); r.appendChild(cur); r.appendChild(pill('A+', function () { setSize(curSize() + 2); }, 'nstep'));
    var r2 = el('div', 'nfr'); body.appendChild(r2); SIZES.forEach(function (n) { var b = pill(String(n), function () { setSize(n); }, 'nsmall'); b.dataset.z = n; r2.appendChild(b); });
    r = add('Style');
    [['B', 'bold', 'Bold', 'fb-b'], ['I', 'italic', 'Italic', 'fb-i'], ['U', 'underline', 'Underline', 'fb-u'], ['S', 'strikeThrough', 'Strikethrough', 'fb-s'], ['x²', 'superscript', 'Superscript', ''], ['x₂', 'subscript', 'Subscript', '']].forEach(function (s) { var b = pill(s[0], function () { cmd(s[1]); }, 'nicon ' + s[3], s[2]); b.dataset.c = s[1]; r.appendChild(b); });
    r = add('Heading');
    [['Title', 'h1'], ['Heading', 'h2'], ['Subheading', 'h3'], ['Body', 'p']].forEach(function (h) { var b = pill(h[0], function () { block(h[1]); }); b.dataset.h = h[1]; r.appendChild(b); });
    r = add('Alignment');
    [['Left', 'justifyLeft'], ['Centre', 'justifyCenter'], ['Right', 'justifyRight'], ['Justify', 'justifyFull']].forEach(function (a) { var b = pill(a[0], function () { cmd(a[1]); }); b.dataset.c = a[1]; r.appendChild(b); });
    r = add('Lists & indent');
    [['• Bullets', function () { list('ul'); }, 'ul'], ['1. Numbers', function () { list('ol'); }, 'ol'], ['☑ Checklist', function () { list('check'); }, 'ck'], ['Indent', function () { cmd('indent'); }], ['Outdent', function () { cmd('outdent'); }]].forEach(function (a) { var b = pill(a[0], a[1]); if (a[2]) b.dataset.l = a[2]; r.appendChild(b); });
    r = add('Text colour'); r.classList.add('nsw');
    INKS.forEach(function (c) { r.appendChild(sw(c, function () { cmd('foreColor', c); })); });
    var ci = el('input'); ci.type = 'color'; ci.className = 'swc'; ci.value = '#d32f2f'; ci.title = 'Any colour'; ci.onchange = function () { cmd('foreColor', ci.value); }; ci.onmousedown = function () { if (!hasSel() && saved) { } }; r.appendChild(ci);
    r.appendChild(pill('Auto', function () { cmd('foreColor', note && lum(note.paper) < .45 ? '#f2f2f2' : '#101010'); }));
    r = add('Highlight'); r.classList.add('nsw');
    HILITES.forEach(function (c) { r.appendChild(sw(c, function () { cmd('hiliteColor', c); })); });
    r.appendChild(pill('None', function () { cmd('hiliteColor', 'transparent'); }));
    r = add('Spacing'); [['Tight', 1.3], ['Normal', 1.6], ['Relaxed', 1.9], ['Wide', 2.3]].forEach(function (s) { var b = pill(s[0], function () { note.lh = s[1]; look(); touch(); refreshState(); }); b.dataset.lh = s[1]; r.appendChild(b); });
    r = add('Paper'); r.classList.add('nsw');
    PAPERS.forEach(function (c) { var b = sw(c[0], function () { note.paper = c[0]; look(); touch(); refreshState(); }); b.dataset.p = c[0]; b.title = c[1]; r.appendChild(b); });
    r = add('Tools');
    r.appendChild(pill('Undo', function () { cmd('undo'); })); r.appendChild(pill('Redo', function () { cmd('redo'); })); r.appendChild(pill('Clear formatting', function () { cmd('removeFormat'); }));
    r.appendChild(pill('Insert date', function () { focusEd(); document.execCommand('insertText', false, new Date().toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' })); touch(); }));
    refreshState();
  }
  function curSize() { var s = getSelection(), n = s.rangeCount && s.anchorNode; if (n && ed.contains(n)) { n = n.nodeType === 3 ? n.parentNode : n; var v = parseFloat(getComputedStyle(n).fontSize); if (v) return Math.round(v); } return note ? note.size : 18; }
  function qs(c) { try { return document.queryCommandState(c); } catch (e) { return false; } }
  function refreshState() {
    if (!fmtPanel || !note) return; var q = function (s) { return [].slice.call(fmtPanel.querySelectorAll(s)); };
    q('[data-c]').forEach(function (b) { b.classList.toggle('on', qs(b.dataset.c)); });
    var sz = curSize(); var e = $('#ntSz'); if (e) e.textContent = sz; q('[data-z]').forEach(function (b) { b.classList.toggle('on', +b.dataset.z === sz); });
    var fam = ''; var s = getSelection(); if (s.rangeCount && ed.contains(s.anchorNode)) { var n = s.anchorNode.nodeType === 3 ? s.anchorNode.parentNode : s.anchorNode; fam = (getComputedStyle(n).fontFamily || '').split(',')[0].replace(/['"\s]/g, '').toLowerCase(); }
    q('[data-f]').forEach(function (b) { var f = THK.font(b.dataset.f), nm = f.stack.split(',')[0].replace(/['"\s]/g, '').toLowerCase(); b.classList.toggle('on', fam ? nm === fam : b.dataset.f === note.font); });
    var blk = closest('h1') ? 'h1' : closest('h2') ? 'h2' : closest('h3') ? 'h3' : 'p'; q('[data-h]').forEach(function (b) { b.classList.toggle('on', b.dataset.h === blk); });
    var ul = closest('ul'), ol = closest('ol'); q('[data-l]').forEach(function (b) { var k = b.dataset.l; b.classList.toggle('on', k === 'ck' ? !!(ul && ul.classList.contains('ckl')) : k === 'ul' ? !!(ul && !ul.classList.contains('ckl')) : !!ol); });
    q('[data-lh]').forEach(function (b) { b.classList.toggle('on', +b.dataset.lh === +note.lh); });
    q('[data-p]').forEach(function (b) { b.classList.toggle('on', b.dataset.p === note.paper); });
  }

  /* ---------------------------------------------------------------- More menu, files, export */
  function title() { return (note.title || '').trim() || 'Untitled idea'; }
  function save() { persist().then(function () { A.toast('Saved on this device ✓ – open it again from More › Saved notes'); }); }
  function saveAs() {
    A.ask('Save As', 'New name', title(), function (n) {
      if (!n) return; persist().then(function () { var c = JSON.parse(JSON.stringify(note)); c.id = A.uid(); c.title = n; c.created = c.updated = Date.now(); c.html = ed.innerHTML; return DB.put(c).then(function () { load(c); S.lastNote = c.id; A.saveS(); A.toast('Saved as “' + n + '”'); }); });
    }, 'Save');
  }
  function mediaMenu(m, anchor) {
    var isPic = m.classList.contains('ntimg');
    A.menu(anchor, [{ hd: isPic ? 'Picture' : 'Voice note' }, { l: isPic ? 'Delete picture' : 'Delete voice note', fn: function () { removeMedia(m, isPic); } }], true);
  }
  function removeMedia(m, isPic) {
    var par = m.parentNode, next = m.nextSibling; if (!par) return;
    var a = m.querySelector('audio'); if (a) { try { a.pause(); } catch (e) { } }
    m.remove(); touch();
    A.undoToast((isPic ? 'Picture' : 'Voice note') + ' deleted', function () {
      if (!ed) return; try { par.insertBefore(m, next && next.parentNode === par ? next : null); } catch (e) { ed.appendChild(m); } touch();
    });
  }
  function rename() { A.ask('Rename note', 'Title', note.title || '', function (n) { note.title = n || ''; $('#ntTitle').value = note.title; touch(); }, 'Rename'); }
  function del() {
    clearTimeout(tmr); var keep = JSON.parse(JSON.stringify(note)); keep.html = ed.innerHTML; var t0 = title();
    DB.del(keep.id).then(function () { dirtyFlag = false; load(blank()); A.undoToast('Deleted “' + t0 + '”', function () { DB.put(keep).then(function () { persist().then(function () { load(keep); }); }); }); });
  }
  function moreMenu(a) {
    var ae = document.activeElement; if (ae === ed || ae === $('#ntTitle')) ae.blur();
    A.menu(a, [
      { hd: 'Idea Vault' }, { l: 'New idea', fn: N.newNote }, { l: 'Saved ideas', fn: savedDlg }, { l: 'Story dice', fn: diceOpen }, { l: 'Beat sheet starter', fn: beatSheet },
      { hr: 1 }, { hd: 'File' }, { l: 'Save', k: 'Ctrl+S', fn: save }, { l: 'Save As', k: 'Ctrl+Shift+S', fn: saveAs }, { l: 'Rename', fn: rename },
      { hr: 1 }, { l: 'Export…', fn: exportDlg },
      { hr: 1 }, { l: 'Delete idea', fn: del }
    ], true);
  }
  function savedDlg() {
    persist().then(function () { return DB.list(); }).then(function (all) {
      var box = el('div', 'ntl'), listEl = el('div', 'ntlr'), d, shown = 0, q = '', STEP = 40;
      var more = el('button', 'btn ntmore', 'Show more'); more.type = 'button';
      var sr = null;
      if (all.length > 7) { sr = el('input', 'ntsearch'); sr.type = 'search'; sr.placeholder = 'Search ideas'; sr.setAttribute('aria-label', 'Search ideas'); sr.oninput = function () { q = sr.value.trim().toLowerCase(); draw(true); }; box.appendChild(sr); }
      box.appendChild(listEl); box.appendChild(more);
      function vis() { return q ? all.filter(function (n) { return ((n.title || 'Untitled idea') + ' ' + n.sn).toLowerCase().indexOf(q) >= 0; }) : all; }
      function row(n) {
        var t = (n.title || '').trim() || 'Untitled idea', cur = note && n.id === note.id, media = [];
        if (n.pics) media.push(n.pics + (n.pics > 1 ? ' pictures' : ' picture')); if (n.auds) media.push(n.auds + (n.auds > 1 ? ' voice notes' : ' voice note'));
        var r = el('div', 'sv' + (cur ? ' cur' : '')); r.innerHTML = '<div class="n"><b>' + esc(t) + '</b><small>' + esc(new Date(n.updated).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) + (cur ? ' · open now' : '') + (media.length ? ' · ' + media.join(', ') : '') + (n.sn ? ' · ' + n.sn : '')) + '</small></div>';
        var x = el('button', 'btn sm', 'Delete'); x.type = 'button';
        x.onclick = function (e) {
          e.stopPropagation();
          DB.get(n.id).then(function (full) {
            if (!full) return; var wasCur = note && n.id === note.id; if (wasCur) clearTimeout(tmr);
            return DB.del(n.id).then(function () {
              all.splice(all.indexOf(n), 1); if (wasCur) { dirtyFlag = false; load(blank()); } draw(true);
              A.undoToast('Deleted “' + t + '”', function () { DB.put(full).then(function () { all.push(n); all.sort(function (a, b) { return b.updated - a.updated; }); if (d && d.isConnected !== false && listEl.isConnected) draw(true); }); });
            });
          });
        };
        r.appendChild(x);
        r.onclick = function () { d.close(); persist().then(function () { return DB.get(n.id); }).then(function (full) { if (full) load(full); }); };
        return r;
      }
      function draw(reset) {
        var v = vis(); if (reset) { listEl.textContent = ''; shown = 0; }
        if (!v.length) { listEl.textContent = ''; listEl.appendChild(el('p', '', all.length ? 'Nothing matches.' : 'Your vault is empty. Anything you write is kept here automatically.')); more.hidden = true; return; }
        var fr = document.createDocumentFragment(); v.slice(shown, shown + STEP).forEach(function (n) { fr.appendChild(row(n)); }); shown = Math.min(v.length, shown + STEP); listEl.appendChild(fr);
        more.hidden = shown >= v.length;
      }
      more.onclick = function () { draw(false); };
      draw(true);
      d = A.dlg('Idea Vault', box, [{ l: 'Close' }], { nofocus: true });
    });
  }

  /* ---------------------------------------------------------------- pictures + voice recordings (kept inside the idea, offline) */
  /* insert at the remembered caret WITHOUT focusing the page, so the on-screen keyboard never pops up on its own */
  function atCaret() {
    var r = saved && ed.contains(saved.commonAncestorContainer) ? saved.cloneRange() : null;
    if (!r) { r = document.createRange(); r.selectNodeContents(ed); r.collapse(false); }
    return r;
  }
  function putHtml(h) {
    if (document.activeElement === ed) { if (saved) { try { var s = getSelection(); s.removeAllRanges(); s.addRange(saved); } catch (e) { } } if (!document.execCommand('insertHTML', false, h)) ed.insertAdjacentHTML('beforeend', h); touch(); return; }
    var r = atCaret(); r.deleteContents(); var fr = r.createContextualFragment(h), last = fr.lastChild; r.insertNode(fr);
    if (last) { r.setStartAfter(last); r.collapse(true); saved = r.cloneRange(); try { if (last.previousSibling && last.previousSibling.scrollIntoView) last.previousSibling.scrollIntoView({ block: 'nearest' }); } catch (e) { } }
    touch();
  }
  function putText(t) {
    if (document.activeElement === ed) { if (saved) { try { var s = getSelection(); s.removeAllRanges(); s.addRange(saved); } catch (e) { } } document.execCommand('insertText', false, t); touch(); return; }
    var r = atCaret(); r.deleteContents(); var tn = document.createTextNode(t); r.insertNode(tn); r.setStartAfter(tn); r.collapse(true); saved = r.cloneRange(); touch();
  }
  function addPicture() {
    if (!THK.img || !THK.img.pickFile) return A.toast('Pictures are not available');
    THK.img.pickFile(function (r) {
      var sel = 'center', body = el('div', ''), th = el('img', 'imgprev'); th.src = r.url; body.appendChild(th);
      body.appendChild(el('p', 'imgnote', esc(r.name) + ' · ' + r.w + '×' + r.h + ' px · original quality'));
      body.appendChild(el('p', '', 'Where should it sit?'));
      var row = el('div', 'imgplace'); [['left', 'Left'], ['center', 'Centre'], ['right', 'Right'], ['full', 'Full width']].forEach(function (p) { var b = el('button', 'btn' + (p[0] === sel ? ' on' : ''), p[1]); b.onclick = function () { sel = p[0]; [].forEach.call(row.children, function (c) { c.classList.remove('on'); }); b.classList.add('on'); }; row.appendChild(b); });
      body.appendChild(row);
      A.dlg('Add picture', body, [{ l: 'Cancel' }, { l: 'Add', cls: 'pri', fn: function () { putHtml('<div class="ntimg ia-' + sel + '" contenteditable="false"><img src="' + r.url + '" alt=""></div><div><br></div>'); } }], { nofocus: true });
    });
  }
  var rec = null;
  function fmtT(s) { return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
  function recToggle() { if (rec) return recStop(false); recStart(); }
  function recStart() {
    if (!navigator.mediaDevices || !window.MediaRecorder) return A.toast('Recording is not supported on this device');
    navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
      var chunks = [], mr; try { mr = new MediaRecorder(stream); } catch (e) { stream.getTracks().forEach(function (t) { t.stop(); }); return A.toast('Recording could not start'); }
      var t0 = Date.now(), b = $('#ntRec');
      rec = { mr: mr, stream: stream, cancel: false, tick: setInterval(function () { var s = Math.round((Date.now() - t0) / 1000); if (b) b.textContent = '● ' + fmtT(s) + ' Stop'; if (s >= 600) recStop(false); }, 400) };
      if (b) { b.classList.add('on'); b.textContent = '● 0:00 Stop'; }
      mr.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };
      mr.onstop = function () {
        var r = rec; rec = null; clearInterval(r.tick); r.stream.getTracks().forEach(function (t) { t.stop(); }); var bb = $('#ntRec'); if (bb) { bb.classList.remove('on'); bb.textContent = 'Record'; }
        if (r.cancel || !chunks.length) return;
        var blob = new Blob(chunks, { type: mr.mimeType || 'audio/webm' }), fr = new FileReader();
        fr.onload = function () { putHtml('<div class="ntaud" contenteditable="false"><audio controls preload="none" src="' + fr.result + '"></audio><small>Voice note · ' + fmtT(Math.round((Date.now() - t0) / 1000)) + '</small></div><div><br></div>'); };
        fr.readAsDataURL(blob);
      };
      mr.start();
    }).catch(function () { A.toast('Microphone permission is needed to record'); });
  }
  function recStop(cancel) { if (!rec) return; rec.cancel = !!cancel; try { rec.mr.stop(); } catch (e) { rec.mr.onstop(); } }
  function beatSheet() {
    var B = ['Opening image', 'Theme stated', 'Set-up', 'Catalyst', 'Debate', 'Break into two', 'B story', 'Fun and games', 'Midpoint', 'Bad guys close in', 'All is lost', 'Dark night of the soul', 'Break into three', 'Finale', 'Final image'];
    if (!note.title) { note.title = 'Beat sheet'; $('#ntTitle').value = note.title; }
    putHtml(B.map(function (t, i) { return '<h3>' + (i + 1) + '. ' + t + '</h3><div><br></div>'; }).join(''));
  }
  function plainClean() { var c = ed.cloneNode(true); [].forEach.call(c.querySelectorAll('.ntaud'), function (a) { a.replaceWith(Object.assign(document.createElement('p'), { textContent: '[Voice recording]' })); }); return c.innerHTML; }

  /* ---------------------------------------------------------------- story dice: five random words → the title, an exercise to connect them */
  var diceEl = null;
  function diceClose(keep) {
    if (!diceEl) return; var o = diceEl, words = o._w; diceEl = null; o.classList.add('out'); setTimeout(function () { o.remove(); }, 260);
    if (keep && words && words.length) { note.title = words.join(' · '); $('#ntTitle').value = note.title; touch(); if (THK.hap) THK.hap('ok'); }
  }
  function diceOpen() {
    if (diceEl || !THK.dice) return; var o = el('div', 'ntdice'), box = el('div', 'dbox'), cards = [], pool = THK.dice;
    o._w = pool.roll(5); diceEl = o;
    var hd = el('div', 'dhd', 'Connect the dots'); box.appendChild(hd);
    o._w.forEach(function (t, i) { var c = el('div', 'dcard'); c.style.setProperty('--i', i); c.innerHTML = '<span class="dn">' + (i + 1) + '</span><b></b>'; box.appendChild(c); cards.push(c); });
    var ft = el('div', 'dft'), again = el('button', 'btn', 'Roll again'); ft.appendChild(again); ft.appendChild(el('small', '', 'Tap outside to keep these as your title'));
    box.appendChild(ft); o.appendChild(box); document.body.appendChild(o);
    function shuffle() {
      var words = pool.roll(5); o._w = words;
      cards.forEach(function (c, i) {
        var tEnd = Date.now() + 420 + i * 150, b = c.querySelector('b'); c.classList.remove('set'); c.classList.add('spin');
        (function tick() { if (!diceEl || diceEl !== o) return; if (Date.now() < tEnd) { b.textContent = pool.roll(1)[0]; setTimeout(tick, 70); } else { b.textContent = words[i]; c.classList.remove('spin'); c.classList.add('set'); if (THK.hap) THK.hap('tick'); } })();
      });
    }
    again.onclick = function (e) { e.stopPropagation(); shuffle(); };
    o.onclick = function (e) { if (!box.contains(e.target)) diceClose(true); };
    box.onclick = function (e) { e.stopPropagation(); };
    shuffle();
  }
  function plainText() { return ed.innerText.replace(/ /g, ' ').replace(/\n{3,}/g, '\n\n'); }
  function fname() { return title().replace(/[\\\/:*?"<>|\n]+/g, ' ').trim() || 'note'; }
  function exportTxt() { persist().then(function () { A.deliver(fname() + '.txt', 'text/plain', toTxt()); }); }
  function pageCss() {
    var dark = lum(note.paper) < .45;
    return '@page{size:A4;margin:18mm 16mm}html,body{margin:0;background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}body{font-family:' + THK.fontStack(note.font) + ';font-size:' + (note.size * 0.75) + 'pt;line-height:' + note.lh + ';color:' + (dark ? '#111' : '#101010') + '}' +
      '.ntimg{display:flex;margin:.6em 0}.ntimg img{max-width:100%;height:auto}.ia-center{justify-content:center}.ia-right{justify-content:flex-end}.ia-full img{width:100%}h1{font-size:1.7em;margin:.4em 0}h2{font-size:1.35em;margin:.4em 0}h3{font-size:1.15em;margin:.4em 0}p,div{margin:0}ul,ol{margin:.3em 0;padding-left:1.5em}ul.ckl{list-style:none;padding-left:0}ul.ckl li{padding-left:1.6em;position:relative}ul.ckl li::before{content:"☐";position:absolute;left:0}ul.ckl li.done::before{content:"☑"}ul.ckl li.done{text-decoration:line-through;opacity:.6}.nt-title{font-size:1.9em;font-weight:700;margin:0 0 .6em}';
  }
  function usedFonts() { var h = ed.innerHTML, ids = [note.font]; THK.FONTS.forEach(function (f) { var nm = f.stack.split(',')[0].replace(/['"]/g, '').trim(); if (nm && h.indexOf(nm) >= 0 && ids.indexOf(f.id) < 0) ids.push(f.id); }); return ids; }
  function exportPdf() {
    persist().then(function () {
      var d = { title: fname(), lang: note.lang, font: note.font, paper: 'a4' }, html = THK.shell(d, pageCss(), (note.title ? '<div class="nt-title">' + esc(note.title) + '</div>' : '') + '<div>' + plainClean() + '</div>', usedFonts());
      try { THK.printRaw(html, d); } catch (e) { A.toast('PDF export failed: ' + e.message); }
    });
  }
  function exportHtml() {
    persist().then(function () { var d = { title: fname(), lang: note.lang, font: note.font, paper: 'a4' }; A.deliver(fname() + '.html', 'text/html', THK.shell(d, pageCss().replace(/@page\{[^}]*\}/, '') + 'body{max-width:780px;margin:24px auto;padding:0 16px}', (note.title ? '<div class="nt-title">' + esc(note.title) + '</div>' : '') + '<div>' + ed.innerHTML + '</div>', usedFonts())); });
  }

  /* ---------------------------------------------------------------- Export: one window, single files */
  function walkOut(root, fx) { // fx.{h,p,li,img,aud,text}; returns nothing, calls back in document order
    var BLOCK = /^(P|DIV|H1|H2|H3|H4|UL|OL|LI|BLOCKQUOTE)$/;
    function runs(node, st, out) {
      node.childNodes.forEach(function (c) {
        if (c.nodeType === 3) { if (c.textContent) out.push({ t: c.textContent, b: st.b, i: st.i, u: st.u, s: st.s, c: st.c, z: st.z, hl: st.hl }); return; }
        if (c.nodeType !== 1) return; var tg = c.nodeName;
        if (tg === 'BR') { out.push({ t: '\n', br: 1 }); return; }
        if (c.classList.contains('ntimg') || c.classList.contains('ntaud')) return;
        var n = Object.assign({}, st), sy = c.style || {};
        if (tg === 'B' || tg === 'STRONG' || /^(bold|[6-9]00)$/.test(sy.fontWeight)) n.b = 1;
        if (tg === 'I' || tg === 'EM' || sy.fontStyle === 'italic') n.i = 1;
        if (tg === 'U' || /underline/.test(sy.textDecoration || sy.textDecorationLine || '')) n.u = 1;
        if (tg === 'S' || tg === 'STRIKE' || /line-through/.test(sy.textDecoration || sy.textDecorationLine || '')) n.s = 1;
        if (tg === 'SUP') n.sup = 1; if (tg === 'SUB') n.sub = 1;
        if (sy.color) n.c = sy.color; if (sy.backgroundColor && sy.backgroundColor !== 'transparent') n.hl = sy.backgroundColor; if (sy.fontSize && /px$/.test(sy.fontSize)) n.z = parseFloat(sy.fontSize);
        runs(c, n, out);
      });
      return out;
    }
    function media(el0) { if (el0.classList.contains('ntimg')) { var im = el0.querySelector('img'); if (im) fx.img(im.getAttribute('src') || ''); return true; } if (el0.classList.contains('ntaud')) { var sm = el0.querySelector('small'); fx.aud(sm ? sm.textContent : 'Voice note'); return true; } return false; }
    function blockLike(c) { return [].some.call(c.childNodes, function (k) { return k.nodeType === 1 && (BLOCK.test(k.nodeName) || k.classList.contains('ntimg') || k.classList.contains('ntaud')); }); }
    function go(parent, ctx) {
      var pend = []; // loose inline content collected into one paragraph
      function flush() { if (pend.length) { var o = []; pend.forEach(function (n) { if (n.nodeType === 3) o.push({ t: n.textContent }); else { var tmp = document.createElement('div'); tmp.appendChild(n.cloneNode(true)); runs(tmp, {}, o); } }); fx.p(o, ctx); pend = []; } }
      parent.childNodes.forEach(function (c) {
        if (c.nodeType === 3) { if (c.textContent.trim() || pend.length) pend.push(c); return; }
        if (c.nodeType !== 1) return;
        if (media(c)) { flush(); return; }
        var tg = c.nodeName;
        if (tg === 'UL' || tg === 'OL') { flush(); var chk = c.classList.contains('ckl'), n = 0; [].forEach.call(c.children, function (li) { if (li.nodeName !== 'LI') return; n++; fx.li(runs(li, {}, []), { depth: ctx.depth, num: tg === 'OL' ? n : 0, check: chk ? (li.classList.contains('done') ? 2 : 1) : 0 });
          [].forEach.call(li.children, function (k) { if (k.nodeName === 'UL' || k.nodeName === 'OL') go(li, { depth: ctx.depth + 1 }); }); }); return; }
        if (/^H[1-4]$/.test(tg)) { flush(); fx.h(+tg[1], runs(c, {}, [])); return; }
        if (tg === 'P' || tg === 'DIV' || tg === 'BLOCKQUOTE') { flush(); if (blockLike(c)) go(c, ctx); else fx.p(runs(c, {}, []), ctx, c.style && c.style.textAlign); return; }
        pend.push(c);
      });
      flush();
    }
    go(root, { depth: 0 });
  }
  function runsText(rs) { return rs.map(function (r) { return r.t; }).join(''); }
  function toTxt() {
    var out = [title(), ''];
    walkOut(ed, { h: function (l, rs) { out.push(runsText(rs)); }, p: function (rs) { out.push(runsText(rs)); }, li: function (rs, o) { out.push(new Array(o.depth + 1).join('  ') + (o.check ? (o.check === 2 ? '[x] ' : '[ ] ') : o.num ? o.num + '. ' : '• ') + runsText(rs)); }, img: function () { out.push('[Picture]'); }, aud: function (t) { out.push('[' + t + ']'); } });
    return out.join('\n').replace(/\n{3,}/g, '\n\n') + '\n';
  }
  function mdRuns(rs) {
    return rs.map(function (r) {
      var t = r.t; if (r.br) return '  \n'; if (!t.trim()) return t; var lead = /^\s*/.exec(t)[0], trail = /\s*$/.exec(t)[0], core = t.trim().replace(/([*_`\\])/g, '\\$1');
      if (r.b && r.i) core = '***' + core + '***'; else if (r.b) core = '**' + core + '**'; else if (r.i) core = '*' + core + '*'; if (r.s) core = '~~' + core + '~~'; return lead + core + trail;
    }).join('');
  }
  function toMd() {
    var out = ['# ' + title(), ''], nImg = 0;
    walkOut(ed, { h: function (l, rs) { out.push('', new Array(Math.min(l + 1, 6)).join('#') + '# ' + mdRuns(rs).trim(), ''); }, p: function (rs) { out.push(mdRuns(rs), ''); },
      li: function (rs, o) { out.push(new Array(o.depth + 1).join('  ') + (o.num ? o.num + '. ' : '- ') + (o.check ? (o.check === 2 ? '[x] ' : '[ ] ') : '') + mdRuns(rs).trim()); },
      img: function (src) { nImg++; out.push('', '![Picture ' + nImg + '](' + src + ')', ''); }, aud: function (t) { out.push('', '*[' + t + ']*', ''); } });
    return out.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
  }
  /* Word: built by hand (no library), pictures embedded; anything Word cannot show (webp, svg, avif) becomes PNG first */
  function dataBytes(url) { var m = /^data:([^;,]+)?(;base64)?,(.*)$/s.exec(url || ''); if (!m) return null; var raw = m[2] ? atob(m[3]) : decodeURIComponent(m[3]), u = new Uint8Array(raw.length); for (var i = 0; i < raw.length; i++) u[i] = raw.charCodeAt(i); return { mime: (m[1] || '').toLowerCase(), u8: u }; }
  function pngOf(url) { return new Promise(function (res) { var im = new Image(); im.onload = function () { try { var c = document.createElement('canvas'); c.width = im.naturalWidth || 1; c.height = im.naturalHeight || 1; c.getContext('2d').drawImage(im, 0, 0); var b = dataBytes(c.toDataURL('image/png')); res({ mime: 'image/png', u8: b.u8, w: c.width, h: c.height }); } catch (e) { res(null); } }; im.onerror = function () { res(null); }; im.src = url; }); }
  function imgInfo(url) {
    var b = dataBytes(url); if (!b) return Promise.resolve(null);
    return new Promise(function (res) { var im = new Image(); im.onload = function () { var ok = /^image\/(png|jpeg|jpg|gif)$/.test(b.mime); if (ok) res({ mime: b.mime === 'image/jpg' ? 'image/jpeg' : b.mime, u8: b.u8, w: im.naturalWidth, h: im.naturalHeight }); else pngOf(url).then(res); }; im.onerror = function () { res(null); }; im.src = url; });
  }
  function xe(t) { return String(t == null ? '' : t).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function hex(c) { var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(c || ''); if (m) return ('0' + (+m[1]).toString(16)).slice(-2) + ('0' + (+m[2]).toString(16)).slice(-2) + ('0' + (+m[3]).toString(16)).slice(-2); var h = /^#([0-9a-f]{6})$/i.exec(c || ''); return h ? h[1] : ''; }
  function toDocx() {
    var L = THK.lang(note.lang || S.lang), rtl = !!L.rtl, face = ((THK.fontStack(note.font) || 'Calibri').split(',')[0] || 'Calibri').replace(/['"]/g, '').trim(), base = Math.round((note.size || 18) * 1.5) / 1, body = [], imgs = [], jobs = [];
    var bidi = rtl ? '<w:bidi/>' : '';
    function rx(r, sz) {
      if (r.br) return '<w:r><w:br/></w:r>';
      var rp = '<w:rFonts w:ascii="' + xe(face) + '" w:hAnsi="' + xe(face) + '" w:cs="' + xe(face) + '"/>' + (r.b ? '<w:b/><w:bCs/>' : '') + (r.i ? '<w:i/><w:iCs/>' : '') + (r.u ? '<w:u w:val="single"/>' : '') + (r.s ? '<w:strike/>' : '') + (hex(r.c) ? '<w:color w:val="' + hex(r.c) + '"/>' : '') + '<w:sz w:val="' + Math.round((r.z ? r.z * 1.5 : (sz || base))) + '"/><w:szCs w:val="' + Math.round((r.z ? r.z * 1.5 : (sz || base))) + '"/>' + (hex(r.hl) ? '<w:shd w:val="clear" w:color="auto" w:fill="' + hex(r.hl) + '"/>' : '') + (r.sup ? '<w:vertAlign w:val="superscript"/>' : r.sub ? '<w:vertAlign w:val="subscript"/>' : '') + (rtl ? '<w:rtl/>' : '');
      return '<w:r><w:rPr>' + rp + '</w:rPr><w:t xml:space="preserve">' + xe(r.t) + '</w:t></w:r>';
    }
    function para(rs, o) { o = o || {}; var jc = o.jc || (rtl ? 'right' : ''); body.push('<w:p><w:pPr>' + (o.keep ? '<w:keepNext/>' : '') + bidi + '<w:spacing w:after="' + (o.after == null ? 80 : o.after) + '" w:line="' + Math.round((note.lh || 1.6) * 240) + '" w:lineRule="auto"/>' + (o.ind ? '<w:ind w:' + (rtl ? 'right' : 'left') + '="' + o.ind + '" w:hanging="' + (o.hang || 0) + '"/>' : '') + (jc ? '<w:jc w:val="' + jc + '"/>' : '') + '</w:pPr>' + rs.map(function (r) { return rx(r, o.sz); }).join('') + '</w:p>'); }
    para([{ t: title(), b: 1, z: 22 }], { after: 200, keep: 1 });
    walkOut(ed, {
      h: function (l, rs) { para(rs.map(function (r) { return Object.assign({}, r, { b: 1, z: r.z || [0, 1.8, 1.4, 1.15, 1][l] * (note.size || 18) }); }), { after: 120, keep: 1 }); },
      p: function (rs, ctx, al) { para(rs.length ? rs : [{ t: '' }], { jc: ({ center: 'center', right: rtl ? 'left' : 'right', justify: 'both', left: rtl ? 'right' : '' })[al] || '' }); },
      li: function (rs, o) { var mk = o.check ? (o.check === 2 ? '☑ ' : '☐ ') : o.num ? o.num + '. ' : '• '; para([{ t: mk }].concat(rs.map(function (r) { return o.check === 2 ? Object.assign({}, r, { s: 1 }) : r; })), { ind: 540 + o.depth * 360, hang: 360, after: 40 }); },
      img: function (src) { var idx = body.length; body.push(''); jobs.push(imgInfo(src).then(function (inf) { if (!inf) { body[idx] = '<w:p><w:r><w:t>[Picture]</w:t></w:r></w:p>'; return; } var n = imgs.length + 1, ext = inf.mime === 'image/png' ? 'png' : inf.mime === 'image/gif' ? 'gif' : 'jpeg', max = 5760720, wE = Math.min(max, Math.round(inf.w * 9525)), hE = Math.round(wE * inf.h / inf.w); imgs.push({ n: n, ext: ext, u8: inf.u8 });
        body[idx] = '<w:p><w:pPr>' + bidi + '<w:spacing w:after="120"/><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="' + wE + '" cy="' + hE + '"/><wp:docPr id="' + (100 + n) + '" name="Picture ' + n + '"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="' + n + '" name="img' + n + '"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rId' + (10 + n) + '"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' + wE + '" cy="' + hE + '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>'; })); },
      aud: function (t) { para([{ t: '[' + t + ']', i: 1, c: '#666666' }]); }
    });
    return Promise.all(jobs).then(function () {
      var ns = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"';
      var files = {
        '[Content_Types].xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Default Extension="jpeg" ContentType="image/jpeg"/><Default Extension="gif" ContentType="image/gif"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>',
        '_rels/.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
        'word/_rels/document.xml.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' + imgs.map(function (m) { return '<Relationship Id="rId' + (10 + m.n) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/img' + m.n + '.' + m.ext + '"/>'; }).join('') + '</Relationships>',
        'word/styles.xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="' + xe(face) + '" w:hAnsi="' + xe(face) + '" w:cs="' + xe(face) + '"/><w:sz w:val="' + base + '"/></w:rPr></w:rPrDefault></w:docDefaults></w:styles>',
        'word/document.xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ' + ns + '><w:body>' + body.join('') + '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="567" w:footer="567" w:gutter="0"/>' + (rtl ? '<w:bidi/>' : '') + '</w:sectPr></w:body></w:document>'
      };
      imgs.forEach(function (m) { files['word/media/img' + m.n + '.' + m.ext] = m.u8; });
      return THK.fmt.zip(files);
    });
  }
  function exportDlg() {
    if (!note) return; var d;
    persist().then(function () {
      var box = el('div', 'ntx'), F = [
        ['PDF', '.pdf', 'Print-ready A4 with your fonts, pictures and formatting.', exportPdf],
        ['Word document', '.docx', 'Editable Word file; pictures are embedded, voice notes are listed by name.', exportDocx],
        ['Markdown', '.md', 'Plain text with simple marks (headings, lists, bold). Pictures are embedded.', exportMd],
        ['Text file', '.txt', 'Words only. Pictures and voice notes appear as short labels.', exportTxt],
        ['Web page', '.html', 'One self-contained page you can open in any browser.', exportHtml]];
      F.forEach(function (f) { var b = el('button', 'ntxi', '<b>' + esc(f[0]) + '</b><i>' + esc(f[1]) + '</i><small>' + esc(f[2]) + '</small>'); b.type = 'button'; b.onclick = function () { d.close(); setTimeout(f[3], 60); }; box.appendChild(b); });
      d = A.dlg('Export “' + title() + '”', box, [{ l: 'Close' }], { nofocus: true });
    });
  }
  function exportMd() { persist().then(function () { A.deliver(fname() + '.md', 'text/markdown', toMd()); }); }
  function exportDocx() { persist().then(toDocx).then(function (u8) { A.deliverBin(fname() + '.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', u8); }).catch(function (e) { A.toast('Word export failed: ' + (e && e.message || e)); }); }

  /* ---------------------------------------------------------------- look (theme-aware, reuses the editor's glass / pill styles) */
  var st = document.createElement('style');
  st.textContent =
    '#nt{padding:0;display:flex;flex-direction:column;overflow:hidden}' +
    '#nSheet{width:min(100%,1100px);padding:0;display:flex;flex-direction:column;margin:0 auto;min-height:100%}' +
    '#nWork{flex:1;min-height:0;display:flex;padding:8px}#nScroll{flex:1;min-width:0;overflow:auto;border-radius:22px;padding:0;overscroll-behavior:contain;display:flex}' +
    '#nPage.nted{flex:1 0 auto;min-height:60vh;outline:none;white-space:normal;word-wrap:break-word;overflow-wrap:anywhere;font-family:var(--ntf,var(--font));font-size:var(--ntfs,18px);line-height:var(--ntlh,1.6);caret-color:var(--acc);padding:clamp(18px,5vw,48px) clamp(16px,5vw,56px) 90px;-webkit-user-modify:read-write;user-modify:read-write;border-radius:22px}' +
    '#nPage.nted:empty::before{content:attr(data-ph);opacity:.35;pointer-events:none}' +
    '.nted h1{font-size:1.8em;line-height:1.25;margin:.3em 0}.nted h2{font-size:1.4em;line-height:1.3;margin:.3em 0}.nted h3{font-size:1.15em;margin:.3em 0}.nted p,.nted div{margin:0}.nted ul,.nted ol{margin:.3em 0;padding-inline-start:1.5em}' +
    '.nted ul.ckl{list-style:none;padding-inline-start:0}.nted ul.ckl>li{position:relative;padding-inline-start:1.8em;min-height:1.4em}.nted ul.ckl>li::before{content:"";position:absolute;inset-inline-start:.15em;top:.32em;width:.95em;height:.95em;border:2px solid currentColor;border-radius:.3em;opacity:.55;box-sizing:border-box;cursor:pointer}' +
    '.nted ul.ckl>li.done::before{background:var(--acc);border-color:var(--acc);opacity:1;box-shadow:inset 0 0 0 2px var(--pagec,#fff)}.nted ul.ckl>li.done{text-decoration:line-through;opacity:.62}' +
    '#nTop .ttl{display:flex;flex-direction:column;align-items:center;text-align:center;cursor:default;padding:2px 6px}#nTop .ntti{width:100%;min-width:0;border:0;outline:0;background:transparent;color:var(--ink);font:inherit;font-weight:700;text-align:center;text-overflow:ellipsis;padding:2px 4px}#nTop .ntti::placeholder{color:var(--ink2);opacity:.8}' +
    '#nTop .ttl small{text-align:center;display:block;font-size:11px;font-weight:500}' +
    '#nAcc .btn{flex:1 1 0}' +
    '#nFmt{margin:0 8px 8px;border-radius:26px;display:flex;flex-direction:column;max-height:52vh;max-height:min(52vh,560px);overflow:hidden;z-index:6}' +
    '#nFmt .nft{display:flex;align-items:center;gap:10px;padding:12px 14px 8px}#nFmt .nft b{font-size:16px}#nFmt .nft span{flex:1;font-size:11.5px;color:var(--ink2);line-height:1.3}' +
    '#nFmt .nfb{overflow:auto;padding:2px 14px 14px;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;touch-action:pan-y}' +
    '#nFmt .nfh{font-size:11px;text-transform:uppercase;letter-spacing:.6px;color:var(--ink2);margin:12px 4px 6px;font-weight:600}#nFmt .nfh small{text-transform:none;letter-spacing:0;font-weight:400;opacity:.8;margin-left:4px}' +
    '#nFmt .nfr{display:flex;flex-wrap:wrap;gap:6px;align-items:center}#nFmt .nff{max-height:156px;overflow:auto;padding:2px}' +
    '#nFmt .btn{padding:8px 14px}#nFmt .nfont{font-size:15px;max-width:100%;white-space:nowrap}#nFmt .nsmall{min-width:44px;padding:7px 8px}#nFmt .nicon{min-width:44px;padding:8px 10px}#nFmt .nstep{min-width:50px}#nFmt .nsv{min-width:38px;text-align:center;font-weight:700}' +
    '#nFmt .fb-b{font-weight:800}#nFmt .fb-i{font-style:italic}#nFmt .fb-u{text-decoration:underline}#nFmt .fb-s{text-decoration:line-through}' +
    '#nFmt .nsw .sw{width:30px;height:30px;border-radius:50%;border:2px solid var(--edge);padding:0;cursor:pointer;flex:0 0 30px}#nFmt .nsw .sw[data-p]{width:38px;border-radius:12px}#nFmt .nsw .sw[data-p].on{outline:3px solid var(--acc);outline-offset:2px}#nFmt .swc{width:38px;height:30px;border:0;padding:0;background:none;border-radius:50%}' +
    '.ntdice{position:fixed;inset:0;z-index:90;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(10,12,18,.34);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);animation:dFade .28s ease both}.ntdice.out{animation:dFadeOut .26s ease both}' +
    '.ntdice .dbox{width:min(92vw,420px);display:flex;flex-direction:column;gap:10px}.ntdice .dhd{text-align:center;font-size:.78em;letter-spacing:.22em;text-transform:uppercase;color:#fff;opacity:.85;margin-bottom:2px}' +
    '.ntdice .dcard{display:flex;align-items:center;gap:14px;padding:15px 18px;border-radius:22px;background:var(--glass);border:1px solid var(--edge);color:var(--ink);-webkit-backdrop-filter:blur(18px) saturate(1.3);backdrop-filter:blur(18px) saturate(1.3);box-shadow:0 10px 30px rgba(0,0,0,.18);font-size:1.18em;animation:dRise .5s cubic-bezier(.2,.9,.25,1.15) both;animation-delay:calc(var(--i) * 90ms)}' +
    '.ntdice .dcard .dn{flex:0 0 auto;width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:.62em;font-weight:700;background:var(--acc);color:var(--onacc,#fff)}.ntdice .dcard b{font-weight:600;min-width:0;overflow-wrap:anywhere;transition:opacity .25s,filter .25s}.ntdice .dcard.spin b{opacity:.45;filter:blur(1.2px)}' +
    '.ntdice .dft{display:flex;flex-direction:column;align-items:center;gap:8px;margin-top:6px}.ntdice .dft small{color:#fff;opacity:.75}' +
    '@keyframes dRise{from{opacity:0;transform:translateY(26px) scale(.92) rotate(-1.5deg)}to{opacity:1;transform:none}}@keyframes dFade{from{opacity:0}to{opacity:1}}@keyframes dFadeOut{to{opacity:0}}' +
    '.ntl .sv{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:20px;background:var(--glass2);border:1px solid var(--edge);color:var(--ink)}.ntl .sv b{color:var(--ink)}.ntl .sv small,.ntl>p{color:var(--ink2)}.ntl .sv .btn{color:var(--ink)}' +
    '#nAcc{display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;flex-wrap:nowrap}#nAcc::-webkit-scrollbar{display:none}#nAcc .btn{flex:1 0 auto;white-space:nowrap}#ntRec.on{background:#e5484d;color:#fff;border-color:transparent}' +
    '.nted .ntimg{display:block;position:relative;width:fit-content;max-width:100%;margin:.6em 0;user-select:none;-webkit-user-select:none;line-height:0}.nted .ntimg img{max-width:100%;height:auto;border-radius:14px;display:block;content-visibility:auto}.nted .ntimg.ia-left{margin-right:auto}.nted .ntimg.ia-center{margin-left:auto;margin-right:auto}.nted .ntimg.ia-right{margin-left:auto}.nted .ntimg.ia-full{width:100%}.nted .ntimg.ia-full img{width:100%}' +
    '.nted .ntimg::after,.nted .ntaud::after{content:"\\22EF";position:absolute;top:6px;right:6px;width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font:700 20px/1 system-ui,sans-serif;color:#fff;background:rgba(20,20,28,.58);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);cursor:pointer;line-height:1;letter-spacing:0;text-indent:0}.nted .ntaud{position:relative;padding-right:46px!important}.nted .ntaud::after{top:50%;margin-top:-15px;color:var(--textc,#111);background:rgba(127,127,127,.28)}' +
    '.ntx{display:flex;flex-direction:column;gap:8px;padding:6px}.ntx .ntxi{display:grid;grid-template-columns:1fr auto;gap:2px 10px;text-align:left;padding:12px 14px;border-radius:16px;border:1px solid var(--edge);background:var(--glass2);color:var(--ink);cursor:pointer;font:inherit}.ntx .ntxi b{font-size:15px}.ntx .ntxi i{font-style:normal;opacity:.6;font-size:13px}.ntx .ntxi small{grid-column:1/-1;opacity:.7;font-size:12.5px;line-height:1.35}.ntx .ntxi:active{transform:scale(.985)}' +
    '.ntl .ntsearch{width:100%;box-sizing:border-box;padding:10px 14px;border-radius:14px;border:1px solid var(--edge);background:var(--glass2);color:var(--ink);font:inherit;margin-bottom:2px}.ntl .ntlr{display:flex;flex-direction:column;gap:8px}.ntl .ntmore{align-self:center}' +
    '.nted .ntaud{margin:.6em 0;padding:8px;border-radius:18px;background:rgba(127,127,127,.14);display:flex;flex-direction:column;gap:4px}.nted .ntaud audio{width:100%;max-width:420px}.nted .ntaud small{opacity:.65}' +
    '.ntl{display:flex;flex-direction:column;gap:8px;max-height:56vh;overflow:auto;padding:10px}.ntl .sv.cur{outline:none}.ntl .sv .btn{flex:0 0 auto}';
  document.head.appendChild(st);
  window.addEventListener('resize', function () { if (active) caretIntoView(); });
})();
