/* Account, free trial and plan.
   Sign-up is required before the 5-day free trial. The server (Firebase) starts the trial, keeps the plan and checks the region; the app keeps a copy
   so it works offline. After the trial or plan ends the app is read-only: scripts can always be opened and exported. */
(function () {
  'use strict';
  var A = THK.app, el = A.el, esc = A.esc, X = THK.acct = {}, C = THK.cloud, CFG = window.FINNISH_CONFIG || {};
  var TRIAL_DAYS = 5, DAY = 864e5, SKEY = 'fn_status', MAIL = CFG.support || 'mailstonishan@gmail.com', UPDATED = '24 November 2026', GRACE = 14 * DAY;

  /* ---------------------------------------------------------------- saved server answer */
  function loadSt() { try { return JSON.parse(localStorage.getItem(SKEY) || 'null'); } catch (e) { return null; } }
  var st = loadSt();
  function saveSt() { try { if (st) localStorage.setItem(SKEY, JSON.stringify(st)); } catch (e) { } }
  var seen = +(localStorage.getItem('fn_seen') || 0);
  function now() { var n = Date.now(); if (n < seen) n = seen; else { seen = n; try { localStorage.setItem('fn_seen', String(n)); } catch (e) { } } return n; }   /* turning the clock back does not extend access */

  function status() {
    var u = C.user(); if (!u) return { k: 'signedout' };
    if (!u.verified) return { k: 'unverified' };
    if (!st || st.uid !== u.uid) return { k: 'unknown' };
    var n = now(); if (n - st.fetched > GRACE && n > st.fetched) return { k: 'unknown', stale: true };
    if (st.plan && st.until > n) return { k: 'active', plan: st.plan, until: st.until };
    if (st.trialEnd && n < st.trialEnd) return { k: 'trial', left: Math.max(1, Math.ceil((st.trialEnd - n) / DAY)) };
    return { k: 'expired' };
  }
  X.status = status;
  X.canEdit = function () { var k = status().k; return k === 'trial' || k === 'active'; };

  /* ---------------------------------------------------------------- prices (same on every platform within a country) */
  var TIER = { 1: [5, 50], 2: [4, 40], 3: [3, 30], 4: [2, 20], 5: [1, 10], 6: [0.5, 4] };   /* USD per month / per year – six tiers */
  var CODES = {
    1: 'US CA AU NZ CH JP SG IE NL BE LU FR FI DK SE NO IS AT',
    2: 'ES IT PT KR IL AE SA QA KW BH OM HK TW CY MT SI EE SK LT LV CZ',
    3: 'PL HU HR GR RO BG CL UY CR PA MY MX KZ RS',
    5: 'VN PH ID LK KE TZ UG TR EG JO TN DZ NP KH LA MM UZ GH ZM SN CI CM',
    6: 'PK BD NG',
    EU: 'DE FR ES IT NL BE AT IE PT FI GR LU SK SI EE LT LV CY MT HR'
  };   /* every country not listed is tier 4 */
  function priceFor(cc) {
    if (cc === 'IN') return { c: '₹', m: 25, y: 200 };
    if (cc === 'GB') return { c: '£', m: 5, y: 50 };
    if (cc === 'DE' || cc === 'AT') return { c: '€', m: 5, y: 50 };
    if ('FR NL BE IE LU FI'.split(' ').indexOf(cc) >= 0) return { c: '€', m: 5, y: 50 };
    var t = 4; ['1', '2', '3', '5', '6'].forEach(function (k) { if (CODES[k].split(' ').indexOf(cc) >= 0) t = +k; });
    return { c: '$', m: TIER[t][0], y: TIER[t][1] };
  }
  function regionName(cc) { try { return new Intl.DisplayNames(['en'], { type: 'region' }).of(cc) || cc; } catch (e) { return cc; } }
  function guessRegion() {
    try { var tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; if (/^Asia\/(Kolkata|Calcutta)$/.test(tz)) return 'IN'; } catch (e) { }
    var L = (navigator.languages || [navigator.language || '']);
    for (var i = 0; i < L.length; i++) { var m = /-([A-Za-z]{2})$/.exec(L[i] || ''); if (m) return m[1].toUpperCase(); }
    return 'US';
  }
  function country() { return (st && st.country) || guessRegion(); }
  function money(p, v) { return p.c + (v % 1 ? v.toFixed(2) : v); }
  function saving(p) { return Math.round(100 * (1 - p.y / (12 * p.m))); }

  /* ---------------------------------------------------------------- talking to the server */
  var busy = null;
  X.refresh = function () {
    if (!C.ready || !C.user() || !C.user().verified) return Promise.resolve(false);
    if (busy) return busy;
    busy = C.status().then(function (r) {
      st = { uid: C.user().uid, trialEnd: r.trialEnd || 0, plan: r.plan || '', until: r.until || 0, country: r.country || '', vpn: !!r.vpn, fetched: Date.now() };
      saveSt(); return true;
    }).catch(function (e) { if (e && e.code === 'SIGNED_OUT') { wall(); } return false; }).then(function (ok) { busy = null; paint(); return ok; });
    return busy;
  };

  /* ---------------------------------------------------------------- styles */
  var css = document.createElement('style');
  css.textContent = '.acx{text-align:center}.acx .ast{font-weight:700;font-size:17px;margin:2px 0}.acx .asub{font-size:12.5px;opacity:.75;line-height:1.45;margin:2px 0 8px}' +
    '.acx .ah{font-weight:700;margin:14px 0 4px}.acx input.t{width:100%;box-sizing:border-box;margin:4px 0}.acx .xrow{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:6px 0}' +
    '.acx .warn{font-size:12.5px;line-height:1.45;padding:8px 10px;border-radius:12px;background:rgba(255,159,10,.16);margin:8px 0}.acx .err{color:#ff453a;font-size:12.5px;min-height:16px;margin:2px 0}' +
    '.acx .lnk{background:none;border:0;color:inherit;opacity:.75;text-decoration:underline;font-size:12.5px;cursor:pointer;padding:4px}' +
    '#fnwall{position:fixed;inset:0;z-index:95;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(10,12,16,.72);-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px)}' +
    '#fnwall .dlg{max-width:400px;width:100%;max-height:92vh;overflow:auto}' +
    '.lgl{max-height:58vh;overflow:auto;-webkit-overflow-scrolling:touch;text-align:left;font-size:13.5px;line-height:1.55}.lgl h4{margin:14px 0 4px;font-size:14px}.lgl p,.lgl ul{margin:4px 0}.lgl ul{padding-left:20px}.lgl .lu{opacity:.7;font-size:12px}';
  document.head.appendChild(css);

  /* ---------------------------------------------------------------- the sign-up wall (cannot be closed until signed in and verified) */
  var wallEl = null;
  function wall() {
    var s = status(); if (!C.ready) { return showWall(unconfigured()); }
    if (s.k === 'signedout') return showWall(signForm('in'));
    if (s.k === 'unverified') return showWall(verifyForm());
    if (s.k === 'unknown') { if (navigator.onLine === false) return showWall(offlineForm()); X.refresh().then(function () { if (status().k === 'unknown') showWall(offlineForm()); else hideWall(); }); return; }
    hideWall();
  }
  function hideWall() { if (wallEl) { wallEl.remove(); wallEl = null; } }
  function showWall(box) {
    if (!wallEl) { wallEl = el('div', ''); wallEl.id = 'fnwall'; var d = el('div', 'dlg glass'); wallEl.appendChild(d); document.body.appendChild(wallEl); }
    var d2 = wallEl.firstChild; d2.innerHTML = ''; d2.appendChild(box);
  }
  function unconfigured() { var b = el('div', 'acx'); b.appendChild(el('div', 'ast', 'Account server not set up')); b.appendChild(el('div', 'asub', 'This build has no server settings yet. Fill in <b>www/config.js</b> (see FIREBASE_SETUP.md) and build again.')); return b; }
  function offlineForm() {
    var b = el('div', 'acx'); b.appendChild(el('div', 'ast', 'Connect to the internet')); b.appendChild(el('div', 'asub', 'finnish needs to check your account once' + (st && st.uid ? ' (it has been a while since the last check)' : '') + '. After that you can write offline.'));
    var r = el('div', 'xrow'); r.appendChild(A.btn('Try again', function () { X.refresh().then(wall); }, 'pri')); r.appendChild(A.btn('Sign out', function () { C.signOut().then(wall); })); b.appendChild(r); return b;
  }
  function verifyForm() {
    var u = C.user(), b = el('div', 'acx'), msg = el('div', 'err', '');
    b.appendChild(el('div', 'ast', 'Check your email')); b.appendChild(el('div', 'asub', 'We sent a link to <b>' + esc(u.email) + '</b>. Open it, then come back and press the button. Look in spam if it is not in your inbox.'));
    b.appendChild(msg);
    var r = el('div', 'xrow');
    r.appendChild(A.btn('I have verified', function () { msg.textContent = ''; C.checkVerified().then(function (v) { if (!v) { msg.textContent = 'Not verified yet. Open the link in the email first.'; return; } X.refresh().then(wall); }, function (e) { msg.textContent = e.message; }); }, 'pri'));
    r.appendChild(A.btn('Send the email again', function () { msg.textContent = ''; C.sendVerify().then(function () { A.toast('Email sent'); }, function (e) { msg.textContent = e.message; }); }));
    r.appendChild(A.btn('Use another email', function () { C.signOut().then(wall); })); b.appendChild(r); return b;
  }
  function signForm(mode) {
    var b = el('div', 'acx'), up = mode === 'up';
    b.appendChild(el('div', 'ast', up ? 'Create your account' : 'Welcome to finnish'));
    b.appendChild(el('div', 'asub', up ? 'Your 5-day free trial starts after you verify your email. One account works on Android, iPhone, Windows and Mac.' : 'Sign in to continue. New here? Create an account to start your 5-day free trial.'));
    var em = el('input', 't'); em.type = 'email'; em.placeholder = 'Email'; em.autocomplete = 'email'; em.setAttribute('inputmode', 'email');
    var pw = el('input', 't'); pw.type = 'password'; pw.placeholder = up ? 'Password (8 or more characters)' : 'Password'; pw.autocomplete = up ? 'new-password' : 'current-password';
    var pw2 = el('input', 't'); pw2.type = 'password'; pw2.placeholder = 'Repeat password'; pw2.autocomplete = 'new-password';
    var msg = el('div', 'err', ''); b.appendChild(em); b.appendChild(pw); if (up) b.appendChild(pw2); b.appendChild(msg);
    function go() {
      var v = em.value.trim(); msg.textContent = '';
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(v)) { msg.textContent = 'Enter a valid email address.'; return; }
      if (up && pw.value.length < 8) { msg.textContent = 'Choose a password of at least 8 characters.'; return; }
      if (up && pw.value !== pw2.value) { msg.textContent = 'The two passwords are not the same.'; return; }
      if (!up && !pw.value) { msg.textContent = 'Enter your password.'; return; }
      msg.textContent = 'Please wait…';
      (up ? C.signUp(v, pw.value) : C.signIn(v, pw.value)).then(function () { X.refresh().then(wall); wall(); }, function (e) { msg.textContent = e.message; });
    }
    var r = el('div', 'xrow'); r.appendChild(A.btn(up ? 'Create account' : 'Sign in', go, 'pri'));
    if (THK.google && THK.google.available()) r.appendChild(A.btn('Continue with Google', function () { msg.textContent = ''; THK.google.token(THK.google.SIGNIN).then(C.signInGoogle).then(function () { X.refresh().then(wall); wall(); }, function (e) { msg.textContent = e.message; }); }));
    b.appendChild(r);
    var r2 = el('div', 'xrow');
    var sw = el('button', 'lnk', up ? 'I already have an account' : 'Create an account'); sw.onclick = function () { showWall(signForm(up ? 'in' : 'up')); }; r2.appendChild(sw);
    if (!up) { var fg = el('button', 'lnk', 'Forgot password'); fg.onclick = function () { var v = em.value.trim(); if (!/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(v)) { msg.textContent = 'Type your email above first.'; return; } C.sendReset(v).then(function () { msg.textContent = 'If an account uses this email, a reset link is on its way.'; }, function (e) { msg.textContent = e.message; }); }; r2.appendChild(fg); }
    b.appendChild(r2);
    var lg = el('div', 'asub', 'By continuing you agree to the <button class="lnk" data-l="terms">Terms of Service</button> and the <button class="lnk" data-l="privacy">Privacy Policy</button>.');
    lg.querySelectorAll('button').forEach(function (x) { x.onclick = function () { X.legal(x.getAttribute('data-l')); }; }); b.appendChild(lg);
    em.addEventListener('keydown', function (e) { if (e.key === 'Enter') pw.focus(); }); pw.addEventListener('keydown', function (e) { if (e.key === 'Enter') { up ? pw2.focus() : go(); } }); pw2.addEventListener('keydown', function (e) { if (e.key === 'Enter') go(); });
    return b;
  }

  /* ---------------------------------------------------------------- the account & plan window */
  var openD = null;
  X.open = function (why) {
    if (!C.user()) { wall(); return; }
    if (openD && openD.isConnected) openD.close();
    var box = el('div', 'acx'), top = el('div', ''), body = el('div', '');
    box.appendChild(top); box.appendChild(body);
    var pr = priceFor(country());

    function head() {
      var s = status(), t = '', sub = '';
      if (s.k === 'trial') { t = 'Free trial · ' + s.left + (s.left === 1 ? ' day' : ' days') + ' left'; sub = 'Everything is unlocked during the trial.'; }
      else if (s.k === 'active') { t = 'Subscribed · ' + (s.plan === 'year' ? 'Annual' : 'Monthly'); sub = 'Active until ' + new Date(s.until).toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' }) + '.'; }
      else if (s.k === 'expired') { t = 'Your free trial has ended'; sub = 'You can still open, read and export every script. Subscribe to write again.'; }
      else { t = 'Account'; sub = 'Connect to the internet to refresh your plan.'; }
      top.innerHTML = '<div class="ast">' + esc(t) + '</div><div class="asub">' + esc(why || sub) + '</div>';
    }
    function who() {
      var u = C.user(), w = el('div', ''); w.appendChild(el('div', 'ah', 'Account'));
      w.appendChild(el('div', 'asub', 'Signed in as <b>' + esc(u.email) + '</b><br>One account works on Android, iPhone, Windows and Mac. Your scripts stay on each device; use Backup to move them.'));
      var r = el('div', 'xrow');
      r.appendChild(A.btn('Sign out', function () { C.signOut().then(function () { box.closest('.scrim') && box.closest('.scrim').remove(); wall(); }); }));
      r.appendChild(A.btn('Delete account', deleteDlg)); w.appendChild(r); return w;
    }
    function plans() {
      var s = status(), w = el('div', ''); w.appendChild(el('div', 'ah', s.k === 'active' ? 'Your plan' : 'Plans'));
      var cc = country(); pr = priceFor(cc);
      w.appendChild(el('div', 'asub', 'Prices for <b>' + esc(regionName(cc)) + '</b>. Same price on every platform.'));
      var pb = el('div', 'xrow');
      if (s.k === 'active') { w.appendChild(el('div', 'asub', 'To change or cancel your plan, open your store’s subscription settings (Google Play, App Store or Microsoft Store).')); }
      else {
        pb.appendChild(A.btn('Monthly · ' + money(pr, pr.m), function () { buy('month'); }, 'pri'));
        pb.appendChild(A.btn('Annual · ' + money(pr, pr.y) + ' · save ' + saving(pr) + '%', function () { buy('year'); }, 'pri'));
        w.appendChild(pb);
        if (st && st.vpn) w.appendChild(el('div', 'warn', 'A VPN or proxy was detected. You can keep using finnish, but to subscribe please turn it off and refresh. This keeps prices fair in every country.'));
        w.appendChild(el('div', 'asub', 'Renews automatically until you cancel in your store’s subscription settings. The store shows the final price in your currency.'));
      }
      var rf = el('div', 'xrow'); rf.appendChild(A.btn('Refresh', function () { X.refresh().then(function () { draw(); A.toast('Updated'); }); })); w.appendChild(rf); return w;
    }
    function buy(plan) {
      X.refresh().then(function () {
        if (st && st.vpn) { A.dlg('VPN or proxy detected', '<p>To keep prices fair in every country, subscriptions are not available while a VPN or proxy is on. Turn it off, tap Refresh, then try again. You can keep writing during your trial.</p>', [{ l: 'OK', cls: 'pri' }]); draw(); return; }
        if (!CFG.billingLive || !THK.billing) { A.dlg('Subscriptions open soon', '<p>Subscriptions open when finnish is available in your store. Your free trial continues until then, and your scripts always stay yours to read and export.</p>', [{ l: 'OK', cls: 'pri' }]); return; }
        var p = pr; A.dlg('Subscribe', '<p>' + (plan === 'year' ? 'Annual · ' + money(p, p.y) : 'Monthly · ' + money(p, p.m)) + '</p>', [{ l: 'Not now' }, { l: 'Subscribe', cls: 'pri', fn: function () { THK.billing.purchase(plan, country()).then(function () { return X.refresh(); }).then(function () { A.toast('Plan active'); draw(); }, function (e) { A.toast(e.message || 'Purchase did not complete'); }); } }]);
      });
    }
    function deleteDlg() {
      var b = el('div', ''); b.appendChild(el('p', '', 'This permanently deletes your account and your subscription record on our server. Scripts saved on this device are not touched, so export or back them up first if you need them.<br>Active store subscriptions must be cancelled in the store.'));
      var i = el('input', 't'); i.placeholder = 'Type DELETE to confirm'; b.appendChild(i);
      var m = el('div', 'err', ''); b.appendChild(m);
      A.dlg('Delete account?', b, [{ l: 'Keep my account' }, { l: 'Delete account', cls: 'pri', fn: function () { if (i.value.trim() !== 'DELETE') { m.textContent = 'Type DELETE exactly.'; return false; } C.deleteAccount().then(function () { try { localStorage.removeItem(SKEY); } catch (e) { } st = null; if (openD && openD.close) openD.close(); wall(); A.toast('Account deleted'); }, function (e) { A.toast(e.message || 'Could not delete. Try again.'); }); } }]);
    }
    function links() {
      var w = el('div', 'xrow'); w.style.marginTop = '12px';
      [['Privacy', 'privacy'], ['Terms', 'terms'], ['Refunds', 'refund'], ['License', 'licence']].forEach(function (l) { w.appendChild(A.btn(l[0], function () { X.legal(l[1]); })); });
      return w;
    }
    function draw() { head(); body.innerHTML = ''; body.appendChild(who()); body.appendChild(plans()); body.appendChild(links()); }
    draw();
    openD = A.dlg('Account & plan', box, [{ l: 'Close', cls: 'pri' }], { nofocus: true });
    return openD;
  };

  /* ---------------------------------------------------------------- legal pages */
  var LEGAL = {
    privacy: ['Privacy Policy', function () {
      return '<p class="lu">Last updated ' + UPDATED + '</p>' +
        '<h4>Who we are</h4><p>finnish is created and operated by Nishan, India. In this policy, “we” means Nishan. Contact: ' + MAIL + '.</p>' +
        '<h4>Your scripts stay on your device</h4><p>Everything you write or import (scripts, covers, storyboards, notes, pictures and settings) is saved only on your phone, tablet or computer. We do not receive a copy and we cannot read it. If you uninstall the app or clear its data, it is gone unless you made a backup or export.</p>' +
        '<h4>Your account</h4><p>You need an account to use finnish. We store your email address, a sign-in record, the date your free trial started, your plan and its end date, and the country used to set your price. If you sign in with Google we receive your name and email from Google. Your account is kept with Google Firebase, our account provider. One account works on every platform we support.</p>' +
        '<h4>Region and VPN check</h4><p>To keep prices fair, our server looks at your internet address (IP address) to find your country and to detect a VPN or proxy. The IP address is checked with a detection service (proxycheck.io) and is not kept in your account record. Using a VPN never blocks the app; it only pauses new subscriptions until you turn it off.</p>' +
        '<h4>Payments</h4><p>Subscriptions are handled by Google Play, the Apple App Store or the Microsoft Store. We never see your card or bank details. We receive only the subscription status from the store.</p>' +
        '<h4>Backup to Google Drive</h4><p>If you choose Back up to Google Drive, your backup file is saved in a hidden folder that only finnish can open. We never see it. You can delete it in your Google Account settings.</p>' +
        '<h4>What is sent over the internet</h4><p>Writing, saving, exporting and everything else works without internet, apart from the items below. These happen only when you use them:</p><ul>' +
        '<li><b>Translate</b> sends the text of your script and character names to online translation services (Google Translate and Microsoft Translator; if one is unavailable the app may use another translation provider such as Lingva or MyMemory). Those services can see the text and your IP address and have their own privacy policies. Do not translate a script you must keep confidential.</li>' +
        '<li><b>Proofread</b> may ask Google for spelling suggestions and sends the checked text.</li>' +
        '<li><b>Scan to Script</b> downloads reading data for a language once from a public network (jsDelivr). Your pictures are read on the device and are not uploaded.</li>' +
        '<li><b>Voice typing</b>, when you use it, is handled by the speech service of your device or browser, which may send audio to its provider.</li>' +
        '<li><b>Some optional fonts</b> are loaded from Google Fonts when you choose them.</li></ul>' +
        '<h4>No ads, no tracking</h4><p>The app has no advertising and no analytics.</p>' +
        '<h4>How long we keep data</h4><p>We keep your account record while your account exists. When you delete your account, we delete the record from our server.</p>' +
        '<h4>Your rights and choices</h4><p>You can see your account details in Account &amp; plan. You can delete your account and its data yourself at any time in <b>Account &amp; plan → Delete account</b>. Depending on where you live (for example the EU, the UK, India or California) you may also have the right to ask for a copy of your data or to correct it; write to ' + MAIL + ' and we will answer within 30 days.</p>' +
        '<h4>Children</h4><p>finnish is not directed at children under 13 (or under 16 where local law requires), and we do not knowingly collect their data.</p>' +
        '<h4>Changes</h4><p>If we make a significant change to this policy, we will tell you in the app before it takes effect. The date above shows the latest version.</p>' +
        '<h4>Contact</h4><p>' + MAIL + '</p>';
    }],
    terms: ['Terms of Service', function () {
      return '<p class="lu">Last updated ' + UPDATED + '</p>' +
        '<h4>Using finnish</h4><p>finnish is a screenplay-writing app created and operated by Nishan, India (“we”). By creating an account or using the app you agree to these terms. If you do not agree, do not use the app. You must be at least 13 years old (or older where local law requires) to create an account.</p>' +
        '<h4>Your work</h4><p>You own everything you write. We claim no rights over your scripts. Scripts are stored on your device, so you are responsible for keeping backups: use Backup &amp; restore and Export regularly.</p>' +
        '<h4>Free trial and subscription</h4><ul><li>A ' + TRIAL_DAYS + '-day free trial starts when you create an account and verify your email. One trial is available per person.</li><li>After the trial, writing needs a subscription. You can always open, read and export your existing scripts.</li><li>Plans are monthly or annual, renew automatically, and are charged by the store you bought from. Prices depend on your country, are the same on every platform, and are shown before you buy. We will tell you before a price change affects you.</li><li>One account works on every platform we support. A paid plan unlocks all of them.</li><li>Prices are set by your country. Using a VPN or proxy to get another country’s price is not allowed; subscriptions pause while one is detected.</li></ul>' +
        '<h4>Cancelling</h4><p>You can stop renewal at any time in your store’s subscription settings. Stopping renewal ends future charges; you keep access until the end of the period you have already paid for.</p>' +
        '<h4>Translation and other online tools</h4><p>Machine translation and spelling suggestions can be wrong. Always read the result before you use it. Online tools depend on third-party services that can change or stop working without notice. Features marked experimental are provided as is.</p>' +
        '<h4>Acceptable use</h4><p>Do not copy, resell or reverse-engineer the app, share your account, or use the app to break the law. We may suspend an account that breaks these terms.</p>' +
        '<h4>No warranty</h4><p>The app is provided “as is”. To the extent the law allows, we are not liable for lost data, or for indirect or consequential damages. Nothing here removes rights you have under the mandatory consumer laws of your country.</p>' +
        '<h4>Changes and law</h4><p>We may update these terms; for significant changes we will tell you in the app first. The date above shows the latest version. These terms are governed by the laws of India, and disputes are handled by the courts of India, except where your local consumer law says otherwise.</p>' +
        '<h4>Contact</h4><p>' + MAIL + '</p>';
    }],
    refund: ['Cancellation & Refunds', function () {
      return '<p class="lu">Last updated ' + UPDATED + '</p>' +
        '<h4>Free trial</h4><p>The ' + TRIAL_DAYS + '-day free trial is free. Nothing is charged during the trial.</p>' +
        '<h4>Cancelling</h4><p>Cancel renewal in the subscription settings of the store you used (Google Play, App Store or Microsoft Store). You will not be charged again and you keep access until the end of the period you paid for.</p>' +
        '<h4>Refunds</h4><p>Your payment is taken and refunded by the store you bought from, under that store’s own refund rules. To ask for a refund, use the store’s “Report a problem” or refund request page: Google Play, the App Store and the Microsoft Store each have one. We cannot refund a store payment ourselves, but if you need help with a request, write to ' + MAIL + '.</p>' +
        '<h4>Your scripts</h4><p>Cancelling never deletes your scripts. You can always open, read and export them.</p>';
    }],
    licence: ['Software License', function () {
      return '<p class="lu">Last updated ' + UPDATED + '</p><p>© 2026 Nishan. All rights reserved.</p>' +
        '<h4>License</h4><p>We give you a personal, non-transferable license to install and use finnish on your own devices for as long as your trial or subscription is active, and to read and export your own scripts afterwards. The app and its design remain the property of Nishan.</p>' +
        '<h4>Not allowed</h4><p>Copying or redistributing the app, removing notices, or extracting its code or assets for another product.</p>' +
        '<h4>Third-party components</h4><ul><li>PDF.js (Mozilla): Apache License 2.0, used to read PDF files.</li><li>Tesseract.js and Tesseract language data: Apache License 2.0, used by Scan to Script.</li><li>Capacitor and Electron: MIT license, used to run the app on phones and computers.</li><li>Fonts bundled with the app (for example the Noto, Manjari, Meera, Uroob and Anjali families): SIL Open Font License.</li></ul>' +
        '<p>These parts keep their own licenses. Their authors are not responsible for finnish or for any problem it causes.</p>' +
        '<h4>Contact</h4><p>' + MAIL + '</p>';
    }]
  };
  X.legal = function (k) { var d = LEGAL[k]; if (!d) return; A.dlg(d[0], '<div class="lgl">' + d[1]() + '</div>', [{ l: 'Close', cls: 'pri' }]); };

  /* ---------------------------------------------------------------- read-only after the trial, and locked while not signed in */
  var lastAsk = 0;
  function ask() { var t = Date.now(); if (t - lastAsk < 8000) return; lastAsk = t; if (document.querySelector('#layer .dlg')) return; if (status().k === 'expired') X.open(); else wall(); }
  function inDoc(t) { return t && t.closest && t.closest('#page .ed, #cover .ed'); }
  function locked() { return !X.canEdit(); }
  document.addEventListener('focusin', function (e) { if (!locked()) return; var ed = inDoc(e.target); if (!ed) return; ed.contentEditable = 'false'; try { ed.blur(); } catch (x) { } ask(); }, true);
  ['beforeinput', 'paste', 'cut', 'drop'].forEach(function (n) { document.addEventListener(n, function (e) { if (locked() && inDoc(e.target)) { e.preventDefault(); e.stopPropagation(); ask(); } }, true); });
  document.addEventListener('keydown', function (e) {
    if (!locked() || !inDoc(e.target) || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key.length === 1 || /^(Enter|Backspace|Delete|Tab)$/.test(e.key)) { e.preventDefault(); ask(); }
  }, true);
  document.addEventListener('click', function (e) { if (locked() && inDoc(e.target)) ask(); }, true);
  function gate(obj, fn) { var f = obj && obj[fn]; if (!f) return; obj[fn] = function () { if (!X.canEdit()) { X.open('Subscribe to use this. Your existing scripts can still be read and exported.'); return; } return f.apply(this, arguments); }; }
  gate(THK.scan, 'open'); gate(THK.tr2en, 'run');

  /* a small badge-free status line: trial reminder once a day */
  function paint() {
    try {
      var s = status(); if ((s.k === 'signedout' || s.k === 'unverified') && !wallEl) { wall(); } else if (wallEl && (s.k === 'trial' || s.k === 'active' || s.k === 'expired')) { hideWall(); }
      var day = Math.floor(now() / DAY); if (X.noted === day) return;
      if (s.k === 'trial' && s.left <= 2) { X.noted = day; A.toast('Free trial: ' + s.left + (s.left === 1 ? ' day' : ' days') + ' left'); }
      else if (s.k === 'expired') { X.noted = day; A.toast('Trial ended. You can read and export.'); }
    } catch (e) { }
  }
  function start() {
    wall();
    if (C.user()) X.refresh().then(function () { wall(); });
    window.addEventListener('online', function () { X.refresh(); });
    setInterval(function () { X.refresh(); }, 6 * 3600 * 1000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden && C.user() && (!st || Date.now() - st.fetched > 30 * 60 * 1000)) X.refresh(); });
  }
  setTimeout(start, 600);
})();
