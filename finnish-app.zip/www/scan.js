/* Scan to Script – photograph or pick pictures of written / printed script pages, read them ON THE DEVICE with OCR
   (Tesseract, the same engine the PDF importer uses), sense whether the pages are Standard or Two Column, and open an editable script.
   Pictures never leave the device; there is no cloud / AI-vision option by design. */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, SC = THK.scan = {};
  var LANGPATH = { fast: 'https://cdn.jsdelivr.net/gh/tesseract-ocr/tessdata_fast@4.1.0', best: 'https://cdn.jsdelivr.net/gh/tesseract-ocr/tessdata_best@4.1.0' };
  var LANGS = [['mal', 'Malayalam'], ['eng', 'English'], ['hin', 'Hindi'], ['tam', 'Tamil'], ['tel', 'Telugu'], ['kan', 'Kannada'], ['ben', 'Bengali'], ['mar', 'Marathi'], ['guj', 'Gujarati'], ['pan', 'Punjabi'], ['ori', 'Odia'], ['sin', 'Sinhala'], ['nep', 'Nepali'], ['urd', 'Urdu'], ['ara', 'Arabic'], ['fas', 'Persian'], ['heb', 'Hebrew'], ['spa', 'Spanish'], ['fra', 'French'], ['deu', 'German'], ['ita', 'Italian'], ['por', 'Portuguese'], ['rus', 'Russian'], ['ukr', 'Ukrainian'], ['pol', 'Polish'], ['nld', 'Dutch'], ['swe', 'Swedish'], ['ell', 'Greek'], ['tur', 'Turkish'], ['ind', 'Indonesian'], ['tha', 'Thai'], ['vie', 'Vietnamese'], ['jpn', 'Japanese'], ['kor', 'Korean'], ['chi_sim', 'Chinese (Simplified)'], ['chi_tra', 'Chinese (Traditional)']];
  var LMAP = { mal: 'ml', hin: 'hi', tam: 'ta', tel: 'te', kan: 'kn', ben: 'bn', mar: 'mr', guj: 'gu', pan: 'pa', ori: 'or', sin: 'si', nep: 'ne', urd: 'ur', ara: 'ar', fas: 'fa', eng: 'en', spa: 'es', fra: 'fr', deu: 'de', ita: 'it', por: 'pt', rus: 'ru', tur: 'tr', ind: 'id', jpn: 'ja', kor: 'ko', chi_sim: 'zh', tha: 'th', vie: 'vi' };
  var A = function () { return THK.app; };
  function el(t, c, h) { return A().el(t, c, h); }

  /* ---------------------------------------------------------------- picture clean-up (shadows, contrast, tilt) */
  function toCanvas(src, rot) {
    var W = src.width || src.naturalWidth, H = src.height || src.naturalHeight, k = Math.min(3000 / Math.max(W, H), Math.max(1, 1500 / Math.min(W, H)));
    var q = (rot / 90) % 4; if (q < 0) q += 4; var w = Math.round(W * k), h = Math.round(H * k), c = document.createElement('canvas');
    if (q % 2) { c.width = h; c.height = w; } else { c.width = w; c.height = h; }
    var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.save(); x.translate(c.width / 2, c.height / 2); x.rotate(q * Math.PI / 2); x.drawImage(src, -w / 2, -h / 2, w, h); x.restore(); return c;
  }
  function boxBlur(a, w, h, r) {
    var t = new Float32Array(a.length), i, x, y, s, n;
    for (y = 0; y < h; y++) { s = 0; n = 0; for (x = -r; x <= r; x++) { if (x >= 0 && x < w) { s += a[y * w + x]; n++; } } for (x = 0; x < w; x++) { t[y * w + x] = s / n; var ax = x + r + 1, rx = x - r; if (ax < w) { s += a[y * w + ax]; n++; } if (rx >= 0) { s -= a[y * w + rx]; n--; } } }
    for (x = 0; x < w; x++) { s = 0; n = 0; for (y = -r; y <= r; y++) { if (y >= 0 && y < h) { s += t[y * w + x]; n++; } } for (y = 0; y < h; y++) { a[y * w + x] = s / n; var ay = y + r + 1, ry = y - r; if (ay < h) { s += t[ay * w + x]; n++; } if (ry >= 0) { s -= t[ry * w + x]; n--; } } }
  }
  function dilate(a, w, h, r) {
    var t = new Float32Array(a.length), x, y, d, m;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) { m = 0; for (d = -r; d <= r; d++) { var xx = x + d; if (xx >= 0 && xx < w && a[y * w + xx] > m) m = a[y * w + xx]; } t[y * w + x] = m; }
    for (x = 0; x < w; x++) for (y = 0; y < h; y++) { m = 0; for (d = -r; d <= r; d++) { var yy = y + d; if (yy >= 0 && yy < h && t[yy * w + x] > m) m = t[yy * w + x]; } a[y * w + x] = m; }
  }
  /* even out shadows / uneven light: divide by the local paper brightness, then stretch the contrast */
  function flatten(c) {
    var w = c.width, h = c.height, x = c.getContext('2d'), id = x.getImageData(0, 0, w, h), d = id.data, n = w * h, g = new Uint8ClampedArray(n), i;
    for (i = 0; i < n; i++) g[i] = (d[i * 4] * 299 + d[i * 4 + 1] * 587 + d[i * 4 + 2] * 114) / 1000;
    var sw = Math.max(8, Math.round(w / 12)), sh = Math.max(8, Math.round(h / 12)), sm = document.createElement('canvas'); sm.width = sw; sm.height = sh;
    var mid = document.createElement('canvas'); mid.width = Math.max(sw, Math.round(w / 4)); mid.height = Math.max(sh, Math.round(h / 4));
    mid.getContext('2d').drawImage(c, 0, 0, mid.width, mid.height); var sx = sm.getContext('2d'); sx.drawImage(mid, 0, 0, sw, sh);
    var sd = sx.getImageData(0, 0, sw, sh).data, bg = new Float32Array(sw * sh);
    for (i = 0; i < sw * sh; i++) bg[i] = (sd[i * 4] * 299 + sd[i * 4 + 1] * 587 + sd[i * 4 + 2] * 114) / 1000;
    dilate(bg, sw, sh, 2); boxBlur(bg, sw, sh, 2);
    var bc = document.createElement('canvas'); bc.width = sw; bc.height = sh; var bi = bc.getContext('2d').createImageData(sw, sh);
    for (i = 0; i < sw * sh; i++) { var v = Math.max(1, Math.min(255, bg[i])); bi.data[i * 4] = bi.data[i * 4 + 1] = bi.data[i * 4 + 2] = v; bi.data[i * 4 + 3] = 255; }
    bc.getContext('2d').putImageData(bi, 0, 0); var big = document.createElement('canvas'); big.width = w; big.height = h; var bx = big.getContext('2d'); bx.imageSmoothingEnabled = true; bx.imageSmoothingQuality = 'high'; bx.drawImage(bc, 0, 0, w, h);
    var B = bx.getImageData(0, 0, w, h).data, hist = new Uint32Array(256), out = new Uint8ClampedArray(n);
    for (i = 0; i < n; i++) { var p = Math.min(255, g[i] * 255 / Math.max(50, B[i * 4])); out[i] = p; hist[p | 0]++; }
    var acc = 0, lo = 0, cut = n * 0.004; for (i = 0; i < 256; i++) { acc += hist[i]; if (acc > cut) { lo = i; break; } }
    var hi = 235, span = Math.max(40, hi - lo);
    for (i = 0; i < n; i++) { var q = Math.max(0, Math.min(255, (out[i] - lo) * 255 / span)); d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = q; d[i * 4 + 3] = 255; }
    x.putImageData(id, 0, 0); return c;
  }
  /* tilt of the text lines (degrees): the angle that makes the rows of ink sharpest */
  function skew(c) {
    var k = Math.min(1, 700 / c.width), w = Math.round(c.width * k), h = Math.round(c.height * k), s = document.createElement('canvas'); s.width = w; s.height = h;
    var sx = s.getContext('2d'); sx.drawImage(c, 0, 0, w, h); var d = sx.getImageData(0, 0, w, h).data, px = [], i;
    for (i = 0; i < w * h; i++) if (d[i * 4] < 120) px.push(i);
    if (px.length < 200) return 0; var step = Math.max(1, Math.floor(px.length / 40000));
    function score(a) {
      var cs = Math.cos(a * Math.PI / 180), sn = Math.sin(a * Math.PI / 180), bins = new Float32Array(h * 2 + 4), j, off = h * 0.5 + 2;
      for (j = 0; j < px.length; j += step) { var ix = px[j] % w, iy = (px[j] / w) | 0, y = iy * cs - ix * sn + off | 0; if (y >= 0 && y < bins.length) bins[y]++; }
      var t = 0; for (j = 1; j < bins.length; j++) { var df = bins[j] - bins[j - 1]; t += df * df; } return t;
    }
    var best = 0, bs = -1, a; for (a = -6; a <= 6; a += 0.5) { var sc = score(a); if (sc > bs) { bs = sc; best = a; } }
    var b2 = best; for (a = best - 0.5; a <= best + 0.5; a += 0.1) { var s2 = score(a); if (s2 > bs) { bs = s2; b2 = a; } }
    return b2;
  }
  function straighten(c, deg) {
    if (Math.abs(deg) < 0.25) return c; var o = document.createElement('canvas'), r = deg * Math.PI / 180; o.width = c.width; o.height = c.height;
    var x = o.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, o.width, o.height); x.translate(o.width / 2, o.height / 2); x.rotate(-r); x.drawImage(c, -c.width / 2, -c.height / 2); return o;
  }
  function prepare(src, rot) { var c = toCanvas(src, rot || 0); flatten(c); return straighten(c, skew(c)); }

  SC._skew = skew; SC._prep = prepare;
  function loadBitmap(file) {
    if (window.createImageBitmap) return createImageBitmap(file, { imageOrientation: 'from-image' }).catch(function () { return viaImg(file); });
    return viaImg(file);
  }
  function viaImg(file) { return new Promise(function (ok, bad) { var u = URL.createObjectURL(file), i = new Image(); i.onload = function () { ok(i); }; i.onerror = function () { bad(new Error('Could not open that picture')); }; i.src = u; }); }
  function thumbOf(bm) { var k = Math.min(1, 220 / Math.max(bm.width, bm.height)), c = document.createElement('canvas'); c.width = Math.round(bm.width * k); c.height = Math.round(bm.height * k); c.getContext('2d').drawImage(bm, 0, 0, c.width, c.height); return c.toDataURL('image/jpeg', .7); }

  /* ---------------------------------------------------------------- reading */
  function read(pages, lang, o) {
    var cancel = o.cancel, worker = null, cancelled = function () { var e = new Error('cancelled'); e.cancelled = true; return e; };
    function stop() { var p = worker ? worker.terminate().catch(function () { }) : Promise.resolve(); worker = null; return p; }
    var cur = { p: 0 };
    return THK._ocrLoad().then(function (T) {
      o.progress(0, pages.length, 'Loading the language (first time: downloading)…', 0);
      return T.createWorker(lang, 1, { langPath: LANGPATH[o.quality], cachePath: 'fn-' + o.quality, gzip: false, cacheMethod: 'write', logger: function (e) { if (e && e.status) o.progress(cur.p, pages.length, e.status, e.progress || 0); } });
    }).then(function (w) {
      worker = w; var rows = [], conf = [], i = 0;
      return Promise.resolve(w.setParameters ? w.setParameters({ preserve_interword_spaces: '1', user_defined_dpi: '300' }) : 0).catch(function () { }).then(function () {
        function next() {
          if (cancel.v) throw cancelled(); if (i >= pages.length) return rows;
          var pg = pages[i]; cur.p = ++i; o.progress(i, pages.length, 'Cleaning page ' + i + ' of ' + pages.length + '…', 0);
          return new Promise(function (r) { setTimeout(r, 30); }).then(function () { return loadBitmap(pg.file); }).then(function (bm) {
            var cv = prepare(bm, pg.rot); try { bm.close && bm.close(); } catch (e) { }
            o.progress(i, pages.length, 'Reading page ' + i + ' of ' + pages.length + '…', 0);
            return w.recognize(cv).then(function (res) {
              var sc = cv.width / 612, pw = 612, ph = cv.height / sc, items = [], lines = (res.data && res.data.lines) || [];
              lines.forEach(function (ln) {
                var words = (ln.words || []).filter(function (x) { return x.text && x.text.trim(); }), seg = null, h = Math.max(4, (ln.bbox.y1 - ln.bbox.y0) / sc);
                words.forEach(function (x) {
                  if (x.confidence != null) conf.push(x.confidence);
                  var x0 = x.bbox.x0 / sc, x1 = x.bbox.x1 / sc, y = ph - ln.bbox.y1 / sc + h * 0.2;
                  if (seg && x0 - seg.x1 < pw * 0.05) { seg.t += ' ' + x.text; seg.x1 = x1; } else { if (seg) items.push(seg); seg = { t: x.text, x0: x0, x1: x1, y: y, h: h }; }
                });
                if (seg) items.push(seg);
              });
              rows.push(THK._pageRows({ items: items.map(function (s) { return { str: s.t, transform: [s.h * 0.8, 0, 0, s.h * 0.8, s.x0, s.y], width: s.x1 - s.x0, height: s.h * 0.8 }; }) }, pw, ph));
              cv.width = cv.height = 0; return next();
            });
          });
        }
        return next();
      }).then(function (pgs) {
        var avg = conf.length ? conf.reduce(function (a, b) { return a + b; }, 0) / conf.length : 0, low = conf.filter(function (c) { return c < 60; }).length;
        return stop().then(function () { return { pages: pgs, info: { avg: Math.round(avg), low: low, words: conf.length } }; });
      });
    }).catch(function (e) { return stop().then(function () { throw e; }); });
  }

  /* ---------------------------------------------------------------- the window */
  SC.open = function () {
    var a = A(), st = { pages: [], lang: 'mal', eng: true, lang2: '', best: true, layout: 'auto' };
    try { st.lang = localStorage.getItem('fn_scanlang') || 'mal'; } catch (e) { }
    var box = el('div', 'scn');
    var intro = el('p', 'xsub'); intro.textContent = 'Photograph the pages or pick pictures from your gallery. They are read on this device and turned into an editable script – Standard or Two Column is sensed automatically.'; box.appendChild(intro);
    var tray = el('div', 'scnpg'); box.appendChild(tray);
    var add = el('div', 'xrow'); box.appendChild(add);
    function pill(label, fn, on) { var b = el('button', 'btn' + (on ? ' on' : '')); b.type = 'button'; b.textContent = label; b.onclick = function () { fn(b); }; return b; }
    function pick(capture, multi) {
      var f = el('input'); f.type = 'file'; f.accept = 'image/*'; if (capture) f.setAttribute('capture', 'environment'); if (multi) f.multiple = true;
      f.onchange = function () { var fl = [].slice.call(f.files || []); Promise.all(fl.map(function (file) { return loadBitmap(file).then(function (bm) { var t = thumbOf(bm); try { bm.close && bm.close(); } catch (e) { } st.pages.push({ file: file, thumb: t, rot: 0 }); }).catch(function () { a.toast('Could not open ' + file.name); }); })).then(drawTray); };
      f.click();
    }
    add.appendChild(pill('Take photo', function () { pick(true, false); })); add.appendChild(pill('Choose from gallery', function () { pick(false, true); }));
    function drawTray() {
      tray.innerHTML = '';
      st.pages.forEach(function (p, i) {
        var c = el('div', 'scnc'), im = el('img'); im.src = p.thumb; im.style.transform = 'rotate(' + p.rot + 'deg)'; im.alt = 'Page ' + (i + 1); var w = el('div', 'scni'); w.appendChild(im); c.appendChild(w);
        var n = el('span', 'scnn'); n.textContent = String(i + 1); c.appendChild(n);
        var r = el('div', 'scnb');
        function mini(t, title, fn) { var b = el('button', 'btn'); b.type = 'button'; b.textContent = t; b.title = title; b.onclick = fn; r.appendChild(b); return b; }
        var l = mini('◀', 'Move earlier', function () { if (i > 0) { st.pages.splice(i - 1, 0, st.pages.splice(i, 1)[0]); drawTray(); } }); l.disabled = i === 0;
        mini('↻', 'Rotate', function () { p.rot = (p.rot + 90) % 360; drawTray(); });
        var rt = mini('▶', 'Move later', function () { if (i < st.pages.length - 1) { st.pages.splice(i + 1, 0, st.pages.splice(i, 1)[0]); drawTray(); } }); rt.disabled = i === st.pages.length - 1;
        mini('✕', 'Remove', function () { st.pages.splice(i, 1); drawTray(); });
        c.appendChild(r); tray.appendChild(c);
      });
      tray.style.display = st.pages.length ? '' : 'none'; cnt.textContent = st.pages.length ? st.pages.length + (st.pages.length === 1 ? ' page' : ' pages') + ' ready – the order here is the order of the script.' : 'No pages yet.';
    }
    var cnt = el('div', 'xsub'); box.appendChild(cnt);
    function head(t) { var h = el('div', 'xhd'); h.textContent = t; box.appendChild(h); }
    head('Language of the writing');
    var s1 = el('select', 't'); LANGS.forEach(function (l) { var o = el('option'); o.value = l[0]; o.textContent = l[1]; s1.appendChild(o); }); s1.value = st.lang; s1.onchange = function () { st.lang = s1.value; }; box.appendChild(s1); a.upgradeSelect(s1);
    var r1 = el('div', 'xrow'); box.appendChild(r1);
    var eb = pill('Also read English', function (b) { st.eng = !st.eng; b.classList.toggle('on', st.eng); }, true); r1.appendChild(eb);
    var s2 = el('select', 't'); var n0 = el('option'); n0.value = ''; n0.textContent = 'Add another language'; s2.appendChild(n0); LANGS.forEach(function (l) { var o = el('option'); o.value = l[0]; o.textContent = 'Also: ' + l[1]; s2.appendChild(o); }); s2.onchange = function () { st.lang2 = s2.value; }; box.appendChild(s2); a.upgradeSelect(s2);
    head('Layout');
    var r2 = el('div', 'xrow'); box.appendChild(r2); var bt = {};
    [['auto', 'Detect automatically'], ['std', 'Standard'], ['two', 'Two Column']].forEach(function (l) { var b = pill(l[1], function () { st.layout = l[0]; for (var k in bt) bt[k].classList.toggle('on', k === l[0]); }, st.layout === l[0]); bt[l[0]] = b; r2.appendChild(b); });
    head('Accuracy');
    var r3 = el('div', 'xrow'); box.appendChild(r3); var q1 = pill('Best accuracy', function () { st.best = true; q1.classList.add('on'); q2.classList.remove('on'); }, true), q2 = pill('Faster', function () { st.best = false; q2.classList.add('on'); q1.classList.remove('on'); }, false); r3.appendChild(q1); r3.appendChild(q2);
    var tip = el('div', 'xsub'); tip.textContent = 'For the best result: good even light, the page flat and filling the picture, dark ink on light paper. Typed or printed pages read very well; neat handwriting is read less reliably, so check the review screen. The first time a language is used it downloads once (about 3–15 MB); after that it works offline.'; box.appendChild(tip);
    drawTray();
    a.dlg('Scan to Script', box, [{ l: 'Cancel' }, { l: 'Read pages', cls: 'pri', fn: function () { if (!st.pages.length) { a.toast('Add at least one page'); return false; } run(st); } }]);
  };

  function run(st) {
    var a = A(), langs = [st.lang]; if (st.lang2 && langs.indexOf(st.lang2) < 0) langs.push(st.lang2); if (st.eng && langs.indexOf('eng') < 0) langs.push('eng');
    try { localStorage.setItem('fn_scanlang', st.lang); } catch (e) { }
    var cancel = { v: false }, box = el('div', ''), msg = el('p'), bar = el('div'); msg.textContent = 'Starting…'; bar.innerHTML = '<div style="height:8px;border-radius:99px;background:rgba(128,128,128,.25);overflow:hidden"><div class="scnbar" style="height:100%;width:2%;border-radius:99px;background:var(--acc,#5e6cf2);transition:width .25s"></div></div>';
    box.appendChild(msg); box.appendChild(bar);
    var d2 = a.dlg('Reading your pages…', box, [{ l: 'Cancel', fn: function () { cancel.v = true; } }], { nofocus: true }), fill = bar.querySelector('.scnbar');
    var ropt = { cancel: cancel, quality: st.best ? 'best' : 'fast', progress: function (p, n, s, fr) { msg.textContent = s.length > 60 ? s.slice(0, 60) + '…' : s; var v = ((p ? p - 1 : 0) + (fr || 0)) / (n || 1); fill.style.width = Math.max(2, Math.min(100, Math.round(v * 100))) + '%'; } };
    read(st.pages, langs.join('+'), ropt).then(function (r) {
      d2.close(); var name = 'Scanned script';
      var doc; try { doc = THK.pdfPagesToScript(r.pages, name, { method: 'Scan (' + langs.join('+') + ')', ocrDone: true, ocrInfo: r.info, layout: st.layout }); }
      catch (e) { if (e && e.needOcr) { a.dlg('No text found', '<p>Nothing readable was found in these pictures. Try again with brighter, even light, hold the camera straight above the page, and make sure the right language is selected.</p>', [{ l: 'OK', cls: 'pri' }]); return; } throw e; }
      var app = LMAP[st.lang]; if (app && THK.LANGS.some(function (l) { return l.id === app; })) doc.lang = app;
      return THK.pdfReview(doc).then(function (ok) { if (ok) a.finishImport([doc], name); });
    }).catch(function (e) {
      try { d2.close(); } catch (x) { }
      if (e && e.cancelled) return; a.dlg('Could not read the pages', '<p>' + a.esc(e && e.status === 400 && /key/i.test(e.message) ? 'The Google AI key was not accepted. Check that you pasted the whole key.' : e && e.status === 429 ? 'The free limit of the AI service was reached for now. Wait a minute and try again, or use "On this phone".' : /failed to fetch|network/i.test((e && e.message) || '') ? 'No internet connection. Connect and try again, or use "On this phone".' : (e && e.message) || 'Unknown error') + '</p>', [{ l: 'OK', cls: 'pri' }]);
    });
  }

  var css = document.createElement('style'); css.textContent =
    '.scn{display:flex;flex-direction:column;gap:8px;min-width:0}.scn .xrow{display:flex;flex-wrap:wrap;gap:8px}.scn .ddp{width:100%;justify-content:space-between}' +
    '.scnpg{display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:8px}.scnc{position:relative;border-radius:16px;padding:6px;background:var(--glass2,var(--glass));border:1px solid var(--edge);display:flex;flex-direction:column;gap:5px;align-items:center}' +
    '.scni{width:100%;aspect-ratio:3/4;display:grid;place-items:center;overflow:hidden;border-radius:10px;background:#fff}.scni img{max-width:100%;max-height:100%;transition:transform .2s}.scnn{position:absolute;left:8px;top:8px;min-width:22px;height:22px;border-radius:11px;display:grid;place-items:center;font-size:.72em;font-weight:700;background:var(--acc);color:var(--onacc,#fff)}' +
    '.scnb{display:flex;gap:3px;flex-wrap:wrap;justify-content:center}.scnb .btn{padding:2px 8px;font-size:.78em;min-width:0}.scnb .btn:disabled{opacity:.3}';
  document.head.appendChild(css);
})();
