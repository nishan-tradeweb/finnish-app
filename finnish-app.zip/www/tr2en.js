/* Translate – turns a script written in any language into a new script in the language you pick (the original stays untouched). English is the default.
   Uses Google's free translate service, so it needs internet. Character names are turned into English letters by sound and shown to you first,
   so every name is spelled the same way all through the script. */
(function () {
  'use strict';
  var A = THK.app, el = A.el, esc = A.esc, T = THK.tr2en = {}, TL = 'en', TLN = 'English';
  /* Google Translate languages: [code, English name, native name] */
  var LANGS = [['af','Afrikaans','Afrikaans'],['sq','Albanian','Shqip'],['am','Amharic','አማርኛ'],['ar','Arabic','العربية'],['hy','Armenian','Հայերեն'],['as','Assamese','অসমীয়া'],['az','Azerbaijani','Azərbaycan'],['eu','Basque','Euskara'],['be','Belarusian','Беларуская'],['bn','Bengali','বাংলা'],['bho','Bhojpuri','भोजपुरी'],['bs','Bosnian','Bosanski'],['bg','Bulgarian','Български'],['my','Burmese','မြန်မာ'],['ca','Catalan','Català'],['ceb','Cebuano','Cebuano'],['zh-CN','Chinese (Simplified)','简体中文'],['zh-TW','Chinese (Traditional)','繁體中文'],['co','Corsican','Corsu'],['hr','Croatian','Hrvatski'],['cs','Czech','Čeština'],['da','Danish','Dansk'],['dv','Dhivehi','ދިވެހި'],['doi','Dogri','डोगरी'],['nl','Dutch','Nederlands'],['en','English','English'],['eo','Esperanto','Esperanto'],['et','Estonian','Eesti'],['fil','Filipino','Filipino'],['fi','Finnish','Suomi'],['fr','French','Français'],['fy','Frisian','Frysk'],['gl','Galician','Galego'],['ka','Georgian','ქართული'],['de','German','Deutsch'],['el','Greek','Ελληνικά'],['gn','Guarani','Avañeʼẽ'],['gu','Gujarati','ગુજરાતી'],['ht','Haitian Creole','Kreyòl'],['ha','Hausa','Hausa'],['haw','Hawaiian','ʻŌlelo Hawaiʻi'],['iw','Hebrew','עברית'],['hi','Hindi','हिन्दी'],['hmn','Hmong','Hmoob'],['hu','Hungarian','Magyar'],['is','Icelandic','Íslenska'],['ig','Igbo','Igbo'],['ilo','Ilocano','Ilokano'],['id','Indonesian','Indonesia'],['ga','Irish','Gaeilge'],['it','Italian','Italiano'],['ja','Japanese','日本語'],['jw','Javanese','Basa Jawa'],['kn','Kannada','ಕನ್ನಡ'],['kk','Kazakh','Қазақша'],['km','Khmer','ខ្មែរ'],['rw','Kinyarwanda','Kinyarwanda'],['gom','Konkani','कोंकणी'],['ko','Korean','한국어'],['kri','Krio','Krio'],['ku','Kurdish','Kurdî'],['ckb','Kurdish (Sorani)','کوردی'],['ky','Kyrgyz','Кыргызча'],['lo','Lao','ລາວ'],['la','Latin','Latina'],['lv','Latvian','Latviešu'],['ln','Lingala','Lingála'],['lt','Lithuanian','Lietuvių'],['lg','Luganda','Luganda'],['lb','Luxembourgish','Lëtzebuergesch'],['mk','Macedonian','Македонски'],['mai','Maithili','मैथिली'],['mg','Malagasy','Malagasy'],['ms','Malay','Bahasa Melayu'],['ml','Malayalam','മലയാളം'],['mt','Maltese','Malti'],['mi','Maori','Māori'],['mr','Marathi','मराठी'],['mni-Mtei','Meiteilon (Manipuri)','ꯃꯩꯇꯩꯂꯣꯟ'],['lus','Mizo','Mizo'],['mn','Mongolian','Монгол'],['ne','Nepali','नेपाली'],['no','Norwegian','Norsk'],['ny','Nyanja (Chichewa)','Chichewa'],['or','Odia (Oriya)','ଓଡ଼ିଆ'],['om','Oromo','Oromoo'],['ps','Pashto','پښتو'],['fa','Persian','فارسی'],['pl','Polish','Polski'],['pt','Portuguese','Português'],['pa','Punjabi','ਪੰਜਾਬੀ'],['qu','Quechua','Runasimi'],['ro','Romanian','Română'],['ru','Russian','Русский'],['sm','Samoan','Gagana Samoa'],['sa','Sanskrit','संस्कृतम्'],['gd','Scots Gaelic','Gàidhlig'],['nso','Sepedi','Sepedi'],['sr','Serbian','Српски'],['st','Sesotho','Sesotho'],['sn','Shona','chiShona'],['sd','Sindhi','سنڌي'],['si','Sinhala','සිංහල'],['sk','Slovak','Slovenčina'],['sl','Slovenian','Slovenščina'],['so','Somali','Soomaali'],['es','Spanish','Español'],['su','Sundanese','Basa Sunda'],['sw','Swahili','Kiswahili'],['sv','Swedish','Svenska'],['tg','Tajik','Тоҷикӣ'],['ta','Tamil','தமிழ்'],['tt','Tatar','Татарча'],['te','Telugu','తెలుగు'],['th','Thai','ไทย'],['ti','Tigrinya','ትግርኛ'],['ts','Tsonga','Xitsonga'],['tr','Turkish','Türkçe'],['tk','Turkmen','Türkmen'],['ak','Twi','Twi'],['uk','Ukrainian','Українська'],['ur','Urdu','اردو'],['ug','Uyghur','ئۇيغۇرچە'],['uz','Uzbek','Oʻzbek'],['vi','Vietnamese','Tiếng Việt'],['cy','Welsh','Cymraeg'],['xh','Xhosa','isiXhosa'],['yi','Yiddish','ייִדיש'],['yo','Yoruba','Yorùbá'],['zu','Zulu','isiZulu']];
  var POP = ['en', 'hi', 'ml', 'ta', 'te', 'kn', 'bn', 'mr', 'gu', 'pa', 'ur', 'ar', 'es', 'fr', 'de', 'zh-CN', 'ja', 'ko', 'ru', 'pt'];
  T.langs = LANGS;
  function post(q, extra) { return THK.net.gtx({ sl: 'auto', tl: TL, dt: extra ? ['t', 'rm'] : ['t'], q: q }); }
  function retry(fn, n) { return fn().catch(function (e) { if (n <= 0 || (e && e.cancelled)) throw e; return new Promise(function (ok) { setTimeout(ok, 700 * (4 - n)); }).then(function () { return retry(fn, n - 1); }); }); }
  function netErr(e) { return new Error(THK.net.explain(e)); }

  /* one string -> English (keeps the line breaks inside it) */
  function one(s) { return retry(function () { return post(s); }, 2).then(function (d) { return { t: (d[0] || []).map(function (x) { return x && x[0] || ''; }).join(''), sl: d[2] }; }); }
  /* many single-line strings in one request; falls back to one-by-one if Google changes the number of lines */
  function many(list, st) {
    if (!list.length) return Promise.resolve([]);
    var txt = list.join('\n');
    return retry(function () { return post(txt); }, 2).then(function (d) {
      if (d[2] && !st.sl) st.sl = d[2];
      var out = (d[0] || []).map(function (x) { return x && x[0] || ''; }).join('').split('\n');
      if (out.length === list.length) return out.map(function (s) { return s.replace(/\s+$/, ''); });
      var res = []; return list.reduce(function (p, s, i) { return p.then(function () { if (st.cancel) throw { cancelled: true }; return one(s).then(function (r) { res[i] = r.t; }); }); }, Promise.resolve()).then(function () { return res; });
    });
  }
  /* a name -> its sound in English letters */
  function nameSound(n) {
    return retry(function () { return post(n, '&dt=rm'); }, 2).then(function (d) {
      var tr = '', en = '';
      (d[0] || []).forEach(function (seg) { if (!seg) return; en += seg[0] || ''; if (seg[3]) tr += seg[3]; });
      var s = (tr || en || n).trim();
      return s.replace(/\b([a-z])/g, function (m) { return m.toUpperCase(); });
    });
  }

  var HEAD = [[/^(inside|interior|indoors?|int\b)[\s.,:\-–]*/i, 'INT. '], [/^(outside|exterior|outdoors?|ext\b)[\s.,:\-–]*/i, 'EXT. ']];
  function fixHead(s) { s = s.trim(); if (!/^(INT|EXT|I\/E)\b/i.test(s)) for (var i = 0; i < HEAD.length; i++) if (HEAD[i][0].test(s)) { s = s.replace(HEAD[i][0], HEAD[i][1]); break; } return s.toUpperCase(); }
  function isLatin(s) { return !/[^\u0000-ɏ -⁯\s]/.test(s); }

  /* language picker: search box + popular languages first, same look as every other list in the app */
  function pickLang(cb) {
    var w = el('div', ''), q = el('input', 't'); q.type = 'search'; q.placeholder = 'Search a language…'; var list = el('div', 'trlist');
    w.appendChild(el('p', '', 'Translate this script into which language? The original is kept; a new script is made.')); w.appendChild(q); w.appendChild(list);
    var d; var last = (A.S && A.S.trLang) || 'en';
    function row(l) { var b = el('button', 'btn' + (l[0] === last ? ' on' : ''), '<span>' + esc(l[1]) + '</span><small>' + esc(l[2]) + '</small>'); b.type = 'button'; b.onclick = function () { d.close(); try { A.S.trLang = l[0]; A.saveS(); } catch (e) { } cb(l[0], l[1]); }; return b; }
    function draw() {
      var v = q.value.trim().toLowerCase(); list.innerHTML = '';
      var items = v ? LANGS.filter(function (l) { return l[1].toLowerCase().indexOf(v) >= 0 || l[2].toLowerCase().indexOf(v) >= 0 || l[0].toLowerCase() === v; }) : POP.map(function (c) { return LANGS.filter(function (l) { return l[0] === c; })[0]; });
      if (!v) list.appendChild(el('div', 'trh', 'Popular'));
      items.forEach(function (l) { list.appendChild(row(l)); });
      if (!v) { list.appendChild(el('div', 'trh', 'All languages')); LANGS.forEach(function (l) { if (POP.indexOf(l[0]) < 0) list.appendChild(row(l)); }); }
      if (v && !items.length) list.appendChild(el('p', '', 'No language found'));
    }
    q.oninput = draw; draw();
    d = A.dlg('Translate', w, [{ l: 'Cancel' }], { nofocus: true });
  }
  T.run = function () {
    if (!A.cur) return;
    pickLang(function (c, n) { TL = c; TLN = n; start(); });
  };
  function start() {
    var cur = A.cur; if (!cur) return;
    var blocks = cur.blocks.filter(function (b) { return b.t !== 'img'; });
    if (!blocks.some(function (b) { return (b.x || '').trim(); })) return A.toastIn('There is nothing to translate yet');
    var st = { cancel: false, sl: '' };
    var names = {}, order = [];
    if (TL === 'en') blocks.forEach(function (b) { if (b.t === 'char') { var n = (b.x || '').replace(/\(.*?\)/g, '').replace(/[:：]\s*$/, '').trim(); if (n && !names[n]) { names[n] = ''; order.push(n); } } });
    var wrap = el('div', ''), msg = el('p', '', 'Finding the character names…'), bar = el('div', '', '<div style="height:8px;border-radius:99px;background:rgba(128,128,128,.25);overflow:hidden"><div class="ocrbar" style="height:100%;width:2%;border-radius:99px;background:#5e6cf2;transition:width .25s"></div></div>');
    wrap.appendChild(msg); wrap.appendChild(bar); var fill = bar.querySelector('.ocrbar');
    var d1 = A.dlg('Translate', wrap, [{ l: 'Cancel', fn: function () { st.cancel = true; } }], { nofocus: true });
    function prog(v, t) { fill.style.width = Math.max(2, Math.min(100, Math.round(v * 100))) + '%'; if (t) msg.textContent = t; }
    function chk() { if (st.cancel) throw { cancelled: true }; }
    /* step 1 – names */
    var i = 0, p = Promise.resolve();
    order.forEach(function (n) {
      p = p.then(function () { chk(); return isLatin(n) ? n : nameSound(n); }).then(function (s) { names[n] = s; i++; prog(0.2 * i / Math.max(1, order.length)); });
    });
    p.then(function () { chk(); d1.close(); return askNames(names, order); }).then(function (map) {
      if (!map) return;
      var d2 = A.dlg('Translating…', (function () { var w = el('div', ''); w.appendChild(msg); w.appendChild(bar); return w; })(), [{ l: 'Cancel', fn: function () { st.cancel = true; } }], { nofocus: true });
      prog(0.02, 'Translating the script… (keep the app open)');
      return translateAll(cur, map, st, prog).then(function (copy) { d2.close(); if (!copy) return; done(copy, st); }, function (e) { d2.close(); throw e; });
    }).catch(function (e) {
      try { d1.close(); } catch (x) { }
      if (e && e.cancelled) return A.toastIn('Translation cancelled');
      A.dlg('Could not translate', '<p>' + esc(netErr(e).message) + '</p>', [{ l: 'Close', cls: 'pri' }]);
    });
  }

  function askNames(names, order) {
    return new Promise(function (resolve) {
      if (!order.length) return resolve({});
      var w = el('div', ''), list = el('div', 'pdflist'), inputs = {};
      w.appendChild(el('p', '', 'These are the character names as they sound in English letters. Fix any spelling now – every place the name appears will use it.'));
      order.forEach(function (n) { var r = el('div', 'trrow'); r.appendChild(el('span', 'trsrc', esc(n))); var i = el('input'); i.type = 'text'; i.value = names[n]; i.setAttribute('autocapitalize', 'words'); inputs[n] = i; r.appendChild(i); list.appendChild(r); });
      w.appendChild(list);
      A.dlg('Check the names (' + order.length + ')', w, [{ l: 'Cancel', fn: function () { resolve(null); } }, { l: 'Translate', cls: 'pri', fn: function () { var m = {}; order.forEach(function (n) { m[n] = (inputs[n].value || names[n]).trim(); }); resolve(m); } }], { nofocus: true });
    });
  }

  function translateAll(cur, nameMap, st, prog) {
    var uniq = {}, list = [];
    function want(s) { s = (s || '').replace(/\s*\n\s*/g, ' ').trim(); if (s && !uniq.hasOwnProperty(s)) { uniq[s] = null; list.push(s); } return s; }
    cur.blocks.forEach(function (b) { if (b.t === 'img') return; if (b.t === 'char') { if (TL !== 'en') want((b.x || '').replace(/\(.*?\)/g, '').replace(/[:：]\s*$/, '')); return; } want(b.x); if (b.x2) want(b.x2); });
    want(cur.title);
    /* progress is kept on this device, so a long script that stops half way carries on from where it stopped */
    var ckey = 'fn_trc_' + (cur.id || '') + '_' + TL, cache = {};
    try { cache = JSON.parse(localStorage.getItem(ckey) || '{}') || {}; } catch (e) { cache = {}; }
    function saveCache() { try { localStorage.setItem(ckey, JSON.stringify(cache)); } catch (e) { } }
    var left = list.filter(function (s) { if (cache.hasOwnProperty(s)) { uniq[s] = cache[s]; return false; } return true; });
    /* small parts, cut at scene headings so every request keeps its context */
    var sceneHeads = {}; cur.blocks.forEach(function (b) { if (b.t === 'scene') { var k = (b.x || '').replace(/\s*\n\s*/g, ' ').trim(); if (k) sceneHeads[k] = 1; } });
    var batches = [], bt = [], len = 0;
    left.forEach(function (s) { if (bt.length && (len + s.length > 1000 || bt.length >= 25 || sceneHeads[s] && bt.length >= 8)) { batches.push(bt); bt = []; len = 0; } bt.push(s); len += s.length + 1; });
    if (bt.length) batches.push(bt);
    var total = batches.length, done = 0, conc = 2, idx = 0, finished = 0, bad = 0, stop = false;
    function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
    /* one part: up to 4 tries with a growing pause; after the first miss the part is cut in halves */
    function part(arr, tries) {
      if (st.cancel) return Promise.reject({ cancelled: true });
      return many(arr, st).then(function (out) { arr.forEach(function (s, k) { var t = (out[k] || '').trim() || s; uniq[s] = t; cache[s] = t; }); saveCache(); },
        function (e) {
          if (e && e.cancelled) throw e;
          if (tries >= 3) throw e;
          return wait(1500 * Math.pow(2, tries)).then(function () {
            if (arr.length > 3) { var h = Math.ceil(arr.length / 2); return part(arr.slice(0, h), tries + 1).then(function () { return part(arr.slice(h), tries + 1); }); }
            return part(arr, tries + 1);
          });
        });
    }
    return new Promise(function (resolve, reject) {
      if (!total) { cache = {}; try { localStorage.removeItem(ckey); } catch (e) { } return resolve(build()); }
      prog(0.05, 'Translating… part 0 of ' + total + (list.length > left.length ? ' (carrying on from last time)' : ''));
      function end() {
        if (stop) return;
        if (finished < total) return;
        if (bad) { stop = true; var er = new Error(bad + ' of ' + total + ' parts could not be translated (the free translation service did not answer). Everything done so far is saved on this device – press Translate again to carry on from here.'); er.keep = 1; return reject(er); }
        try { localStorage.removeItem(ckey); } catch (e) { } stop = true; resolve(build());
      }
      function next() {
        if (stop) return; if (st.cancel) { stop = true; return reject({ cancelled: true }); }
        if (idx >= total) return end();
        var b = batches[idx++];
        part(b, 0).then(function () { done++; }, function (e) { if (e && e.cancelled) { stop = true; return reject(e); } bad++; }).then(function () {
          finished++; prog(0.05 + 0.93 * finished / total, 'Translating… part ' + finished + ' of ' + total + ' (' + Math.round(100 * finished / total) + '%)'); next();
        });
      }
      for (var k = 0; k < conc; k++) next();
    });

    function tr(s) { var k = (s || '').replace(/\s*\n\s*/g, ' ').trim(); return k ? (uniq[k] || k) : ''; }
    function build() {
      var c = JSON.parse(JSON.stringify(cur)); c.id = A.uid(); delete c.path; delete c.updated;
      var AL = TL.split('-')[0]; if (AL === 'iw') AL = 'he'; if (AL === 'fil') AL = 'tl'; if (AL === 'jw') AL = 'jv'; c.title = tr(cur.title) || cur.title; c.lang = AL; try { c.font = THK.defaultFont(AL) || c.font; } catch (e) { } delete c.titleFont; delete c.cfm;
      c.title = (c.title + ' (' + TLN + ')').slice(0, 120);
      c.blocks = c.blocks.map(function (b) {
        if (b.t === 'img') return b; delete b.fm;
        if (b.t === 'char') {
          var raw = b.x || '', core = raw.replace(/\(.*?\)/g, '').replace(/[:：]\s*$/, '').trim(), ext = (raw.match(/\((.*?)\)/) || [])[1];
          var nm = TL === 'en' ? (nameMap[core] || core) : (tr(core) || core); if (ext) nm += ' (' + (isLatin(ext) && TL === 'en' ? ext : (tr(ext) || ext)).toUpperCase() + ')'; b.x = nm.toUpperCase(); return b;
        }
        b.x = tr(b.x); if (b.t === 'scene') { b.x = TL === 'en' ? fixHead(b.x) : b.x.toUpperCase(); if (b.x2 != null) b.x2 = tr(b.x2).toUpperCase(); }
        else if (b.t === 'trans') b.x = b.x.toUpperCase();
        return b;
      });
      return c;
    }
  }

  function done(copy, st) {
    var w = el('div', '', '<p>Your ' + esc(TLN) + ' script is ready' + (st.sl ? ' (the original language was detected as <b>' + esc(st.sl) + '</b>)' : '') + '. The original script is unchanged. Machine translation is good for understanding, but please read it through before sharing.</p>');
    A.dlg('Done', w, [{ l: 'Stay here' }, { l: 'Open translated script', cls: 'pri', fn: function () { setTimeout(function () { A.openDoc(A.norm(copy), true); }, 60); } }]);
  }
  var st = document.createElement('style'); st.textContent = '.trrow{display:flex;gap:8px;align-items:center;margin:6px 0}.trsrc{flex:0 0 38%;opacity:.8;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.trrow input{flex:1;min-width:0;padding:8px 12px;border-radius:99px;border:1px solid rgba(128,128,128,.4);background:transparent;color:inherit;font:inherit}';
  document.head.appendChild(st);
})();
