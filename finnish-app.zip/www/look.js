/* finnish – look & feel: icon packs, corner style, Reduce Motion, micro-interactions, fluid navigation. */
(function () {
  var THK = window.THK = window.THK || {}, L = THK.look = {};
  var R = document.documentElement;
  function A() { return THK.app; }
  function S() { return THK.app && THK.app.S || {}; }
  function save() { try { THK.app.saveS(); } catch (e) { } }

  /* ---------- Reduce motion (default follows the phone's own setting) */
  L.rm = function () { var s = S(); if (s.rm === 1 || s.rm === 0) return !!s.rm; try { return matchMedia('(prefers-reduced-motion:reduce)').matches; } catch (e) { return false; } };
  L.applyRm = function () { if (L.rm()) R.setAttribute('data-rm', '1'); else R.removeAttribute('data-rm'); };
  L.toggleRm = function () { var s = S(); s.rm = L.rm() ? 0 : 1; save(); L.applyRm(); A().toast('Reduce motion: ' + (L.rm() ? 'On – lighter and smoother on slow phones' : 'Off – full animations')); };

  /* ---------- Corner style */
  var CORNERS = [['pill', 'Pill', 'Fully round – the signature look'], ['rounded', 'Rounded', 'Generous, friendly corners'], ['soft', 'Soft', 'Gentle, understated corners'], ['sharp', 'Sharp', 'Crisp, almost square edges']];
  var BIG = '.dlg,.panel,.wizcard,.paper-opt,.fbtn,.sv,#side,#top,#cTop,#nTop,#ribbon,.menu,.thprev,.thcard,.pc,#dock,.strip,#acc,#cAcc,#nAcc,.glass.card';
  var CTL = '.btn,.menu>button,.frow button,input.t,select.t,textarea.t,#dock select,.ddp,.tag';
  var SML = '.thsw,.thwarn,.pp,.side-item,.thcard .thsw,#nScroll,#scroll';
  function cornerCss() {
    var t = { rounded: [26, 16, 12], soft: [16, 10, 8], sharp: [4, 2, 2] }, o = '';
    Object.keys(t).forEach(function (k) {
      var v = t[k], p = 'html[data-corner=' + k + '] ';
      function sel(s) { return s.split(',').map(function (x) { return p + x; }).join(','); }
      o += sel(BIG) + '{border-radius:' + v[0] + 'px!important}' + sel(CTL) + '{border-radius:' + v[1] + 'px!important}' + sel(SML) + '{border-radius:' + v[2] + 'px!important}';
      o += sel('.thcard .thsw') + '{border-radius:' + v[2] + 'px!important}';
    });
    o += 'html[data-corner=sharp] .menu>button{border-radius:2px!important}';
    return o;
  }
  L.applyCorner = function () { var c = S().corner; if (c && c !== 'pill') R.setAttribute('data-corner', c); else R.removeAttribute('data-corner'); };

  /* ---------- Icon packs */
  var PACKS = [[0, 'finnish', 'icons/icon-192.png'], [1, 'Onyx', 'icons/packs/p1.webp'], [2, 'Gilded', 'icons/packs/p2.webp'], [3, 'Ruby Glass', 'icons/packs/p3.webp'], [4, 'Crimson Velvet', 'icons/packs/p4.webp'], [5, 'Gold Plate', 'icons/packs/p5.webp'], [6, 'Graphite', 'icons/packs/p6.webp'], [7, 'Chrome Noir', 'icons/packs/p7.webp'], [8, 'Neon Ruby', 'icons/packs/p8.webp']];
  L.PACKS = PACKS;
  function packOf(i) { for (var k = 0; k < PACKS.length; k++) if (PACKS[k][0] === i) return PACKS[k]; return PACKS[0]; }
  L.applyIcon = function () {
    var p = packOf(S().icon || 0), l = document.querySelector('link[rel=icon]'), a = document.querySelector('link[rel=apple-touch-icon]');
    if (l) l.href = p[2]; if (a && p[0]) a.href = p[2];
  };
  function setNative(i, done) {
    var fp = THK.fp && THK.fp();
    if (fp && fp.setIcon) { Promise.resolve(fp.setIcon({ pack: i })).then(function () { done(true); }, function () { done(false); }); } else done(null);
  }
  var SHAPES = [['circle', 'Circle', '50%'], ['squircle', 'Squircle', '30%'], ['square', 'Square', '14%']];
  L.iconUI = function (body, redraw) {
    var s = S(), shape = s.icShape || 'squircle';
    var sh = A().el('div', 'thtabs'); body.appendChild(sh);
    SHAPES.forEach(function (x) { var b = A().el('button', 'btn sm' + (shape === x[0] ? ' on' : ''), x[1]); b.onclick = function () { s.icShape = x[0]; save(); redraw(); }; sh.appendChild(b); });
    var g = A().el('div', 'thgrid icg'); body.appendChild(g);
    var rad = SHAPES.filter(function (x) { return x[0] === shape; })[0][2];
    PACKS.forEach(function (p) {
      var sel = (s.icon || 0) === p[0];
      var c = A().el('button', 'thcard' + (sel ? ' sel' : ''), '<span class="icv" style="border-radius:' + rad + '"><img alt="" src="' + p[2] + '"></span><b>' + A().esc(p[1]) + '</b>');
      c.onclick = function () {
        s.icon = p[0]; save(); L.applyIcon();
        setNative(p[0], function (ok) {
          if (ok === true) A().toast('App icon changed to ' + p[1] + ' – your launcher may take a few seconds to update');
          else if (ok === false) A().toast('Could not change the launcher icon on this phone. The in-app logo was updated.');
          else A().toast('Icon saved. The launcher icon changes in the Android app.');
          redraw();
        });
      };
      g.appendChild(c);
    });
    body.appendChild(A().el('p', 'thn', 'Android app only: the home-screen icon swaps instantly on most launchers. If yours keeps the old one, restart the launcher or the phone. Installed web apps (PWA) keep their original icon.'));
  };
  L.cornerUI = function (body, redraw) {
    var s = S();
    var g = A().el('div', 'thgrid'); body.appendChild(g); var cur = s.corner || 'pill';
    var R_ = { pill: [999, 26], rounded: [16, 20], soft: [10, 12], sharp: [2, 3] };
    CORNERS.forEach(function (c) {
      var r = R_[c[0]];
      var k = A().el('button', 'thcard' + (cur === c[0] ? ' sel' : ''), '<span class="crv"><i style="border-radius:' + r[0] + 'px"></i><u style="border-radius:' + r[1] + 'px"></u></span><b>' + c[1] + '</b><small>' + c[2] + '</small>');
      k.onclick = function () { s.corner = c[0]; save(); L.applyCorner(); redraw(); };
      g.appendChild(k);
    });
  };

  /* ---------- Fluid navigation: screens glide in the direction you are travelling */
  var DEPTH = { home: 0, wiz: 1, app: 2, nt: 2, cvEd: 3 }, last = null;
  function watch() {
    Object.keys(DEPTH).forEach(function (id) {
      var e = document.getElementById(id); if (!e) return;
      new MutationObserver(function () {
        if (e.hidden) return; if (L.rm()) { last = id; return; }
        var dir = last != null && DEPTH[id] < DEPTH[last] ? 'scr-back' : 'scr-fwd'; last = id;
        e.classList.remove('scr-back', 'scr-fwd'); void e.offsetWidth; e.classList.add(dir);
        setTimeout(function () { e.classList.remove('scr-back', 'scr-fwd'); }, 220);
      }).observe(e, { attributes: true, attributeFilter: ['hidden'] });
    });
  }


  /* ---------- Water ripples: touch the plain background only (never buttons, text, menus or the page) */
  var NOT = 'button,a,input,select,textarea,label,summary,[contenteditable],[role=button],.btn,.thcard,.menu,.dlg,.sv,.fbtn,.pc,.paper-opt,.side-item,.glass,#top,#ribbon,#dock,#side,#toast,#page,.page,.cine,#cine,.strip,.panel,.wizcard,.thprev,.ddp';
  var rl = null, rn = 0;
  function ripple(x, y) {
    if (!rl) { rl = document.createElement('div'); rl.id = 'ripples'; document.body.insertBefore(rl, document.body.firstChild); }
    if (rn > 7) return; rn++;
    var g = document.createElement('div'); g.className = 'rpl'; g.style.left = x + 'px'; g.style.top = y + 'px';
    g.innerHTML = '<i></i><i></i><i></i>'; rl.appendChild(g); setTimeout(function () { g.remove(); rn--; }, 2300);
  }
  function onTouch(e) {
    if (R.getAttribute('data-dyn') !== 'water' || R.hasAttribute('data-rm')) return;
    var t = e.target; if (!t || !t.closest || t.closest(NOT)) return;
    if (e.pointerType === 'mouse' && e.button) return; ripple(e.clientX, e.clientY);
  }
  document.addEventListener('pointerdown', onTouch, { passive: true });
  var RC = '#ripples{position:fixed;inset:0;z-index:0;pointer-events:none;overflow:hidden}.rpl{position:absolute;width:0;height:0}.rpl i{position:absolute;left:0;top:0;border-radius:50%;transform:translate(-50%,-50%) scale(.04);width:340px;height:340px;opacity:0;border:1.5px solid rgba(190,236,255,.55);box-shadow:0 0 18px rgba(116,214,255,.28),inset 0 0 22px rgba(116,214,255,.14),inset 0 0 2px rgba(255,255,255,.35);animation:rpl 2.1s cubic-bezier(.12,.6,.25,1) forwards}.rpl i:nth-child(2){animation-delay:.16s;border-color:rgba(190,236,255,.38)}.rpl i:nth-child(3){animation-delay:.34s;border-color:rgba(190,236,255,.24)}@keyframes rpl{0%{opacity:0;transform:translate(-50%,-50%) scale(.04)}12%{opacity:1}100%{opacity:0;transform:translate(-50%,-50%) scale(1.5)}}html:not([data-dyn=water]) #ripples{display:none}';
  var css = '.thcard{content-visibility:auto;contain-intrinsic-size:auto 118px}.thgrid{contain:layout style}' + RC + cornerCss() +
    '.icg{grid-template-columns:repeat(auto-fill,minmax(min(104px,44%),1fr))}.icv{display:block;width:72px;height:72px;overflow:hidden;box-shadow:0 6px 16px rgba(0,0,0,.28),inset 0 0 0 1px rgba(255,255,255,.12);transition:border-radius .25s}.icv img{width:100%;height:100%;object-fit:cover;display:block}' +
    '.crv{display:flex;gap:8px;align-items:center;justify-content:center;height:54px;width:100%}.crv i{display:block;width:44px;height:22px;background:var(--acc);opacity:.9}.crv u{display:block;width:28px;height:28px;background:var(--glass2);border:1px solid var(--edge)}' +
    /* micro-interactions */
    'html:not([data-rm]) .btn,html:not([data-rm]) .menu>button,html:not([data-rm]) .thcard,html:not([data-rm]) .fbtn,html:not([data-rm]) .sv,html:not([data-rm]) .pc,html:not([data-rm]) .paper-opt,html:not([data-rm]) .side-item,html:not([data-rm]) .frow button{transition:transform .14s ease-out;-webkit-tap-highlight-color:transparent}' +
    'html:not([data-rm]) .btn:active,html:not([data-rm]) .thcard:active,html:not([data-rm]) .fbtn:active,html:not([data-rm]) .sv:active,html:not([data-rm]) .pc:active,html:not([data-rm]) .paper-opt:active,html:not([data-rm]) .frow button:active{transform:scale(.96)}' +
    'html:not([data-rm]) .menu>button:active,html:not([data-rm]) .side-item:active{transform:scale(.97)}' +
    '@media(hover:hover){html:not([data-rm]) .btn:hover,html:not([data-rm]) .thcard:hover,html:not([data-rm]) .fbtn:hover,html:not([data-rm]) .sv:hover{transform:translateY(-1.5px)}}' +
    '' +
    'html:not([data-rm]) .dlg{animation:lkDlg .2s ease-out}@keyframes lkDlg{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}' +
    'html:not([data-rm]) #toast{transition:transform .3s cubic-bezier(.2,.9,.3,1.3),opacity .25s}' +
    'html:not([data-rm]) input[type=checkbox],html:not([data-rm]) input[type=radio]{transition:transform .18s}html:not([data-rm]) input[type=checkbox]:active{transform:scale(.88)}' +
    /* fluid navigation */
    '.scr-fwd,.scr-back{animation:scrF .16s ease-out}' +
    '@keyframes scrF{from{opacity:.0}to{opacity:1}}' +
    /* reduce motion: no animation, cheaper glass */
    'html[data-rm] *,html[data-rm] *::before,html[data-rm] *::after{animation-duration:.001s!important;animation-delay:0s!important;animation-iteration-count:1!important;transition-duration:.001s!important;scroll-behavior:auto!important}' +
    'html[data-rm] .glass,html[data-rm] .dlg,html[data-rm] .menu,html[data-rm] .btn,html[data-rm] #top,html[data-rm] #ribbon,html[data-rm] #dock{-webkit-backdrop-filter:blur(6px)!important;backdrop-filter:blur(6px)!important}' +
    'html[data-rm] body::before,html[data-rm] body::after,html[data-rm] .orb{animation:none!important}';
  var st = document.createElement('style'); st.id = 'look-css'; st.textContent = css; document.head.appendChild(st);

  L.boot = function () { L.applyRm(); L.applyCorner(); L.applyIcon(); try { matchMedia('(prefers-reduced-motion:reduce)').addEventListener('change', L.applyRm); } catch (e) { } watch(); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(L.boot, 0); }); else setTimeout(L.boot, 0);
})();

/* ---------- Typing gestures (only while the cursor is in the script) */
(function () {
  var THK = window.THK, g = null, EDGE = 40, busy = 0, comp = 0;
  function typing() { var a = document.activeElement; return !!(a && a.closest && a.closest('#page') && (a.isContentEditable || a.tagName === 'TEXTAREA' || a.tagName === 'INPUT')); }
  function selected() { try { var s = getSelection(); return !!(s && !s.isCollapsed && String(s).length); } catch (e) { return false; } }
  function scr() { return document.getElementById('scroll'); }
  function avg(t, k) { var a = t[0][k], b = t[1] ? t[1][k] : a; return (a + b) / 2; }
  function fire(kind) {
    var A = THK.app; if (!A || busy) return; busy = 1; setTimeout(function () { busy = 0; }, 320);
    try { navigator.vibrate && navigator.vibrate(8); } catch (e) { }
    if (kind === 'page') A.nextPage(); else if (kind === 'undo') { if (!A.undo()) A.toast('Nothing to undo'); } else { if (!A.redo()) A.toast('Nothing to redo'); }
  }
  document.addEventListener('compositionstart', function () { comp = 1; }, true);
  document.addEventListener('compositionend', function () { setTimeout(function () { comp = 0; }, 60); }, true);
  document.addEventListener('touchstart', function (e) {
    g = null; if (!THK.app || !e.target.closest || !e.target.closest('#page') || !typing()) return;
    var n = e.touches.length; if (n > 2) return; var x = avg(e.touches, 'clientX'), y = avg(e.touches, 'clientY');
    if (n === 1 && (x < EDGE || x > innerWidth - EDGE)) return;
    var s = scr(); g = { n: n, x: x, y: y, t: Date.now(), sel: selected(), top: s ? s.scrollTop : 0, px: x, py: y, bad: 0 };
  }, { passive: true });
  document.addEventListener('touchmove', function (e) {
    if (!g) return; var n = e.touches.length;
    if (n !== g.n) { if (n > g.n) g.bad = 1; return; }
    g.px = avg(e.touches, 'clientX'); g.py = avg(e.touches, 'clientY');
    if (g.n === 2 && e.cancelable) e.preventDefault(); /* two fingers are for the page-break gesture only: never scroll */
    if (g.n === 1) { var s = scr(); if (s && Math.abs(s.scrollTop - g.top) > 6) g.bad = 1; if (Math.abs(g.py - g.y) > 40) g.bad = 1; }
  }, { passive: false });
  document.addEventListener('touchcancel', function () { g = null; }, { passive: true });
  document.addEventListener('touchend', function (e) {
    if (!g) return; if (e.touches.length) return; var gg = g; g = null;
    if (gg.bad || comp || Date.now() - gg.t > (gg.n === 2 ? 1100 : 600)) return;
    var dx = gg.px - gg.x, dy = gg.py - gg.y;
    if (gg.n === 2) { if (dy > 70 && Math.abs(dx) < Math.abs(dy) * 0.8) fire('page'); return; }
    if (gg.sel || selected()) return;
    if (Math.abs(dx) > 90 && Math.abs(dy) < 36 && Math.abs(dx) > Math.abs(dy) * 3 && gg.px > EDGE && gg.px < innerWidth - EDGE) fire(dx < 0 ? 'undo' : 'redo');
  }, { passive: true });
})();
