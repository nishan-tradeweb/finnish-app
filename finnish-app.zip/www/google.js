/* finnish – Google sign-in and Google Drive access.
   Browser / web app: Google Identity Services pop-up.  Android: system browser with PKCE and a return link.  Windows / Mac app: system browser with a local return address.
   The app only ever asks for what it needs: sign-in = name and email; Drive backup = its own hidden app folder (drive.appdata). */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {}, G = THK.google = {}, CFG = (window.FINNISH_CONFIG || {}).google || {};
  var SIGNIN = 'openid email profile', DRIVE = 'https://www.googleapis.com/auth/drive.appdata';
  G.SIGNIN = SIGNIN; G.DRIVE = DRIVE;
  function cap() { try { var c = window.Capacitor; return c && c.isNativePlatform && c.isNativePlatform() ? c : null; } catch (e) { return null; } }
  function desk() { return window.finnishNative && window.finnishNative.googleAuth; }
  G.available = function () { return !!(cap() ? CFG.androidClientId : desk() ? CFG.desktopClientId : CFG.webClientId); };

  function b64url(buf) { var s = ''; new Uint8Array(buf).forEach(function (b) { s += String.fromCharCode(b); }); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function rnd(n) { var a = new Uint8Array(n); crypto.getRandomValues(a); return b64url(a); }
  function sha(s) { return crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)).then(b64url); }
  function form(o) { return Object.keys(o).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(o[k]); }).join('&'); }

  /* ---- web */
  var gis = null;
  function loadGis() {
    if (window.google && google.accounts && google.accounts.oauth2) return Promise.resolve();
    if (gis) return gis;
    gis = new Promise(function (res, rej) { var s = document.createElement('script'); s.src = 'https://accounts.google.com/gsi/client'; s.async = true; s.onload = res; s.onerror = function () { gis = null; rej(new Error('Could not reach Google. Check your internet connection.')); }; document.head.appendChild(s); });
    return gis;
  }
  function webToken(scope) {
    return loadGis().then(function () {
      return new Promise(function (res, rej) {
        var c = google.accounts.oauth2.initTokenClient({ client_id: CFG.webClientId, scope: scope, callback: function (r) { r && r.access_token ? res(r.access_token) : rej(new Error((r && r.error_description) || 'Google sign-in was cancelled.')); }, error_callback: function () { rej(new Error('Google sign-in was cancelled.')); } });
        c.requestAccessToken();
      });
    });
  }

  /* ---- Android */
  function androidToken(scope, C) {
    var Browser = C.Plugins && C.Plugins.Browser, App = C.Plugins && C.Plugins.App;
    if (!Browser || !App) return Promise.reject(new Error('Google sign-in is not available in this build.'));
    var verifier = rnd(48), state = rnd(16), redirect = 'app.finnish.writer:/oauth2redirect';
    return sha(verifier).then(function (chal) {
      var url = 'https://accounts.google.com/o/oauth2/v2/auth?' + form({ client_id: CFG.androidClientId, redirect_uri: redirect, response_type: 'code', scope: scope, state: state, code_challenge: chal, code_challenge_method: 'S256', prompt: 'select_account' });
      return new Promise(function (res, rej) {
        var h; App.addListener('appUrlOpen', function (ev) {
          if (!ev || !ev.url || ev.url.indexOf(redirect.split(':')[0] + ':') !== 0) return; if (h && h.remove) h.remove();
          try { Browser.close(); } catch (e) { }
          var q = {}; (ev.url.split('?')[1] || '').split('&').forEach(function (p) { var kv = p.split('='); q[kv[0]] = decodeURIComponent(kv[1] || ''); });
          if (q.error || q.state !== state || !q.code) return rej(new Error('Google sign-in was cancelled.'));
          fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ client_id: CFG.androidClientId, code: q.code, code_verifier: verifier, grant_type: 'authorization_code', redirect_uri: redirect }) })
            .then(function (r) { return r.json(); }).then(function (j) { j.access_token ? res(j.access_token) : rej(new Error('Google did not complete sign-in.')); }, function () { rej(new Error('Could not reach Google. Check your internet connection.')); });
        }).then(function (l) { h = l; });
        Browser.open({ url: url });
      });
    });
  }

  /* scope: G.SIGNIN or G.DRIVE (Drive also needs the sign-in scopes granted once; Google remembers them) */
  G.token = function (scope) {
    if (!G.available()) return Promise.reject(new Error('Google sign-in is not set up in this build.'));
    var C = cap(); if (C) return androidToken(scope, C);
    if (desk()) return window.finnishNative.googleAuth(scope, CFG.desktopClientId, CFG.desktopClientSecret).then(function (t) { if (!t) throw new Error('Google sign-in was cancelled.'); return t; });
    return webToken(scope);
  };

  /* ---- Drive: the app's own hidden folder (appDataFolder). One file per backup, newest kept. */
  function api(t, path, opt) { opt = opt || {}; opt.headers = Object.assign({ Authorization: 'Bearer ' + t }, opt.headers || {}); return fetch('https://www.googleapis.com/' + path, opt).then(function (r) { if (!r.ok) throw new Error('Google Drive answered ' + r.status + '. Try again.'); return r; }, function () { throw new Error('Could not reach Google Drive. Check your internet connection.'); }); }
  G.driveList = function () { return G.token(DRIVE).then(function (t) { return api(t, 'drive/v3/files?spaces=appDataFolder&orderBy=modifiedTime%20desc&pageSize=20&fields=files(id,name,modifiedTime,size)').then(function (r) { return r.json(); }).then(function (j) { return { t: t, files: j.files || [] }; }); }); };
  G.driveUpload = function (name, text) {
    return G.token(DRIVE).then(function (t) {
      var b = '-----finnish' + rnd(8), body = '--' + b + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' + JSON.stringify({ name: name, parents: ['appDataFolder'] }) + '\r\n--' + b + '\r\nContent-Type: application/json\r\n\r\n' + text + '\r\n--' + b + '--';
      return api(t, 'upload/drive/v3/files?uploadType=multipart', { method: 'POST', headers: { 'Content-Type': 'multipart/related; boundary=' + b }, body: body }).then(function (r) { return r.json(); }).then(function (j) {
        return api(t, 'drive/v3/files?spaces=appDataFolder&orderBy=modifiedTime%20desc&pageSize=50&fields=files(id)').then(function (r) { return r.json(); }).then(function (l) { return Promise.all((l.files || []).slice(10).map(function (f) { return api(t, 'drive/v3/files/' + f.id, { method: 'DELETE' }).catch(function () { }); })); }).then(function () { return j; });
      });
    });
  };
  G.driveRead = function (t, id) { return api(t, 'drive/v3/files/' + id + '?alt=media').then(function (r) { return r.text(); }); };
})();
